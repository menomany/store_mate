<?php
session_start();

// التحقق من وجود المستخدم
if (!isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}

require_once 'includes/db_connection.php';
require_once 'includes/auth_check.php';

$page_title = "تفاصيل جهة الاتصال";

// الحصول على معرف جهة الاتصال من الرابط
$contact_id = $_GET['id'] ?? 0;

if (!$contact_id) {
    header('Location: contacts.php');
    exit;
}

// جلب بيانات جهة الاتصال
try {
    $stmt = $pdo->prepare("SELECT * FROM contacts WHERE contact_id = ?");
    $stmt->execute([$contact_id]);
    $contact = $stmt->fetch();
    
    if (!$contact) {
        header('Location: contacts.php');
        exit;
    }
} catch (PDOException $e) {
    echo "<div class='alert alert-danger'>خطأ في جلب البيانات: " . $e->getMessage() . "</div>";
    exit;
}

// جلب الحركات المرتبطة بجهة الاتصال
try {
    $stmt = $pdo->prepare("
        SELECT t.*, 
               (SELECT COUNT(*) FROM transaction_details td WHERE td.trans_id = t.trans_id) as items_count
        FROM transactions t 
        WHERE t.contact_id = ? 
        ORDER BY t.trans_date DESC 
        LIMIT 50
    ");
    $stmt->execute([$contact_id]);
    $transactions = $stmt->fetchAll();
} catch (PDOException $e) {
    $transactions = [];
}

// جلب إحصائيات الحركات
try {
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_transactions,
            SUM(CASE WHEN trans_type IN ('in', 'return') THEN total_amount ELSE 0 END) as total_in,
            SUM(CASE WHEN trans_type IN ('out', 'issue') THEN total_amount ELSE 0 END) as total_out
        FROM transactions 
        WHERE contact_id = ?
    ");
    $stmt->execute([$contact_id]);
    $transaction_stats = $stmt->fetch();
} catch (PDOException $e) {
    $transaction_stats = ['total_transactions' => 0, 'total_in' => 0, 'total_out' => 0];
}

// تحديد لون وعنوان النوع
$type_info = [
    'supplier' => ['title' => 'مورد', 'class' => 'bg-warning text-dark', 'icon' => 'bi-truck'],
    'customer' => ['title' => 'عميل', 'class' => 'bg-info text-white', 'icon' => 'bi-person-check'],
    'contractor' => ['title' => 'مقاول', 'class' => 'bg-success text-white', 'icon' => 'bi-briefcase']
];
$type = $contact['contact_type'];
$type_title = $type_info[$type]['title'] ?? 'غير محدد';
$type_class = $type_info[$type]['class'] ?? 'bg-secondary text-white';
$type_icon = $type_info[$type]['icon'] ?? 'bi-person';
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - StoreMate</title>
    
    <!-- Bootstrap CSS مع نسخة احتياطية محلية -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.rtl.min.css" 
          onerror="this.onerror=null;this.href='assets/css/bootstrap.min.css';">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    
    <!-- الخط العربي -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    
    <!-- الأنماط العامة -->
    <?php include 'includes/styles.php'; ?>
    
    <style>
        .contact-avatar-large {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 2rem;
            margin: 0 auto 20px;
        }
        
        .balance-card {
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .balance-positive {
            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            border: 1px solid #c3e6cb;
        }
        
        .balance-negative {
            background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%);
            border: 1px solid #f5c6cb;
        }
        
        .balance-zero {
            background: linear-gradient(135deg, #e2e3e5 0%, #d6d8db 100%);
            border: 1px solid #d6d8db;
        }
        
        .balance-amount {
            font-size: 2.5rem;
            font-weight: bold;
            text-align: center;
            margin: 10px 0;
        }
        
        .transaction-card {
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            margin-bottom: 15px;
            transition: all 0.3s ease;
        }
        
        .transaction-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .transaction-in {
            border-right: 4px solid #28a745;
        }
        
        .transaction-out {
            border-right: 4px solid #dc3545;
        }
        
        .transaction-issue {
            border-right: 4px solid #ffc107;
        }
        
        .transaction-return {
            border-right: 4px solid #17a2b8;
        }
        
        .transaction-transfer {
            border-right: 4px solid #6f42c1;
        }
        
        .action-buttons .btn {
            min-width: 40px;
        }
        
        .info-row {
            padding: 10px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .info-row:last-child {
            border-bottom: none;
        }
        
        .info-label {
            font-weight: 600;
            color: #666;
            min-width: 120px;
        }
        
        .stats-card {
            border-radius: 10px;
            padding: 15px;
            text-align: center;
            margin-bottom: 20px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }
        
        .stats-value {
            font-size: 1.8rem;
            font-weight: bold;
            margin: 10px 0;
        }
        
        .stats-label {
            color: #666;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <!-- السايدبار -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- الشريط العلوي -->
        <?php include 'includes/header.php'; ?>
        
        <!-- بطاقة الترحيب -->
        <div class="welcome-card fade-in">
            <div class="container p-4 position-relative">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h2 class="mb-2">تفاصيل جهة الاتصال</h2>
                        <p class="mb-0 opacity-75">عرض كافة المعلومات والحركات المرتبطة بجهة الاتصال</p>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <a href="contacts.php" class="btn btn-light me-2">
                            <i class="bi bi-arrow-right me-1"></i>رجوع للقائمة
                        </a>
                        <a href="edit_contact.php?id=<?php echo $contact_id; ?>" class="btn btn-warning">
                            <i class="bi bi-pencil me-1"></i>تعديل
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- محتوى الصفحة -->
        <div class="row mb-4 fade-in">
            <!-- العمود الأيمن: معلومات جهة الاتصال -->
            <div class="col-lg-4 mb-4">
                <!-- بطاقة معلومات جهة الاتصال -->
                <div class="card">
                    <div class="card-body text-center">
                        <div class="contact-avatar-large mb-3">
                            <?php echo mb_substr($contact['contact_name'], 0, 1, 'UTF-8'); ?>
                        </div>
                        
                        <h3 class="mb-2"><?php echo htmlspecialchars($contact['contact_name']); ?></h3>
                        
                        <span class="badge <?php echo $type_class; ?> p-2 mb-3">
                            <i class="bi <?php echo $type_icon; ?> me-1"></i>
                            <?php echo $type_title; ?>
                        </span>
                        
                        <hr>
                        
                        <!-- معلومات الاتصال -->
                        <div class="text-start">
                            <div class="info-row d-flex">
                                <span class="info-label">رقم الهاتف:</span>
                                <span class="flex-grow-1">
                                    <?php if($contact['phone_number']): ?>
                                    <a href="tel:<?php echo htmlspecialchars($contact['phone_number']); ?>" class="text-decoration-none">
                                        <i class="bi bi-telephone me-1"></i>
                                        <?php echo htmlspecialchars($contact['phone_number']); ?>
                                    </a>
                                    <?php else: ?>
                                    <span class="text-muted">غير محدد</span>
                                    <?php endif; ?>
                                </span>
                            </div>
                            
                            <div class="info-row d-flex">
                                <span class="info-label">العنوان:</span>
                                <span class="flex-grow-1">
                                    <?php echo $contact['address'] ? htmlspecialchars($contact['address']) : '<span class="text-muted">غير محدد</span>'; ?>
                                </span>
                            </div>
                            
                            <div class="info-row d-flex">
                                <span class="info-label">تاريخ الإضافة:</span>
                                <span class="flex-grow-1">
                                    <?php echo date('Y/m/d H:i', strtotime($contact['created_at'])); ?>
                                </span>
                            </div>
                        </div>
                        
                        <hr>
                        
                        <!-- أزرار الإجراءات -->
                        <div class="d-flex justify-content-center mt-3">
                            <a href="tel:<?php echo htmlspecialchars($contact['phone_number']); ?>" 
                               class="btn btn-outline-primary me-2 <?php echo !$contact['phone_number'] ? 'disabled' : ''; ?>">
                                <i class="bi bi-telephone"></i> اتصال
                            </a>
                            <a href="edit_contact.php?id=<?php echo $contact_id; ?>" class="btn btn-outline-warning me-2">
                                <i class="bi bi-pencil"></i> تعديل
                            </a>
                            <button class="btn btn-outline-danger" 
                                    onclick="deleteContact(<?php echo $contact_id; ?>, '<?php echo htmlspecialchars($contact['contact_name']); ?>')">
                                <i class="bi bi-trash"></i> حذف
                            </button>
                        </div>
                    </div>
                </div>
                
                <!-- بطاقات الإحصائيات الصغيرة -->
                <div class="row mt-4">
                    <div class="col-12 mb-3">
                        <div class="stats-card bg-light">
                            <i class="bi bi-list-check text-primary fs-4"></i>
                            <div class="stats-value"><?php echo $transaction_stats['total_transactions']; ?></div>
                            <div class="stats-label">إجمالي الحركات</div>
                        </div>
                    </div>
                    
                    <div class="col-6 mb-3">
                        <div class="stats-card" style="background: #d4edda;">
                            <i class="bi bi-box-arrow-in-down text-success fs-4"></i>
                            <div class="stats-value"><?php echo number_format($transaction_stats['total_in'], 2); ?></div>
                            <div class="stats-label">إجمالي الوارد</div>
                        </div>
                    </div>
                    
                    <div class="col-6 mb-3">
                        <div class="stats-card" style="background: #f8d7da;">
                            <i class="bi bi-box-arrow-up text-danger fs-4"></i>
                            <div class="stats-value"><?php echo number_format($transaction_stats['total_out'], 2); ?></div>
                            <div class="stats-label">إجمالي الصادر</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- العمود الأيسر: الرصيد والحركات -->
            <div class="col-lg-8">
                <!-- بطاقة الرصيد -->
                <?php
                $balance_class = 'balance-zero';
                if ($contact['current_balance'] > 0) {
                    $balance_class = 'balance-positive';
                } elseif ($contact['current_balance'] < 0) {
                    $balance_class = 'balance-negative';
                }
                ?>
                <div class="balance-card <?php echo $balance_class; ?>">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h4 class="mb-3">الرصيد المالي</h4>
                            <div class="d-flex justify-content-between mb-2">
                                <span>الرصيد الأولي:</span>
                                <span class="fw-bold"><?php echo number_format($contact['initial_balance'], 2); ?> <?php echo isset($currency) ? $currency : 'EGP'; ?></span>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span>الرصيد الحالي:</span>
                                <span class="fw-bold"><?php echo number_format($contact['current_balance'], 2); ?> <?php echo isset($currency) ? $currency : 'EGP'; ?></span>
                            </div>
                            <div class="d-flex justify-content-between">
                                <span>صافي الحركات:</span>
                                <span class="fw-bold">
                                    <?php 
                                    $net_change = $contact['current_balance'] - $contact['initial_balance'];
                                    echo number_format($net_change, 2) . ' ' . (isset($currency) ? $currency : 'EGP');
                                    ?>
                                </span>
                            </div>
                        </div>
                        <div class="col-md-4 text-center">
                            <div class="balance-amount">
                                <?php echo number_format($contact['current_balance'], 2); ?>
                                <small class="d-block"><?php echo isset($currency) ? $currency : 'EGP'; ?></small>
                            </div>
                            <?php if($contact['current_balance'] > 0): ?>
                            <span class="badge bg-success">مدين لنا</span>
                            <?php elseif($contact['current_balance'] < 0): ?>
                            <span class="badge bg-danger">دائن لنا</span>
                            <?php else: ?>
                            <span class="badge bg-secondary">متوازن</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- أزرار الحركات السريعة -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title mb-3">حركات سريعة</h5>
                        <div class="row g-2">
                            <div class="col-md-3 col-6">
                                <a href="add_transaction.php?type=in&contact_id=<?php echo $contact_id; ?>" class="btn btn-success w-100">
                                    <i class="bi bi-box-arrow-in-down me-1"></i>وارد
                                </a>
                            </div>
                            <div class="col-md-3 col-6">
                                <a href="add_transaction.php?type=out&contact_id=<?php echo $contact_id; ?>" class="btn btn-danger w-100">
                                    <i class="bi bi-box-arrow-up me-1"></i>صادر
                                </a>
                            </div>
                            <div class="col-md-3 col-6">
                                <a href="add_transaction.php?type=issue&contact_id=<?php echo $contact_id; ?>" class="btn btn-warning w-100">
                                    <i class="bi bi-box-arrow-right me-1"></i>صرف
                                </a>
                            </div>
                            <div class="col-md-3 col-6">
                                <a href="add_transaction.php?type=return&contact_id=<?php echo $contact_id; ?>" class="btn btn-info w-100">
                                    <i class="bi bi-arrow-counterclockwise me-1"></i>مرتجع
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- قائمة الحركات الحديثة -->
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">آخر الحركات</h5>
                        <a href="transactions.php?contact_id=<?php echo $contact_id; ?>" class="btn btn-sm btn-outline-primary">
                            <i class="bi bi-list me-1"></i>عرض الكل
                        </a>
                    </div>
                    <div class="card-body">
                        <?php if(count($transactions) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>التاريخ</th>
                                        <th>نوع الحركة</th>
                                        <th>عدد الأصناف</th>
                                        <th>القيمة الإجمالية</th>
                                        <th>ملاحظات</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($transactions as $index => $transaction): 
                                        $trans_type_class = '';
                                        $trans_type_text = '';
                                        switch($transaction['trans_type']) {
                                            case 'in':
                                                $trans_type_class = 'transaction-in';
                                                $trans_type_text = 'وارد';
                                                break;
                                            case 'out':
                                                $trans_type_class = 'transaction-out';
                                                $trans_type_text = 'صادر';
                                                break;
                                            case 'issue':
                                                $trans_type_class = 'transaction-issue';
                                                $trans_type_text = 'صرف';
                                                break;
                                            case 'return':
                                                $trans_type_class = 'transaction-return';
                                                $trans_type_text = 'مرتجع';
                                                break;
                                            case 'transfer':
                                                $trans_type_class = 'transaction-transfer';
                                                $trans_type_text = 'تحويل';
                                                break;
                                        }
                                    ?>
                                    <tr class="<?php echo $trans_type_class; ?>">
                                        <td><?php echo $index + 1; ?></td>
                                        <td><?php echo date('Y/m/d H:i', strtotime($transaction['trans_date'])); ?></td>
                                        <td>
                                            <span class="badge bg-secondary">
                                                <?php echo $trans_type_text; ?>
                                            </span>
                                        </td>
                                        <td><?php echo $transaction['items_count']; ?></td>
                                        <td>
                                            <span class="<?php echo in_array($transaction['trans_type'], ['in', 'return']) ? 'text-success' : 'text-danger'; ?>">
                                                <?php echo number_format($transaction['total_amount'], 2); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php echo $transaction['notes'] ? htmlspecialchars(substr($transaction['notes'], 0, 30)) . (strlen($transaction['notes']) > 30 ? '...' : '') : '---'; ?>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm action-buttons">
                                                <a href="transaction_details.php?id=<?php echo $transaction['trans_id']; ?>" 
                                                   class="btn btn-outline-info" title="عرض">
                                                    <i class="bi bi-eye"></i>
                                                </a>
                                                <a href="edit_transaction.php?id=<?php echo $transaction['trans_id']; ?>" 
                                                   class="btn btn-outline-warning" title="تعديل">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php else: ?>
                        <div class="text-center py-5">
                            <i class="bi bi-arrow-left-right display-1 text-muted"></i>
                            <h5 class="mt-3">لا توجد حركات</h5>
                            <p class="text-muted">لم يتم تسجيل أي حركات لهذه جهة الاتصال بعد</p>
                            <a href="add_transaction.php?type=in&contact_id=<?php echo $contact_id; ?>" class="btn btn-primary mt-3">
                                <i class="bi bi-plus-circle me-1"></i>إضافة أول حركة
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- الفوتر -->
    <?php include 'includes/footer.php'; ?>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- الاسكريبتات العامة -->
    <?php include 'includes/scripts.php'; ?>
    
    <script>
    // وظيفة حذف جهة الاتصال
    function deleteContact(id, name) {
        if(confirm(`هل أنت متأكد من حذف جهة الاتصال "${name}"؟`)) {
            fetch(`api/delete_contact.php?id=${id}`, {
                method: 'DELETE'
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    alert('تم حذف جهة الاتصال بنجاح');
                    window.location.href = 'contacts.php';
                } else {
                    alert(data.message || 'حدث خطأ أثناء الحذف');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('حدث خطأ في الاتصال');
            });
        }
    }
    
    // تهيئة أدوات التلميح
    document.addEventListener('DOMContentLoaded', function() {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    });
    </script>
</body>
</html>