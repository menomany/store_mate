<?php
// product_details.php
session_start();

// تعريف متغيرات الجلسة إذا لم تكن موجودة
if (!isset($_SESSION['full_name'])) {
    $_SESSION['full_name'] = 'مستخدم النظام';
    $_SESSION['role'] = 'مدير';
}

require_once 'includes/db_connection.php';
require_once 'includes/auth_check.php';

$page_title = "تفاصيل المنتج";

// التحقق من وجود معرف المنتج
$product_id = $_GET['id'] ?? 0;
if (!$product_id) {
    header('Location: products.php');
    exit;
}

// جلب بيانات المنتج
try {
    $stmt = $pdo->prepare("
        SELECT p.*, c.category_name,
               COALESCE(p.initial_balance, 0) as initial_balance,
               (SELECT COALESCE(SUM(CASE WHEN t.trans_type IN ('in', 'return') THEN td.quantity ELSE 0 END), 0)
                FROM transaction_details td 
                JOIN transactions t ON td.trans_id = t.trans_id 
                WHERE td.product_id = p.product_id) as total_in,
               (SELECT COALESCE(SUM(CASE WHEN t.trans_type IN ('out', 'issue') THEN td.quantity ELSE 0 END), 0)
                FROM transaction_details td 
                JOIN transactions t ON td.trans_id = t.trans_id 
                WHERE td.product_id = p.product_id) as total_out
        FROM products p 
        LEFT JOIN categories c ON p.category_id = c.category_id 
        WHERE p.product_id = ?
    ");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch();
    
    if (!$product) {
        header('Location: products.php');
        exit;
    }
    
    // حساب المخزون الحالي
    $current_stock = (($product['initial_balance'] ?? 0) + ($product['total_in'] ?? 0)) - ($product['total_out'] ?? 0);
    $is_low_stock = $current_stock <= ($product['min_stock_level'] ?? 0);
    
} catch (PDOException $e) {
    die("<div class='alert alert-danger'>خطأ في جلب بيانات المنتج: " . $e->getMessage() . "</div>");
}

// جلب وحدات المنتج
try {
    $units_stmt = $pdo->prepare("SELECT * FROM product_units WHERE product_id = ? ORDER BY conversion_factor");
    $units_stmt->execute([$product_id]);
    $units = $units_stmt->fetchAll();
} catch (PDOException $e) {
    $units = [];
}

// جلب آخر 10 حركات للمنتج
try {
    $transactions_stmt = $pdo->prepare("
        SELECT t.trans_id, t.trans_date, t.trans_type, 
               td.quantity, td.unit_price, td.total_item_price,
               c.contact_name, p.project_name,
               CASE 
                   WHEN t.trans_type = 'in' THEN 'وارد'
                   WHEN t.trans_type = 'out' THEN 'صادر'
                   WHEN t.trans_type = 'issue' THEN 'صرف'
                   WHEN t.trans_type = 'return' THEN 'مرتجع'
                   WHEN t.trans_type = 'transfer' THEN 'تحويل'
                   ELSE t.trans_type
               END as trans_type_arabic
        FROM transactions t
        JOIN transaction_details td ON t.trans_id = td.trans_id
        LEFT JOIN contacts c ON t.contact_id = c.contact_id
        LEFT JOIN projects p ON t.project_id = p.project_id
        WHERE td.product_id = ?
        ORDER BY t.trans_date DESC
        LIMIT 10
    ");
    $transactions_stmt->execute([$product_id]);
    $recent_transactions = $transactions_stmt->fetchAll();
} catch (PDOException $e) {
    $recent_transactions = [];
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $product['product_name'] . ' - ' . $page_title; ?> - StoreMate</title>
    
    <!-- Bootstrap CSS مع نسخة احتياطية محلية -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.rtl.min.css" onerror="this.onerror=null;this.href='assets/css/bootstrap.min.css';">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    
    <!-- الخط العربي -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    
    <!-- الأنماط العامة -->
    <?php include 'includes/styles.php'; ?>
    
    <style>
        .product-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px;
            padding: 2rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            transition: transform 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .unit-badge {
            font-size: 0.85rem;
            padding: 0.35rem 0.75rem;
        }
        
        .stock-indicator {
            font-size: 1.1rem;
            font-weight: bold;
        }
        
        .transaction-type {
            width: 80px;
            text-align: center;
            border-radius: 4px;
            padding: 2px 8px;
            font-size: 0.8rem;
            font-weight: bold;
        }
        
        .type-in { background-color: #d1e7dd; color: #0f5132; }
        .type-out { background-color: #f8d7da; color: #842029; }
        .type-issue { background-color: #fff3cd; color: #664d03; }
        .type-return { background-color: #cff4fc; color: #055160; }
        .type-transfer { background-color: #e7f1ff; color: #084298; }
    </style>
</head>
<body>
    <!-- السايدبار -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- الشريط العلوي -->
        <?php include 'includes/header.php'; ?>
        
        <!-- رأس صفحة المنتج -->
        <div class="container mt-4">
            <div class="product-header fade-in">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <div class="d-flex align-items-center mb-3">
                            <button onclick="history.back()" class="btn btn-light btn-sm me-3">
                                <i class="bi bi-arrow-right"></i> رجوع
                            </button>
                            <h2 class="mb-0"><?php echo htmlspecialchars($product['product_name']); ?></h2>
                        </div>
                        <div class="d-flex flex-wrap gap-3">
                            <?php if($product['product_code']): ?>
                            <span class="badge bg-light text-dark">
                                <i class="bi bi-upc-scan me-1"></i> <?php echo htmlspecialchars($product['product_code']); ?>
                            </span>
                            <?php endif; ?>
                            
                            <span class="badge bg-info">
                                <i class="bi bi-tag me-1"></i> <?php echo htmlspecialchars($product['category_name'] ?? 'بدون فئة'); ?>
                            </span>
                            
                            <?php if($product['is_cable']): ?>
                            <span class="badge bg-warning">
                                <i class="bi bi-lightning-charge me-1"></i> كابل
                            </span>
                            <?php endif; ?>
                            
                            <?php if($is_low_stock): ?>
                            <span class="badge bg-danger">
                                <i class="bi bi-exclamation-triangle me-1"></i> مخزون منخفض
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <div class="btn-group">
                            <a href="products.php" class="btn btn-light">
                                <i class="bi bi-box-seam me-1"></i> جميع المنتجات
                            </a>
                            <a href="edit_product.php?id=<?php echo $product_id; ?>" class="btn btn-warning">
                                <i class="bi bi-pencil-square me-1"></i> تعديل
                            </a>
                            <button class="btn btn-danger" onclick="deleteProduct(<?php echo $product_id; ?>, '<?php echo htmlspecialchars($product['product_name']); ?>')">
                                <i class="bi bi-trash me-1"></i> حذف
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- إحصائيات المخزون -->
        <div class="container mb-4">
            <div class="row g-4">
                <div class="col-xl-3 col-md-6">
                    <div class="card stat-card border-primary h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="text-muted mb-1">رصيد أول المدة</h6>
                                    <h3 class="mb-0 text-primary">
                                        <?php echo number_format($product['initial_balance'] ?? 0, 3); ?>
                                    </h3>
                                    <small class="text-muted">كمية البداية</small>
                                </div>
                                <div class="text-primary">
                                    <i class="bi bi-arrow-bar-up display-6 opacity-50"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-3 col-md-6">
                    <div class="card stat-card border-success h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="text-muted mb-1">إجمالي الوارد</h6>
                                    <h3 class="mb-0 text-success">
                                        <?php echo number_format($product['total_in'] ?? 0, 3); ?>
                                    </h3>
                                    <small class="text-muted">عمليات الإضافة</small>
                                </div>
                                <div class="text-success">
                                    <i class="bi bi-box-arrow-in-down display-6 opacity-50"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-3 col-md-6">
                    <div class="card stat-card border-danger h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="text-muted mb-1">إجمالي الصادر</h6>
                                    <h3 class="mb-0 text-danger">
                                        <?php echo number_format($product['total_out'] ?? 0, 3); ?>
                                    </h3>
                                    <small class="text-muted">عمليات الصرف</small>
                                </div>
                                <div class="text-danger">
                                    <i class="bi bi-box-arrow-up display-6 opacity-50"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-3 col-md-6">
                    <div class="card stat-card border-warning h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="text-muted mb-1">المخزون الحالي</h6>
                                    <h3 class="mb-0 <?php echo $is_low_stock ? 'text-danger' : 'text-warning'; ?> stock-indicator">
                                        <?php echo number_format($current_stock, 3); ?>
                                    </h3>
                                    <small class="text-muted">
                                        <?php echo $is_low_stock ? 'تحت حد الطلب' : 'متاح'; ?>
                                    </small>
                                </div>
                                <div class="<?php echo $is_low_stock ? 'text-danger' : 'text-warning'; ?>">
                                    <i class="bi bi-box-seam display-6 opacity-50"></i>
                                </div>
                            </div>
                            <?php if($is_low_stock): ?>
                            <div class="mt-3">
                                <div class="progress" style="height: 6px;">
                                    <?php 
                                    $min_stock = $product['min_stock_level'] ?? 1;
                                    $percentage = min(($current_stock / $min_stock) * 100, 100);
                                    ?>
                                    <div class="progress-bar bg-danger" style="width: <?php echo $percentage; ?>%"></div>
                                </div>
                                <small class="text-danger">متاح <?php echo number_format($current_stock, 2); ?> من <?php echo number_format($min_stock, 2); ?> المطلوبة</small>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- المعلومات التفصيلية -->
        <div class="container">
            <div class="row">
                <!-- العمود الأيسر: المعلومات الأساسية -->
                <div class="col-lg-8 mb-4">
                    <div class="card h-100">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <i class="bi bi-info-circle me-2"></i> معلومات المنتج
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label text-muted">اسم المنتج</label>
                                    <p class="form-control-static fw-bold"><?php echo htmlspecialchars($product['product_name']); ?></p>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label text-muted">كود المنتج</label>
                                    <p class="form-control-static">
                                        <?php echo $product['product_code'] ? htmlspecialchars($product['product_code']) : '<span class="text-muted">غير محدد</span>'; ?>
                                    </p>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label text-muted">الفئة</label>
                                    <p class="form-control-static">
                                        <?php echo htmlspecialchars($product['category_name'] ?? 'بدون فئة'); ?>
                                    </p>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label text-muted">حد الطلب الأدنى</label>
                                    <p class="form-control-static"><?php echo number_format($product['min_stock_level'] ?? 0, 2); ?></p>
                                </div>
                                <div class="col-md-6 mb-3">
                                <label class="form-label tex    t-muted">سعر الوحدة الأساسية</label>
                                <?php
                                // الحصول على سعر الوحدة الأساسية
                                $base_price = 0;
                                try {
                                $price_stmt = $pdo->prepare("SELECT unit_price FROM product_units WHERE product_id = ? AND is_base_unit = 1 LIMIT 1");
                                $price_stmt->execute([$product_id]);
                                $price_result = $price_stmt->fetch();
                                $base_price = $price_result['unit_price'] ?? 0;
                                } catch (Exception $e) {
                                $base_price = 0;
                                }
                                ?>
                                <p class="form-control-static fw-bold text-success">
                                <?php echo number_format($base_price, 2); ?> ج.م
                                </p>
                                </div>          
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label text-muted">تاريخ الإضافة</label>
                                    <p class="form-control-static">
                                        <?php echo date('Y-m-d', strtotime($product['created_at'] ?? 'now')); ?>
                                    </p>
                                </div>
                                
                                <div class="col-12 mb-3">
                                    <label class="form-label text-muted">الخصائص</label>
                                    <div class="d-flex flex-wrap gap-2">
                                        <span class="badge <?php echo $product['is_cable'] ? 'bg-warning' : 'bg-secondary'; ?>">
                                            <i class="bi bi-<?php echo $product['is_cable'] ? 'lightning-charge' : 'box'; ?> me-1"></i>
                                            <?php echo $product['is_cable'] ? 'منتج كابل' : 'منتج عادي'; ?>
                                        </span>
                                        
                                        <span class="badge <?php echo $is_low_stock ? 'bg-danger' : 'bg-success'; ?>">
                                            <i class="bi bi-<?php echo $is_low_stock ? 'exclamation-triangle' : 'check-circle'; ?> me-1"></i>
                                            <?php echo $is_low_stock ? 'مخزون منخفض' : 'مخزون كافي'; ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- العمود الأيمن: الوحدات والأسعار -->
                <div class="col-lg-4 mb-4">
                    <div class="card h-100">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <i class="bi bi-rulers me-2"></i> الوحدات والأسعار
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php if(count($units) > 0): ?>
                            <div class="list-group">
                                <?php foreach($units as $unit): ?>
                                <div class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-1"><?php echo htmlspecialchars($unit['unit_name']); ?></h6>
                                        <small class="text-muted">
                                            <?php if($unit['is_base_unit']): ?>
                                            الوحدة الأساسية
                                            <?php else: ?>
                                            = <?php echo number_format($unit['conversion_factor'], 3); ?> وحدة أساسية
                                            <?php endif; ?>
                                        </small>
                                    </div>
                                    <div class="text-end">
                                        <span class="badge bg-primary unit-badge">
                                            <?php echo number_format($unit['unit_price'] ?? 0, 2); ?> ج.م
                                        </span>
                                        <?php if($unit['is_base_unit']): ?>
                                        <span class="badge bg-success unit-badge mt-1">أساسي</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <?php else: ?>
                            <div class="text-center py-4">
                                <i class="bi bi-rulers display-4 text-muted"></i>
                                <p class="mt-3 text-muted">لا توجد وحدات مخصصة</p>
                                <a href="edit_product.php?id=<?php echo $product_id; ?>" class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-plus-circle me-1"></i> إضافة وحدات
                                </a>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- آخر الحركات -->
            <?php if(count($recent_transactions) > 0): ?>
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="bi bi-clock-history me-2"></i> آخر الحركات
                    </h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>التاريخ</th>
                                    <th>نوع الحركة</th>
                                    <th>الكمية</th>
                                    <th>السعر</th>
                                    <th>الإجمالي</th>
                                    <th>الجهة</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($recent_transactions as $index => $trans): ?>
                                <tr>
                                    <td><?php echo $index + 1; ?></td>
                                    <td><?php echo date('Y-m-d H:i', strtotime($trans['trans_date'])); ?></td>
                                    <td>
                                        <span class="transaction-type type-<?php echo $trans['trans_type']; ?>">
                                            <?php echo $trans['trans_type_arabic']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo number_format($trans['quantity'], 3); ?></td>
                                    <td><?php echo number_format($trans['unit_price'] ?? 0, 2); ?> ج.م</td>
                                    <td><?php echo number_format($trans['total_item_price'] ?? 0, 2); ?> ج.م</td>
                                    <td>
                                        <?php 
                                        if($trans['contact_name']) {
                                            echo htmlspecialchars($trans['contact_name']);
                                        } elseif($trans['project_name']) {
                                            echo '<span class="badge bg-info">' . htmlspecialchars($trans['project_name']) . '</span>';
                                        } else {
                                            echo '<span class="text-muted">---</span>';
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer text-center">
                    <a href="transactions.php?product_id=<?php echo $product_id; ?>" class="btn btn-sm btn-outline-primary">
                        <i class="bi bi-list-check me-1"></i> عرض جميع الحركات
                    </a>
                </div>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- أزرار الإجراءات -->
        <div class="container mb-5">
            <div class="d-flex justify-content-center gap-3">
                <a href="new_transaction.php?product_id=<?php echo $product_id; ?>&type=in" class="btn btn-success btn-lg">
                    <i class="bi bi-plus-circle me-2"></i>إضافة وارد
                </a>
                <a href="new_transaction.php?product_id=<?php echo $product_id; ?>&type=out" class="btn btn-danger btn-lg">
                    <i class="bi bi-dash-circle me-2"></i>صرف منتج
                </a>
                <a href="edit_product.php?id=<?php echo $product_id; ?>" class="btn btn-warning btn-lg">
                    <i class="bi bi-pencil-square me-2"></i>تعديل المنتج
                </a>
                <a href="products.php" class="btn btn-secondary btn-lg">
                    <i class="bi bi-box-seam me-2"></i>جميع المنتجات
                </a>
            </div>
        </div>
    </div>
    
    <!-- الفوتر -->
    <?php include 'includes/footer.php'; ?>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- الاسكريبتات العامة -->
    <?php include 'includes/scripts.php'; ?>
    
    <script>
    function deleteProduct(id, name) {
        if(confirm(`هل أنت متأكد من حذف المنتج "${name}"؟\n\nملاحظة: لا يمكن التراجع عن هذا الإجراء.`)) {
            fetch(`api/delete_product.php?id=${id}`, {
                method: 'DELETE'
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    alert('تم حذف المنتج بنجاح');
                    window.location.href = 'products.php';
                } else {
                    alert(data.message || 'حدث خطأ أثناء الحذف');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('حدث خطأ في الاتصال');
            });
        }
    }
    
    // إضافة تأثيرات للبطاقات
    document.addEventListener('DOMContentLoaded', function() {
        const statCards = document.querySelectorAll('.stat-card');
        statCards.forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-5px)';
            });
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
            });
        });
    });
    </script>
</body>
</html>