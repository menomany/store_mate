<?php
session_start();
require_once '../includes/db_connection.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'غير مسموح بالوصول']);
    exit;
}

$trans_id = $_GET['id'] ?? null;
if (!$trans_id) {
    echo json_encode(['success' => false, 'message' => 'معرف الحركة مطلوب']);
    exit;
}

try {
    $pdo->beginTransaction();
    
    // جلب بيانات الحركة
    $stmt = $pdo->prepare("SELECT trans_type, contact_id, total_amount FROM transactions WHERE trans_id = ?");
    $stmt->execute([$trans_id]);
    $transaction = $stmt->fetch();
    
    if (!$transaction) {
        echo json_encode(['success' => false, 'message' => 'الحركة غير موجودة']);
        exit;
    }
    
    // تحديث رصيد جهة الاتصال (عكس العملية)
    if ($transaction['contact_id'] && $transaction['total_amount'] > 0) {
        $balance_change = 0;
        if (in_array($transaction['trans_type'], ['in', 'return'])) {
            $balance_change = $transaction['total_amount']; // عكس النقص
        } elseif (in_array($transaction['trans_type'], ['out', 'issue'])) {
            $balance_change = -$transaction['total_amount']; // عكس الزيادة
        }
        
        if ($balance_change != 0) {
            $stmt = $pdo->prepare("
                UPDATE contacts 
                SET current_balance = current_balance + ? 
                WHERE contact_id = ?
            ");
            $stmt->execute([$balance_change, $transaction['contact_id']]);
        }
    }
    
    // حذف تفاصيل الحركة
    $stmt = $pdo->prepare("DELETE FROM transaction_details WHERE trans_id = ?");
    $stmt->execute([$trans_id]);
    
    // حذف الحركة
    $stmt = $pdo->prepare("DELETE FROM transactions WHERE trans_id = ?");
    $stmt->execute([$trans_id]);
    
    $pdo->commit();
    
    echo json_encode(['success' => true, 'message' => 'تم حذف الحركة بنجاح']);
    
} catch (PDOException $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'خطأ في قاعدة البيانات: ' . $e->getMessage()]);
}