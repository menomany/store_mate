<?php
session_start();

// التحقق من وجود المستخدم
if (!isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}

require_once 'includes/db_connection.php';
require_once 'includes/auth_check.php';

$page_title = "الحركات";

// جلب الحركات مع البحث والتصفية
$search = $_GET['search'] ?? '';
$trans_type = $_GET['trans_type'] ?? '';
$contact_id = $_GET['contact_id'] ?? '';
$project_id = $_GET['project_id'] ?? '';
$warehouse_id = $_GET['warehouse_id'] ?? '';
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';

// استعلام أساسي لجلب الحركات
$query = "SELECT t.*, c.contact_name, p.project_name, 
          w1.warehouse_name as from_warehouse_name, 
          w2.warehouse_name as to_warehouse_name,
          u.full_name as user_name
          FROM transactions t 
          LEFT JOIN contacts c ON t.contact_id = c.contact_id
          LEFT JOIN projects p ON t.project_id = p.project_id
          LEFT JOIN warehouses w1 ON t.from_warehouse_id = w1.warehouse_id
          LEFT JOIN warehouses w2 ON t.to_warehouse_id = w2.warehouse_id
          LEFT JOIN users u ON t.user_id = u.id
          WHERE 1=1";

$params = [];

if (!empty($search)) {
    $searchTerm = "%$search%";
    $query .= " AND (t.notes LIKE ? OR c.contact_name LIKE ? OR t.trans_id LIKE ? OR p.project_name LIKE ?)";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

if (!empty($trans_type)) {
    $query .= " AND t.trans_type = ?";
    $params[] = $trans_type;
}

if (!empty($contact_id)) {
    $query .= " AND t.contact_id = ?";
    $params[] = $contact_id;
}

if (!empty($project_id)) {
    $query .= " AND t.project_id = ?";
    $params[] = $project_id;
}

if (!empty($warehouse_id)) {
    $query .= " AND (t.from_warehouse_id = ? OR t.to_warehouse_id = ?)";
    $params[] = $warehouse_id;
    $params[] = $warehouse_id;
}

if (!empty($start_date)) {
    $query .= " AND DATE(t.trans_date) >= ?";
    $params[] = $start_date;
}

if (!empty($end_date)) {
    $query .= " AND DATE(t.trans_date) <= ?";
    $params[] = $end_date;
}

$query .= " ORDER BY t.trans_date DESC, t.trans_id DESC";

// تحديد عدد الصفحات
$limit = 50;
$page = $_GET['page'] ?? 1;
$offset = ($page - 1) * $limit;

// استعلام العد
try {
    $count_query = "SELECT COUNT(*) as total FROM transactions t 
                    LEFT JOIN contacts c ON t.contact_id = c.contact_id
                    LEFT JOIN projects p ON t.project_id = p.project_id
                    WHERE 1=1";
    
    $count_params = [];
    
    if (!empty($search)) {
        $searchTerm = "%$search%";
        $count_query .= " AND (t.notes LIKE ? OR c.contact_name LIKE ? OR t.trans_id LIKE ? OR p.project_name LIKE ?)";
        $count_params[] = $searchTerm;
        $count_params[] = $searchTerm;
        $count_params[] = $searchTerm;
        $count_params[] = $searchTerm;
    }
    
    if (!empty($trans_type)) {
        $count_query .= " AND t.trans_type = ?";
        $count_params[] = $trans_type;
    }
    
    $count_stmt = $pdo->prepare($count_query);
    $count_stmt->execute($count_params);
    $total_result = $count_stmt->fetch();
    $total_transactions = $total_result['total'] ?? 0;
    $total_pages = ceil($total_transactions / $limit);
} catch (PDOException $e) {
    $total_transactions = 0;
    $total_pages = 1;
    error_log("خطأ في استعلام العد: " . $e->getMessage());
}

// إضافة التحديد للصفحة
$query .= " LIMIT ? OFFSET ?";
$params[] = $limit;
$params[] = $offset;

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $transactions = $stmt->fetchAll();
} catch (PDOException $e) {
    $transactions = [];
    $error_message = "خطأ في جلب البيانات: " . $e->getMessage();
    error_log($error_message);
}

// جلب عدد الأصناف لكل حركة
foreach ($transactions as &$trans) {
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) as items_count FROM transaction_details WHERE trans_id = ?");
        $stmt->execute([$trans['trans_id']]);
        $result = $stmt->fetch();
        $trans['items_count'] = $result['items_count'] ?? 0;
    } catch (PDOException $e) {
        $trans['items_count'] = 0;
    }
}

// جلب البيانات للفلترة
try {
    $contacts = $pdo->query("SELECT contact_id, contact_name, contact_type FROM contacts ORDER BY contact_name")->fetchAll();
    $projects = $pdo->query("SELECT project_id, project_name FROM projects ORDER BY project_name")->fetchAll();
    $warehouses = $pdo->query("SELECT warehouse_id, warehouse_name FROM warehouses WHERE is_active = 1 ORDER BY warehouse_name")->fetchAll();
} catch (PDOException $e) {
    $contacts = [];
    $projects = [];
    $warehouses = [];
}

// إحصائيات الحركات
try {
    $stats_query = "SELECT 
        COUNT(*) as total_transactions,
        SUM(CASE WHEN trans_type IN ('in', 'return') THEN total_amount ELSE 0 END) as total_in,
        SUM(CASE WHEN trans_type IN ('out', 'issue') THEN total_amount ELSE 0 END) as total_out,
        SUM(CASE 
            WHEN trans_type IN ('in', 'return') THEN total_amount 
            WHEN trans_type IN ('out', 'issue') THEN -total_amount 
            ELSE 0 
        END) as net_total,
        COUNT(CASE WHEN trans_type = 'in' THEN 1 END) as in_count,
        COUNT(CASE WHEN trans_type = 'out' THEN 1 END) as out_count,
        COUNT(CASE WHEN trans_type = 'issue' THEN 1 END) as issue_count,
        COUNT(CASE WHEN trans_type = 'return' THEN 1 END) as return_count,
        COUNT(CASE WHEN trans_type = 'transfer' THEN 1 END) as transfer_count
        FROM transactions WHERE 1=1";
    
    $stats_params = [];
    
    if (!empty($start_date)) {
        $stats_query .= " AND DATE(trans_date) >= ?";
        $stats_params[] = $start_date;
    }
    
    if (!empty($end_date)) {
        $stats_query .= " AND DATE(trans_date) <= ?";
        $stats_params[] = $end_date;
    }
    
    $stats_stmt = $pdo->prepare($stats_query);
    $stats_stmt->execute($stats_params);
    $stats = $stats_stmt->fetch();
    
    if (!$stats) {
        $stats = [
            'total_transactions' => 0,
            'total_in' => 0,
            'total_out' => 0,
            'net_total' => 0,
            'in_count' => 0,
            'out_count' => 0,
            'issue_count' => 0,
            'return_count' => 0,
            'transfer_count' => 0
        ];
    }
} catch (PDOException $e) {
    $stats = [
        'total_transactions' => 0,
        'total_in' => 0,
        'total_out' => 0,
        'net_total' => 0,
        'in_count' => 0,
        'out_count' => 0,
        'issue_count' => 0,
        'return_count' => 0,
        'transfer_count' => 0
    ];
}

// أسماء أنواع الحركات
$trans_type_names = [
    'in' => 'وارد',
    'out' => 'صادر',
    'issue' => 'صرف',
    'return' => 'مرتجع',
    'transfer' => 'تحويل'
];
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - StoreMate</title>
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.rtl.min.css">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    
    <!-- الأنماط العامة -->
    <?php include 'includes/styles.php'; ?>
    
    <style>
        .transaction-badge {
            font-size: 0.75rem;
            padding: 0.25rem 0.5rem;
        }
        
        .badge-in { background-color: #d4edda; color: #155724; }
        .badge-out { background-color: #f8d7da; color: #721c24; }
        .badge-issue { background-color: #fff3cd; color: #856404; }
        .badge-return { background-color: #d1ecf1; color: #0c5460; }
        .badge-transfer { background-color: #d6d8db; color: #383d41; }
        
        .amount-positive { color: #28a745; font-weight: bold; }
        .amount-negative { color: #dc3545; font-weight: bold; }
        
        .stats-card {
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
            transition: all 0.3s ease;
            height: 100%;
            color: white;
        }
        
        .stats-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .stats-value {
            font-size: 1.8rem;
            font-weight: bold;
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <!-- السايدبار -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- الشريط العلوي -->
        <?php include 'includes/header.php'; ?>
        
        <!-- بطاقة الترحيب -->
        <div class="welcome-card fade-in">
            <div class="container p-4 position-relative">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h2 class="mb-2">إدارة الحركات</h2>
                        <p class="mb-0 opacity-75">عرض وتتبع جميع حركات المخزون والمشتريات والمبيعات</p>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <a href="add_transaction.php" class="btn btn-primary">
                            <i class="bi bi-plus-circle me-1"></i>إضافة حركة جديدة
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- إحصائيات سريعة -->
        <div class="row mb-4 fade-in">
            <div class="col-xl-2 col-lg-4 col-md-6 mb-3">
                <div class="stats-card" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-1">إجمالي الحركات</h6>
                            <h3 class="mb-0 stats-value"><?php echo number_format($stats['total_transactions']); ?></h3>
                            <small class="stats-label">حركة في النظام</small>
                        </div>
                        <div>
                            <i class="bi bi-arrow-left-right fs-3"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-2 col-lg-4 col-md-6 mb-3">
                <div class="stats-card" style="background: linear-gradient(135deg, #28a745 0%, #20c997 100%);">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-1">إجمالي الوارد</h6>
                            <h3 class="mb-0 stats-value"><?php echo number_format($stats['total_in'], 2); ?></h3>
                            <small class="stats-label">قيمة المشتريات</small>
                        </div>
                        <div>
                            <i class="bi bi-box-arrow-in-down fs-3"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-2 col-lg-4 col-md-6 mb-3">
                <div class="stats-card" style="background: linear-gradient(135deg, #dc3545 0%, #fd7e14 100%);">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-1">إجمالي الصادر</h6>
                            <h3 class="mb-0 stats-value"><?php echo number_format($stats['total_out'], 2); ?></h3>
                            <small class="stats-label">قيمة المبيعات</small>
                        </div>
                        <div>
                            <i class="bi bi-box-arrow-up fs-3"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-2 col-lg-4 col-md-6 mb-3">
                <div class="stats-card" style="background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%);">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-1">صرف</h6>
                            <h3 class="mb-0 stats-value"><?php echo number_format($stats['issue_count']); ?></h3>
                            <small class="stats-label">حركة صرف</small>
                        </div>
                        <div>
                            <i class="bi bi-box-arrow-right fs-3"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-2 col-lg-4 col-md-6 mb-3">
                <div class="stats-card" style="background: linear-gradient(135deg, #17a2b8 0%, #20c997 100%);">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-1">مرتجع</h6>
                            <h3 class="mb-0 stats-value"><?php echo number_format($stats['return_count']); ?></h3>
                            <small class="stats-label">حركة إرجاع</small>
                        </div>
                        <div>
                            <i class="bi bi-arrow-counterclockwise fs-3"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-2 col-lg-4 col-md-6 mb-3">
                <div class="stats-card" style="background: linear-gradient(135deg, #6c757d 0%, #495057 100%);">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-1">تحويل</h6>
                            <h3 class="mb-0 stats-value"><?php echo number_format($stats['transfer_count']); ?></h3>
                            <small class="stats-label">تحويل مخازن</small>
                        </div>
                        <div>
                            <i class="bi bi-arrow-left-right fs-3"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- فلترة متقدمة -->
        <div class="filter-section fade-in">
            <form method="GET" class="row g-3">
                <div class="col-md-2">
                    <label class="form-label">نوع الحركة</label>
                    <select class="form-select" name="trans_type">
                        <option value="">كل الأنواع</option>
                        <option value="in" <?php echo ($trans_type == 'in') ? 'selected' : ''; ?>>وارد</option>
                        <option value="out" <?php echo ($trans_type == 'out') ? 'selected' : ''; ?>>صادر</option>
                        <option value="issue" <?php echo ($trans_type == 'issue') ? 'selected' : ''; ?>>صرف</option>
                        <option value="return" <?php echo ($trans_type == 'return') ? 'selected' : ''; ?>>مرتجع</option>
                        <option value="transfer" <?php echo ($trans_type == 'transfer') ? 'selected' : ''; ?>>تحويل</option>
                    </select>
                </div>
                
                <div class="col-md-2">
                    <label class="form-label">جهة الاتصال</label>
                    <select class="form-select" name="contact_id">
                        <option value="">كل جهات الاتصال</option>
                        <?php foreach($contacts as $contact): ?>
                        <option value="<?php echo $contact['contact_id']; ?>" <?php echo ($contact_id == $contact['contact_id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($contact['contact_name']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="col-md-2">
                    <label class="form-label">المشروع</label>
                    <select class="form-select" name="project_id">
                        <option value="">كل المشاريع</option>
                        <?php foreach($projects as $project): ?>
                        <option value="<?php echo $project['project_id']; ?>" <?php echo ($project_id == $project['project_id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($project['project_name']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="col-md-2">
                    <label class="form-label">المخزن</label>
                    <select class="form-select" name="warehouse_id">
                        <option value="">كل المخازن</option>
                        <?php foreach($warehouses as $warehouse): ?>
                        <option value="<?php echo $warehouse['warehouse_id']; ?>" <?php echo ($warehouse_id == $warehouse['warehouse_id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($warehouse['warehouse_name']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="col-md-2">
                    <label class="form-label">من تاريخ</label>
                    <input type="date" class="form-control" name="start_date" value="<?php echo $start_date; ?>">
                </div>
                
                <div class="col-md-2">
                    <label class="form-label">إلى تاريخ</label>
                    <input type="date" class="form-control" name="end_date" value="<?php echo $end_date; ?>">
                </div>
                
                <div class="col-12">
                    <label class="form-label">بحث</label>
                    <div class="input-group">
                        <input type="text" class="form-control" name="search" 
                               placeholder="ابحث برقم الحركة، الملاحظات، أو اسم جهة الاتصال" 
                               value="<?php echo htmlspecialchars($search); ?>">
                        <button class="btn btn-primary" type="submit">
                            <i class="bi bi-search"></i> بحث
                        </button>
                    </div>
                </div>
                
                <div class="col-12">
                    <div class="d-flex justify-content-between mt-3">
                        <div>
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-filter me-1"></i>تطبيق الفلتر
                            </button>
                            <?php if(!empty($search) || !empty($trans_type) || !empty($contact_id) || !empty($project_id) || !empty($warehouse_id) || !empty($start_date) || !empty($end_date)): ?>
                            <a href="transactions.php" class="btn btn-outline-secondary ms-2">
                                <i class="bi bi-x-circle me-1"></i>مسح الفلاتر
                            </a>
                            <?php endif; ?>
                        </div>
                        
                        <div>
                            <button type="button" class="btn btn-success" onclick="exportToExcel()">
                                <i class="bi bi-file-earmark-excel me-1"></i>تصدير إكسل
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        
        <!-- جدول الحركات -->
        <div class="dashboard-table fade-in">
            <div class="card">
                <div class="card-body">
                    <?php if(isset($error_message)): ?>
                    <div class="alert alert-danger">
                        <?php echo $error_message; ?>
                    </div>
                    <?php endif; ?>
                    
                    <?php if(count($transactions) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>رقم الحركة</th>
                                    <th>التاريخ</th>
                                    <th>نوع الحركة</th>
                                    <th>جهة الاتصال</th>
                                    <th>عدد الأصناف</th>
                                    <th>القيمة</th>
                                    <th>المشروع/المخزن</th>
                                    <th>المستخدم</th>
                                    <th>الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($transactions as $index => $trans): 
                                    $badge_class = '';
                                    switch($trans['trans_type']) {
                                        case 'in': $badge_class = 'badge-in'; break;
                                        case 'out': $badge_class = 'badge-out'; break;
                                        case 'issue': $badge_class = 'badge-issue'; break;
                                        case 'return': $badge_class = 'badge-return'; break;
                                        case 'transfer': $badge_class = 'badge-transfer'; break;
                                    }
                                    
                                    $location_info = '';
                                    if ($trans['trans_type'] == 'transfer') {
                                        $location_info = $trans['from_warehouse_name'] . ' → ' . $trans['to_warehouse_name'];
                                    } elseif ($trans['project_name']) {
                                        $location_info = $trans['project_name'];
                                    } else {
                                        $location_info = '---';
                                    }
                                ?>
                                <tr onclick="window.location.href='transaction_details.php?id=<?php echo $trans['trans_id']; ?>'" style="cursor: pointer;">
                                    <td><?php echo $offset + $index + 1; ?></td>
                                    <td>
                                        <span class="transaction-id">#<?php echo str_pad($trans['trans_id'], 6, '0', STR_PAD_LEFT); ?></span>
                                    </td>
                                    <td>
                                        <?php echo date('Y/m/d', strtotime($trans['trans_date'])); ?><br>
                                        <small class="text-muted"><?php echo date('H:i', strtotime($trans['trans_date'])); ?></small>
                                    </td>
                                    <td>
                                        <span class="badge transaction-badge <?php echo $badge_class; ?>">
                                            <?php echo $trans_type_names[$trans['trans_type']]; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if($trans['contact_name']): ?>
                                        <a href="contact_details.php?id=<?php echo $trans['contact_id']; ?>" class="text-decoration-none" onclick="event.stopPropagation()">
                                            <?php echo htmlspecialchars($trans['contact_name']); ?>
                                        </a>
                                        <?php else: ?>
                                        <span class="text-muted">---</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-secondary">
                                            <?php echo $trans['items_count']; ?> صنف
                                        </span>
                                    </td>
                                    <td>
                                        <span class="<?php echo in_array($trans['trans_type'], ['in', 'return']) ? 'amount-positive' : 'amount-negative'; ?>">
                                            <?php echo number_format($trans['total_amount'], 2); ?>
                                            <small>ج.م</small>
                                        </span>
                                    </td>
                                    <td>
                                        <?php echo htmlspecialchars($location_info); ?>
                                    </td>
                                    <td>
                                        <small><?php echo $trans['user_name'] ?? '---'; ?></small>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm action-buttons" onclick="event.stopPropagation()">
                                            <a href="transaction_details.php?id=<?php echo $trans['trans_id']; ?>" 
                                               class="btn btn-outline-info" title="عرض التفاصيل">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                            <button class="btn btn-outline-danger" 
                                                    onclick="deleteTransaction(<?php echo $trans['trans_id']; ?>)" 
                                                    title="حذف">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- الترقيم -->
                    <?php if($total_pages > 1): ?>
                    <div class="d-flex justify-content-center mt-4">
                        <nav aria-label="Page navigation">
                            <ul class="pagination">
                                <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>">
                                        <i class="bi bi-chevron-right"></i>
                                    </a>
                                </li>
                                
                                <?php for($i = 1; $i <= $total_pages; $i++): ?>
                                    <?php if($i == 1 || $i == $total_pages || ($i >= $page - 2 && $i <= $page + 2)): ?>
                                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>">
                                            <?php echo $i; ?>
                                        </a>
                                    </li>
                                    <?php elseif($i == $page - 3 || $i == $page + 3): ?>
                                    <li class="page-item disabled">
                                        <span class="page-link">...</span>
                                    </li>
                                    <?php endif; ?>
                                <?php endfor; ?>
                                
                                <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>">
                                        <i class="bi bi-chevron-left"></i>
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <?php endif; ?>
                    
                    <?php else: ?>
                    <div class="text-center py-5">
                        <i class="bi bi-arrow-left-right display-1 text-muted"></i>
                        <h5 class="mt-3">لا توجد حركات</h5>
                        <p class="text-muted">
                            <?php if(!empty($search) || !empty($trans_type) || !empty($contact_id) || !empty($project_id) || !empty($warehouse_id) || !empty($start_date) || !empty($end_date)): ?>
                            لم يتم العثور على حركات تطابق معايير البحث
                            <?php else: ?>
                            لم يتم تسجيل أي حركات في النظام حتى الآن
                            <?php endif; ?>
                        </p>
                        <div class="mt-4">
                            <a href="add_transaction.php" class="btn btn-primary">
                                <i class="bi bi-plus-circle me-1"></i>إضافة أول حركة
                            </a>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- الفوتر -->
    <?php include 'includes/footer.php'; ?>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- الاسكريبتات العامة -->
    <?php include 'includes/scripts.php'; ?>
    
    <script>
    function deleteTransaction(id) {
        if(confirm(`هل أنت متأكد من حذف هذه الحركة؟`)) {
            window.location.href = `delete_transaction.php?id=${id}`;
        }
    }
    
    function exportToExcel() {
        const params = new URLSearchParams(window.location.search);
        params.set('export', 'excel');
        window.open(`export_transactions.php?${params.toString()}`, '_blank');
    }
    
    document.addEventListener('DOMContentLoaded', function() {
        // تحديث التواريخ تلقائياً
        const endDate = document.querySelector('input[name="end_date"]');
        const startDate = document.querySelector('input[name="start_date"]');
        
        if (endDate && !endDate.value) {
            endDate.value = new Date().toISOString().split('T')[0];
        }
        
        if (startDate && !startDate.value) {
            const oneMonthAgo = new Date();
            oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
            startDate.value = oneMonthAgo.toISOString().split('T')[0];
        }
    });
    </script>
</body>
</html>