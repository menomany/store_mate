<?php
session_start();
require_once 'includes/db_connection.php';
require_once 'includes/auth_check.php';

$page_title = "الإعدادات";

// جلب إعدادات الشركة
$stmt = $pdo->query("SELECT * FROM company_profile WHERE id = 1");
$company = $stmt->fetch() ?: [];

// معالجة حفظ الإعدادات
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_company'])) {
    $company_name = $_POST['company_name'];
    $tax_number = $_POST['tax_number'] ?? '';
    $commercial_register = $_POST['commercial_register'] ?? '';
    $address = $_POST['address'] ?? '';
    $phone_1 = $_POST['phone_1'] ?? '';
    $phone_2 = $_POST['phone_2'] ?? '';
    $email = $_POST['email'] ?? '';
    $currency_name = $_POST['currency_name'] ?? 'EGP';
    
    if(empty($company)) {
        $stmt = $pdo->prepare("INSERT INTO company_profile 
            (company_name, tax_number, commercial_register, address, phone_1, phone_2, email, currency_name) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $company_name, $tax_number, $commercial_register, $address, 
            $phone_1, $phone_2, $email, $currency_name
        ]);
    } else {
        $stmt = $pdo->prepare("UPDATE company_profile SET 
            company_name = ?, tax_number = ?, commercial_register = ?, 
            address = ?, phone_1 = ?, phone_2 = ?, email = ?, currency_name = ? 
            WHERE id = 1");
        $stmt->execute([
            $company_name, $tax_number, $commercial_register, $address, 
            $phone_1, $phone_2, $email, $currency_name
        ]);
    }
    
    // إعادة تحميل بيانات الشركة
    $stmt = $pdo->query("SELECT * FROM company_profile WHERE id = 1");
    $company = $stmt->fetch();
    
    $success_message = "تم حفظ الإعدادات بنجاح";
}

// معالجة رفع الشعار
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['logo'])) {
    $upload_dir = 'assets/images/';
    $file_name = time() . '_' . basename($_FILES['logo']['name']);
    $target_file = $upload_dir . $file_name;
    
    if(move_uploaded_file($_FILES['logo']['tmp_name'], $target_file)) {
        $stmt = $pdo->prepare("UPDATE company_profile SET logo_path = ? WHERE id = 1");
        $stmt->execute([$file_name]);
        $success_message = "تم رفع الشعار بنجاح";
    } else {
        $error_message = "حدث خطأ أثناء رفع الشعار";
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - StoreMate</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4" style="padding-top: 20px;">
                <h2 class="mb-4"><i class="bi bi-gear me-2"></i>إعدادات النظام</h2>

                <!-- رسائل التنبيه -->
                <?php if(isset($success_message)): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle me-2"></i>
                    <?php echo $success_message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php endif; ?>
                
                <?php if(isset($error_message)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle me-2"></i>
                    <?php echo $error_message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php endif; ?>

                <!-- تبادل الإعدادات -->
                <div class="row mt-3">
                    <div class="col-md-3">
                        <div class="list-group">
                            <a href="#company" class="list-group-item list-group-item-action active" 
                               data-bs-toggle="tab">معلومات الشركة</a>
                            <a href="#users" class="list-group-item list-group-item-action" 
                               data-bs-toggle="tab">المستخدمون</a>
                            <a href="#backup" class="list-group-item list-group-item-action" 
                               data-bs-toggle="tab">النسخ الاحتياطي</a>
                        </div>
                    </div>
                    
                    <div class="col-md-9">
                        <div class="tab-content">
                            <!-- معلومات الشركة -->
                            <div class="tab-pane fade show active" id="company">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title mb-4">معلومات الشركة</h5>
                                        
                                        <!-- عرض الشعار -->
                                        <div class="text-center mb-4">
                                            <?php if(!empty($company['logo_path'])): ?>
                                            <img src="assets/images/<?php echo htmlspecialchars($company['logo_path']); ?>" 
                                                 alt="شعار الشركة" class="img-fluid rounded-circle" style="max-height: 150px;">
                                            <?php else: ?>
                                            <div class="bg-light rounded-circle d-inline-flex align-items-center justify-content-center" 
                                                 style="width: 150px; height: 150px;">
                                                <i class="bi bi-building display-4 text-muted"></i>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <!-- نموذج رفع الشعار -->
                                        <form method="POST" enctype="multipart/form-data" class="mb-4">
                                            <div class="input-group">
                                                <input type="file" class="form-control" name="logo" accept="image/*">
                                                <button type="submit" class="btn btn-primary">رفع شعار جديد</button>
                                            </div>
                                            <small class="text-muted">الحجم الأمثل: 500x500 بكسل</small>
                                        </form>
                                        
                                        <!-- نموذج معلومات الشركة -->
                                        <form method="POST">
                                            <input type="hidden" name="save_company">
                                            
                                            <div class="row">
                                                <div class="col-md-6 mb-3">
                                                    <label class="form-label">اسم الشركة *</label>
                                                    <input type="text" class="form-control" name="company_name" 
                                                           value="<?php echo htmlspecialchars($company['company_name'] ?? ''); ?>" required>
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label class="form-label">الرقم الضريبي</label>
                                                    <input type="text" class="form-control" name="tax_number" 
                                                           value="<?php echo htmlspecialchars($company['tax_number'] ?? ''); ?>">
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label class="form-label">السجل التجاري</label>
                                                    <input type="text" class="form-control" name="commercial_register" 
                                                           value="<?php echo htmlspecialchars($company['commercial_register'] ?? ''); ?>">
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label class="form-label">العملة</label>
                                                    <input type="text" class="form-control" name="currency_name" 
                                                           value="<?php echo htmlspecialchars($company['currency_name'] ?? 'EGP'); ?>">
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label class="form-label">الهاتف 1</label>
                                                    <input type="text" class="form-control" name="phone_1" 
                                                           value="<?php echo htmlspecialchars($company['phone_1'] ?? ''); ?>">
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label class="form-label">الهاتف 2</label>
                                                    <input type="text" class="form-control" name="phone_2" 
                                                           value="<?php echo htmlspecialchars($company['phone_2'] ?? ''); ?>">
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label class="form-label">البريد الإلكتروني</label>
                                                    <input type="email" class="form-control" name="email" 
                                                           value="<?php echo htmlspecialchars($company['email'] ?? ''); ?>">
                                                </div>
                                                <div class="col-md-12 mb-3">
                                                    <label class="form-label">العنوان</label>
                                                    <textarea class="form-control" name="address" rows="3"><?php echo htmlspecialchars($company['address'] ?? ''); ?></textarea>
                                                </div>
                                            </div>
                                            
                                            <button type="submit" class="btn btn-primary">
                                                <i class="bi bi-save me-1"></i> حفظ التغييرات
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- المستخدمون -->
                            <div class="tab-pane fade" id="users">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-center mb-4">
                                            <h5 class="card-title mb-0">إدارة المستخدمين</h5>
                                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addUserModal">
                                                <i class="bi bi-plus-circle me-1"></i>إضافة مستخدم
                                            </button>
                                        </div>
                                        
                                        <div class="table-responsive">
                                            <table class="table table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>اسم المستخدم</th>
                                                        <th>الاسم الكامل</th>
                                                        <th>الدور</th>
                                                        <th>الإجراءات</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $users = $pdo->query("SELECT * FROM users ORDER BY id")->fetchAll();
                                                    foreach($users as $index => $user):
                                                    ?>
                                                    <tr>
                                                        <td><?php echo $index + 1; ?></td>
                                                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                                                        <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                                                        <td>
                                                            <span class="badge bg-<?php echo $user['role'] == 'admin' ? 'danger' : 'primary'; ?>">
                                                                <?php echo $user['role'] == 'admin' ? 'مدير' : 'مستخدم'; ?>
                                                            </span>
                                                        </td>
                                                        <td>
                                                            <div class="btn-group btn-group-sm">
                                                                <button class="btn btn-outline-warning" 
                                                                        onclick="editUser(<?php echo $user['id']; ?>)">
                                                                    <i class="bi bi-pencil"></i>
                                                                </button>
                                                                <?php if($user['id'] != $_SESSION['user_id']): ?>
                                                                <button class="btn btn-outline-danger" 
                                                                        onclick="deleteUser(<?php echo $user['id']; ?>, '<?php echo htmlspecialchars($user['username']); ?>')">
                                                                    <i class="bi bi-trash"></i>
                                                                </button>
                                                                <?php endif; ?>
                                                                <button class="btn btn-outline-info" 
                                                                        onclick="resetPassword(<?php echo $user['id']; ?>, '<?php echo htmlspecialchars($user['username']); ?>')">
                                                                    <i class="bi bi-key"></i>
                                                                </button>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- النسخ الاحتياطي -->
                            <div class="tab-pane fade" id="backup">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title mb-4">النسخ الاحتياطي</h5>
                                        
                                        <div class="row">
                                            <div class="col-md-6 mb-4">
                                                <div class="card text-center h-100">
                                                    <div class="card-body">
                                                        <i class="bi bi-download display-4 text-primary mb-3"></i>
                                                        <h5>نسخ احتياطي</h5>
                                                        <p class="text-muted">قم بإنشاء نسخة احتياطية من قاعدة البيانات</p>
                                                        <button class="btn btn-primary" onclick="backupDatabase()">
                                                            <i class="bi bi-database me-1"></i> إنشاء نسخة احتياطية
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-6 mb-4">
                                                <div class="card text-center h-100">
                                                    <div class="card-body">
                                                        <i class="bi bi-upload display-4 text-success mb-3"></i>
                                                        <h5>استعادة</h5>
                                                        <p class="text-muted">استعادة قاعدة البيانات من نسخة احتياطية</p>
                                                        <form method="POST" enctype="multipart/form-data">
                                                            <div class="input-group mb-3">
                                                                <input type="file" class="form-control" name="backup_file" accept=".sql">
                                                                <button type="submit" class="btn btn-success" name="restore_backup">
                                                                    <i class="bi bi-arrow-clockwise me-1"></i> استعادة
                                                                </button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- مودال إضافة مستخدم -->
    <div class="modal fade" id="addUserModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">إضافة مستخدم جديد</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form action="api/save_user.php" method="POST" id="userForm">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">اسم المستخدم *</label>
                            <input type="text" class="form-control" name="username" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">الاسم الكامل *</label>
                            <input type="text" class="form-control" name="full_name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">كلمة المرور *</label>
                            <input type="password" class="form-control" name="password" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">تأكيد كلمة المرور *</label>
                            <input type="password" class="form-control" name="confirm_password" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">الدور *</label>
                            <select class="form-select" name="role" required>
                                <option value="user">مستخدم</option>
                                <option value="admin">مدير</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary">حفظ</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    function editUser(id) {
        window.location.href = 'edit_user.php?id=' + id;
    }

    function deleteUser(id, username) {
        if(confirm(`هل أنت متأكد من حذف المستخدم "${username}"؟`)) {
            fetch(`api/delete_user.php?id=${id}`, {
                method: 'DELETE'
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    alert('تم الحذف بنجاح');
                    window.location.reload();
                } else {
                    alert(data.message || 'حدث خطأ أثناء الحذف');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('حدث خطأ في الاتصال');
            });
        }
    }

    function resetPassword(id, username) {
        const newPassword = prompt(`الرجاء إدخال كلمة مرور جديدة للمستخدم "${username}":`);
        if(newPassword && newPassword.length >= 6) {
            fetch('api/reset_password.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    user_id: id,
                    new_password: newPassword
                })
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    alert('تم تغيير كلمة المرور بنجاح');
                } else {
                    alert(data.message || 'حدث خطأ أثناء تغيير كلمة المرور');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('حدث خطأ في الاتصال');
            });
        }
    }

    function backupDatabase() {
        if(confirm('هل تريد إنشاء نسخة احتياطية من قاعدة البيانات؟')) {
            window.location.href = 'api/backup_database.php';
        }
    }

    // تفعيل تبويبات الإعدادات
    const triggerTabList = document.querySelectorAll('.list-group-item');
    triggerTabList.forEach(triggerEl => {
        const tabTrigger = new bootstrap.Tab(triggerEl);
        triggerEl.addEventListener('click', event => {
            event.preventDefault();
            tabTrigger.show();
        });
    });

    // معالجة نموذج إضافة المستخدم
    document.getElementById('userForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const password = this.querySelector('[name="password"]').value;
        const confirmPassword = this.querySelector('[name="confirm_password"]').value;
        
        if(password !== confirmPassword) {
            alert('كلمات المرور غير متطابقة');
            return;
        }
        
        if(password.length < 6) {
            alert('كلمة المرور يجب أن تكون على الأقل 6 أحرف');
            return;
        }
        
        const formData = new FormData(this);
        
        fetch('api/save_user.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                alert(data.message);
                window.location.reload();
            } else {
                alert(data.message || 'حدث خطأ أثناء الحفظ');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('حدث خطأ في الاتصال');
        });
    });
    </script>
</body>
</html>