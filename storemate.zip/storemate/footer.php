<!-- footer.php - تذييل الصفحة المشترك -->
<footer class="footer fade-in mt-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h6>StoreMate</h6>
                <p class="mb-0">رفيقك الذكي لإدارة المخزون © <?php echo date('Y'); ?></p>
            </div>
            <div class="col-md-6 text-md-end">
                <p class="mb-0">
                    <i class="bi bi-cpu me-1"></i> إصدار 1.2.0
                    <span class="mx-2">|</span>
                    <i class="bi bi-server me-1"></i> آخر تحديث: <?php echo date('Y-m-d H:i'); ?>
                </p>
            </div>
        </div>
    </div>
</footer>