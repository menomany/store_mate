// script.js - الملف الرئيسي للجافاسكريبت

// تهيئة أدوات التلميح
document.addEventListener('DOMContentLoaded', function() {
    // أدوات التلميح
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // البحث السريع
    const searchInput = document.querySelector('.search-box input');
    if(searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const query = this.value.trim();
                if (query.length > 0) {
                    window.location.href = `search.php?q=${encodeURIComponent(query)}`;
                }
            }
        });
    }
});

// وظيفة إظهار/إخفاء السايدبار
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    if(window.innerWidth < 768) {
        sidebar.classList.toggle('d-none');
        sidebar.classList.toggle('d-block');
    }
}

// وظائف CRUD مشتركة
function confirmDelete(itemType, itemName, deleteUrl, successCallback) {
    if(confirm(`هل أنت متأكد من حذف ${itemType} "${itemName}"؟`)) {
        fetch(deleteUrl, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                alert('تم الحذف بنجاح');
                if(successCallback) successCallback();
            } else {
                alert(data.message || 'حدث خطأ أثناء الحذف');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('حدث خطأ في الاتصال');
        });
    }
}

// معالجة النماذج المشتركة
function handleFormSubmit(formId, submitUrl, successCallback) {
    const form = document.getElementById(formId);
    if(form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch(submitUrl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    alert(data.message);
                    if(successCallback) successCallback();
                } else {
                    alert(data.message || 'حدث خطأ أثناء الحفظ');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('حدث خطأ في الاتصال');
            });
        });
    }
}