<?php
// template.php - قالب أساسي لجميع الصفحات
session_start();
require_once 'includes/db_connection.php';
require_once 'includes/auth_check.php';

// يجب تعريف $page_title في كل صفحة
if(!isset($page_title)) {
    $page_title = "StoreMate";
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - StoreMate</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- الخط العربي -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    <!-- CSS المخصص -->
    <link rel="stylesheet" href="style.css">
    <?php if(isset($extra_css)) echo $extra_css; ?>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php include 'sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4" style="padding-top: 20px;">
                <!-- شريط التنقل العلوي -->
                <?php include 'header.php'; ?>
                
                <!-- محتوى الصفحة -->
                <?php echo $content ?? ''; ?>
            </main>
        </div>
        
        <!-- التذييل -->
        <?php include 'footer.php'; ?>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- JS المخصص -->
    <script src="script.js"></script>
    <?php if(isset($extra_js)) echo $extra_js; ?>
</body>
</html>