<?php
session_start();

// تعريف متغيرات الجلسة إذا لم تكن موجودة
if (!isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}

require_once 'includes/db_connection.php';
require_once 'includes/auth_check.php';

$page_title = "جهات الاتصال";

// جلب جهات الاتصال مع البحث والتصفية
$search = $_GET['search'] ?? '';
$contact_type = $_GET['contact_type'] ?? '';

$query = "SELECT * FROM contacts WHERE 1=1";
$params = [];

if (!empty($search)) {
    $searchTerm = "%$search%";
    $query .= " AND (contact_name LIKE ? OR phone_number LIKE ? OR address LIKE ?)";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

if (!empty($contact_type)) {
    $query .= " AND contact_type = ?";
    $params[] = $contact_type;
}

$query .= " ORDER BY contact_name";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $contacts = $stmt->fetchAll();
} catch (PDOException $e) {
    $contacts = [];
    echo "<div class='alert alert-danger'>خطأ في جلب البيانات: " . $e->getMessage() . "</div>";
}

// إحصائيات
$stats = [
    'total_contacts' => count($contacts),
    'suppliers_count' => 0,
    'customers_count' => 0,
    'contractors_count' => 0
];

foreach($contacts as $contact) {
    switch($contact['contact_type']) {
        case 'supplier':
            $stats['suppliers_count']++;
            break;
        case 'customer':
            $stats['customers_count']++;
            break;
        case 'contractor':
            $stats['contractors_count']++;
            break;
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - StoreMate</title>
    
    <!-- Bootstrap CSS مع نسخة احتياطية محلية -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.rtl.min.css" 
          onerror="this.onerror=null;this.href='assets/css/bootstrap.min.css';">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    
    <!-- الخط العربي -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    
    <!-- الأنماط العامة -->
    <?php include 'includes/styles.php'; ?>
    
    <style>
        .content-area {
            min-height: 80vh;
        }
        
        .stat-value {
            font-size: 1.8rem;
            font-weight: bold;
        }
        
        .stat-label {
            font-size: 0.9rem;
            color: #6c757d;
        }
        
        .contact-badge {
            font-size: 0.75rem;
            padding: 0.25rem 0.5rem;
        }
        
        .contact-type-supplier {
            background-color: #e3f2fd;
            color: #1976d2;
        }
        
        .contact-type-customer {
            background-color: #e8f5e9;
            color: #388e3c;
        }
        
        .contact-type-contractor {
            background-color: #fff3e0;
            color: #f57c00;
        }
        
        .balance-positive {
            color: #27ae60;
            font-weight: bold;
        }
        
        .balance-negative {
            color: #e74c3c;
            font-weight: bold;
        }
        
        .balance-zero {
            color: #7f8c8d;
        }
        
        .action-buttons .btn {
            min-width: 40px;
        }
        
        .contact-card {
            transition: all 0.3s ease;
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            margin-bottom: 15px;
        }
        
        .contact-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .contact-header {
            border-bottom: 1px solid #f0f0f0;
            padding-bottom: 10px;
            margin-bottom: 10px;
        }
        
        .contact-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1.2rem;
        }
    </style>
</head>
<body>
    <!-- السايدبار -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- الشريط العلوي -->
        <?php include 'includes/header.php'; ?>
        
        <!-- بطاقة الترحيب -->
        <div class="welcome-card fade-in">
            <div class="container p-4 position-relative">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h2 class="mb-2">إدارة جهات الاتصال</h2>
                        <p class="mb-0 opacity-75">إدارة وتتبع جميع الموردين والعملاء والمقاولين</p>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <button class="btn btn-light" data-bs-toggle="modal" data-bs-target="#addContactModal">
                            <i class="bi bi-person-plus me-1"></i>إضافة جهة اتصال
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- بطاقات الإحصائيات -->
        <div class="row mb-4 fade-in">
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card products h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">إجمالي جهات الاتصال</h6>
                                <h3 class="mb-0 stat-value"><?php echo $stats['total_contacts']; ?></h3>
                                <small class="text-primary stat-label">جهة اتصال في النظام</small>
                            </div>
                            <div class="stat-icon products">
                                <i class="bi bi-people"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card warning h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">الموردين</h6>
                                <h3 class="mb-0 stat-value"><?php echo $stats['suppliers_count']; ?></h3>
                                <small class="text-warning stat-label">مورد لتوريد المنتجات</small>
                            </div>
                            <div class="stat-icon warning">
                                <i class="bi bi-truck"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card info h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">العملاء</h6>
                                <h3 class="mb-0 stat-value"><?php echo $stats['customers_count']; ?></h3>
                                <small class="text-info stat-label">عميل لشراء المنتجات</small>
                            </div>
                            <div class="stat-icon info">
                                <i class="bi bi-person-check"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card success h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">المقاولين</h6>
                                <h3 class="mb-0 stat-value"><?php echo $stats['contractors_count']; ?></h3>
                                <small class="text-success stat-label">مقاول للمشاريع</small>
                            </div>
                            <div class="stat-icon success">
                                <i class="bi bi-briefcase"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      
        <!-- فلترة البحث -->
        <div class="card mb-4 fade-in">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-5">
                        <input type="text" class="form-control" name="search" placeholder="بحث بالاسم أو الهاتف أو العنوان" 
                               value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="col-md-4">
                        <select class="form-select" name="contact_type">
                            <option value="">كل الأنواع</option>
                            <option value="supplier" <?php echo ($contact_type == 'supplier') ? 'selected' : ''; ?>>مورد</option>
                            <option value="customer" <?php echo ($contact_type == 'customer') ? 'selected' : ''; ?>>عميل</option>
                            <option value="contractor" <?php echo ($contact_type == 'contractor') ? 'selected' : ''; ?>>مقاول</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-search"></i> بحث
                        </button>
                        <?php if(!empty($search) || !empty($contact_type)): ?>
                        <a href="contacts.php" class="btn btn-outline-secondary w-100 mt-2">
                            <i class="bi bi-x-circle"></i> مسح الفلاتر
                        </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- عرض جهات الاتصال -->
        <div class="dashboard-table fade-in">
            <div class="card">
                <div class="card-body">
                    <?php if(count($contacts) > 0): ?>
                    <!-- طريقة العرض الجدولي -->
                    <div class="d-none d-md-block">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>اسم جهة الاتصال</th>
                                        <th>النوع</th>
                                        <th>رقم الهاتف</th>
                                        <th>العنوان</th>
                                        <th>رصيد أولي</th>
                                        <th>الرصيد الحالي</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($contacts as $index => $contact): 
                                        $balance_class = '';
                                        if ($contact['current_balance'] > 0) {
                                            $balance_class = 'balance-positive';
                                        } elseif ($contact['current_balance'] < 0) {
                                            $balance_class = 'balance-negative';
                                        } else {
                                            $balance_class = 'balance-zero';
                                        }
                                        
                                        // نوع جهة الاتصال
                                        $type_class = '';
                                        $type_text = '';
                                        switch($contact['contact_type']) {
                                            case 'supplier':
                                                $type_class = 'contact-type-supplier';
                                                $type_text = 'مورد';
                                                break;
                                            case 'customer':
                                                $type_class = 'contact-type-customer';
                                                $type_text = 'عميل';
                                                break;
                                            case 'contractor':
                                                $type_class = 'contact-type-contractor';
                                                $type_text = 'مقاول';
                                                break;
                                        }
                                    ?>
                                    <tr>
                                        <td><?php echo $index + 1; ?></td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($contact['contact_name']); ?></strong>
                                        </td>
                                        <td>
                                            <span class="badge contact-badge <?php echo $type_class; ?>">
                                                <?php echo $type_text; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if($contact['phone_number']): ?>
                                            <a href="tel:<?php echo htmlspecialchars($contact['phone_number']); ?>" class="text-decoration-none">
                                                <i class="bi bi-telephone me-1"></i>
                                                <?php echo htmlspecialchars($contact['phone_number']); ?>
                                            </a>
                                            <?php else: ?>
                                            <span class="text-muted">---</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php echo $contact['address'] ? htmlspecialchars(substr($contact['address'], 0, 30)) . (strlen($contact['address']) > 30 ? '...' : '') : '---'; ?>
                                        </td>
                                        <td>
                                            <?php echo number_format($contact['initial_balance'], 2); ?>
                                        </td>
                                        <td>
                                            <span class="<?php echo $balance_class; ?>">
                                                <?php echo number_format($contact['current_balance'], 2); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm action-buttons">
                                                <button class="btn btn-outline-info" 
                                                        onclick="viewContact(<?php echo $contact['contact_id']; ?>)"
                                                        title="عرض"
                                                        data-bs-toggle="tooltip">
                                                    <i class="bi bi-eye"></i>
                                                </button>
                                                <button class="btn btn-outline-warning"
                                                        onclick="editContact(<?php echo $contact['contact_id']; ?>)"
                                                        title="تعديل"
                                                        data-bs-toggle="tooltip">
                                                    <i class="bi bi-pencil"></i>
                                                </button>
                                                <button class="btn btn-outline-danger" 
                                                        onclick="deleteContact(<?php echo $contact['contact_id']; ?>, '<?php echo htmlspecialchars($contact['contact_name']); ?>')"
                                                        title="حذف"
                                                        data-bs-toggle="tooltip">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <!-- طريقة العرض على شكل بطاقات للشاشات الصغيرة -->
                    <div class="d-md-none">
                        <div class="row">
                            <?php foreach($contacts as $index => $contact): 
                                $balance_class = '';
                                if ($contact['current_balance'] > 0) {
                                    $balance_class = 'balance-positive';
                                } elseif ($contact['current_balance'] < 0) {
                                    $balance_class = 'balance-negative';
                                } else {
                                    $balance_class = 'balance-zero';
                                }
                                
                                // نوع جهة الاتصال
                                $type_class = '';
                                $type_text = '';
                                switch($contact['contact_type']) {
                                    case 'supplier':
                                        $type_class = 'contact-type-supplier';
                                        $type_text = 'مورد';
                                        break;
                                    case 'customer':
                                        $type_class = 'contact-type-customer';
                                        $type_text = 'عميل';
                                        break;
                                    case 'contractor':
                                        $type_class = 'contact-type-contractor';
                                        $type_text = 'مقاول';
                                        break;
                                }
                                
                                // الحرف الأول من الاسم
                                $name_initials = mb_substr($contact['contact_name'], 0, 1, 'UTF-8');
                            ?>
                            <div class="col-12 mb-3">
                                <div class="contact-card p-3">
                                    <div class="contact-header d-flex justify-content-between align-items-center">
                                        <div class="d-flex align-items-center">
                                            <div class="contact-avatar me-3">
                                                <?php echo $name_initials; ?>
                                            </div>
                                            <div>
                                                <h5 class="mb-1"><?php echo htmlspecialchars($contact['contact_name']); ?></h5>
                                                <span class="badge contact-badge <?php echo $type_class; ?>">
                                                    <?php echo $type_text; ?>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="btn-group btn-group-sm">
                                            <button class="btn btn-outline-info btn-sm" 
                                                    onclick="viewContact(<?php echo $contact['contact_id']; ?>)">
                                                <i class="bi bi-eye"></i>
                                            </button>
                                            <button class="btn btn-outline-warning btn-sm"
                                                    onclick="editContact(<?php echo $contact['contact_id']; ?>)">
                                                <i class="bi bi-pencil"></i>
                                            </button>
                                            <button class="btn btn-outline-danger btn-sm" 
                                                    onclick="deleteContact(<?php echo $contact['contact_id']; ?>, '<?php echo htmlspecialchars($contact['contact_name']); ?>')">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-6">
                                            <small class="text-muted d-block">رقم الهاتف</small>
                                            <?php if($contact['phone_number']): ?>
                                            <a href="tel:<?php echo htmlspecialchars($contact['phone_number']); ?>" class="text-decoration-none">
                                                <?php echo htmlspecialchars($contact['phone_number']); ?>
                                            </a>
                                            <?php else: ?>
                                            <span class="text-muted">---</span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-6">
                                            <small class="text-muted d-block">الرصيد الحالي</small>
                                            <span class="<?php echo $balance_class; ?>">
                                                <?php echo number_format($contact['current_balance'], 2); ?>
                                            </span>
                                        </div>
                                    </div>
                                    
                                    <?php if($contact['address']): ?>
                                    <div class="mt-2">
                                        <small class="text-muted d-block">العنوان</small>
                                        <small><?php echo htmlspecialchars($contact['address']); ?></small>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <?php else: ?>
                    <div class="text-center py-5">
                        <i class="bi bi-people display-1 text-muted"></i>
                        <h5 class="mt-3">لا توجد جهات اتصال</h5>
                        <p class="text-muted">ابدأ بإضافة جهات اتصال جديدة إلى النظام</p>
                        <button class="btn btn-primary mt-3" data-bs-toggle="modal" data-bs-target="#addContactModal">
                            <i class="bi bi-person-plus me-1"></i>إضافة أول جهة اتصال
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- الفوتر -->
    <?php include 'includes/footer.php'; ?>
    
    <!-- مودال إضافة جهة اتصال -->
    <div class="modal fade" id="addContactModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">إضافة جهة اتصال جديدة</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form action="api/save_contact.php" method="POST" id="contactForm">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">اسم جهة الاتصال *</label>
                                <input type="text" class="form-control" name="contact_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">نوع جهة الاتصال *</label>
                                <select class="form-select" name="contact_type" required>
                                    <option value="">اختر النوع</option>
                                    <option value="supplier">مورد</option>
                                    <option value="customer">عميل</option>
                                    <option value="contractor">مقاول</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">رقم الهاتف</label>
                                <input type="tel" class="form-control" name="phone_number">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">رصيد أولي</label>
                                <input type="number" class="form-control" name="initial_balance" step="0.01" value="0.00">
                                <small class="form-text text-muted">الرصيد الافتتاحي (يمكن أن يكون موجباً أو سالباً)</small>
                            </div>
                            <div class="col-12 mb-3">
                                <label class="form-label">العنوان</label>
                                <textarea class="form-control" name="address" rows="3"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary">حفظ جهة الاتصال</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- الاسكريبتات العامة -->
    <?php include 'includes/scripts.php'; ?>
    
    <script>
    // وظائف خاصة بصفحة جهات الاتصال
    function viewContact(id) {
        window.location.href = 'contact_details.php?id=' + id;
    }
    
    function editContact(id) {
        // في المستقبل يمكن إنشاء صفحة منفصلة للتعديل
        // أو استخدام مودال لتعديل البيانات
        alert('تعديل جهة الاتصال: ' + id);
        // window.location.href = 'edit_contact.php?id=' + id;
    }
    
    function deleteContact(id, name) {
        if(confirm(`هل أنت متأكد من حذف جهة الاتصال "${name}"؟`)) {
            fetch(`api/delete_contact.php?id=${id}`, {
                method: 'DELETE'
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    alert('تم الحذف بنجاح');
                    window.location.reload();
                } else {
                    alert(data.message || 'حدث خطأ أثناء الحذف');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('حدث خطأ في الاتصال');
            });
        }
    }
    
    // معالجة نموذج إضافة جهة الاتصال
    document.getElementById('contactForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        
        fetch('api/save_contact.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                alert('تم إضافة جهة الاتصال بنجاح');
                window.location.reload();
            } else {
                alert('حدث خطأ: ' + (data.message || 'غير معروف'));
            }
        })
        .catch(error => {
            alert('حدث خطأ في الاتصال بالخادم');
        });
    });
    
    // تهيئة أدوات التلميح
    document.addEventListener('DOMContentLoaded', function() {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    });
    </script>
</body>
</html>