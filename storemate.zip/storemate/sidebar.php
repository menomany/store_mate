<!-- sidebar.php - القائمة الجانبية -->
<div class="p-3">
    <!-- صورة المستخدم -->
    <div class="text-center mb-4">
        <div class="user-avatar mx-auto mb-2">
            <?php echo isset($_SESSION['full_name']) ? substr($_SESSION['full_name'], 0, 1) : 'U'; ?>
        </div>
        <h6 class="text-white mb-1"><?php echo $_SESSION['full_name'] ?? 'مستخدم'; ?></h6>
        <small class="text-light opacity-75"><?php echo $_SESSION['role'] ?? 'مستخدم'; ?></small>
    </div>
    
    <hr class="bg-light opacity-25">
    
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>" href="dashboard.php">
                <i class="bi bi-speedometer2"></i> لوحة التحكم
            </a>
        </li>
        
        <li class="nav-item mt-2">
            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'products.php' ? 'active' : ''; ?>" href="products.php">
                <i class="bi bi-box-seam"></i> الأصناف
            </a>
        </li>
        
        <li class="nav-item">
            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'categories.php' ? 'active' : ''; ?>" href="categories.php">
                <i class="bi bi-tags"></i> الفئات
            </a>
        </li>
        
        <li class="nav-item">
            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'transactions.php' ? 'active' : ''; ?>" href="transactions.php">
                <i class="bi bi-arrow-left-right"></i> الحركات
            </a>
        </li>
        
        <li class="nav-item">
            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'contacts.php' ? 'active' : ''; ?>" href="contacts.php">
                <i class="bi bi-people"></i> الجهات المتعاملة
            </a>
        </li>
        
        <li class="nav-item">
            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'projects.php' ? 'active' : ''; ?>" href="projects.php">
                <i class="bi bi-briefcase"></i> المشاريع
            </a>
        </li>
        
        <li class="nav-item">
            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'treasury.php' ? 'active' : ''; ?>" href="treasury.php">
                <i class="bi bi-cash-stack"></i> الخزينة
            </a>
        </li>
        
        <li class="nav-item">
            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'tools.php' ? 'active' : ''; ?>" href="tools.php">
                <i class="bi bi-tools"></i> الأدوات والمعدات
            </a>
        </li>
        
        <li class="nav-item">
            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'active' : ''; ?>" href="reports.php">
                <i class="bi bi-file-earmark-text"></i> التقارير
            </a>
        </li>
        
        <hr class="bg-light opacity-25 my-3">
        
        <li class="nav-item">
            <small class="text-light opacity-75 ps-3">إدارة النظام</small>
        </li>
        
        <li class="nav-item">
            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>" href="settings.php">
                <i class="bi bi-gear"></i> الإعدادات
            </a>
        </li>
        
        <li class="nav-item">
            <a class="nav-link text-danger" href="logout.php">
                <i class="bi bi-box-arrow-right"></i> تسجيل الخروج
            </a>
        </li>
    </ul>
</div>