<?php
// users.php
session_start();

// تعريف متغيرات الجلسة إذا لم تكن موجودة
if (!isset($_SESSION['full_name'])) {
    $_SESSION['full_name'] = 'مستخدم النظام';
    $_SESSION['role'] = 'مدير';
}

require_once 'includes/db_connection.php';
require_once 'includes/auth_check.php';

// التحقق من صلاحيات المستخدم (فقط المدير يمكنه إدارة المستخدمين)
if ($_SESSION['role'] !== 'مدير') {
    header('Location: index.php');
    exit;
}

$page_title = "المستخدمين";

// جلب المستخدمين
$search = $_GET['search'] ?? '';
$status_filter = $_GET['status'] ?? '';

$query = "SELECT u.*, 
          DATE_FORMAT(u.last_login, '%Y-%m-%d %H:%i') as last_login_formatted,
          (SELECT COUNT(*) FROM transactions t WHERE t.user_id = u.id) as transactions_count
          FROM users u 
          WHERE 1=1";

$params = [];

if (!empty($search)) {
    $query .= " AND (u.username LIKE ? OR u.full_name LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (!empty($status_filter) && in_array($status_filter, ['active', 'inactive', 'suspended'])) {
    $query .= " AND u.status = ?";
    $params[] = $status_filter;
}

$query .= " ORDER BY u.created_at DESC";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $users = $stmt->fetchAll();
} catch (PDOException $e) {
    $users = [];
    echo "<div class='alert alert-danger'>خطأ في جلب البيانات: " . $e->getMessage() . "</div>";
}

// إحصائيات
$stats = [
    'total_users' => 0,
    'active_users' => 0,
    'inactive_users' => 0,
    'admin_users' => 0,
    'last_7_days' => 0
];

if ($users) {
    $stats['total_users'] = count($users);
    
    foreach($users as $user) {
        switch($user['status']) {
            case 'active':
                $stats['active_users']++;
                break;
            case 'inactive':
                $stats['inactive_users']++;
                break;
        }
        
        if($user['role'] === 'مدير') {
            $stats['admin_users']++;
        }
        
        // المستخدمين المضافين في آخر 7 أيام
        $created_date = strtotime($user['created_at']);
        if ($created_date >= strtotime('-7 days')) {
            $stats['last_7_days']++;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - StoreMate</title>
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.rtl.min.css" onerror="this.onerror=null;this.href='assets/css/bootstrap.min.css';">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    
    <!-- الخط العربي -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    
    <!-- الأنماط العامة -->
    <?php include 'includes/styles.php'; ?>
    
    <style>
        .user-card {
            transition: all 0.3s ease;
            border: 1px solid #dee2e6;
            border-radius: 10px;
            overflow: hidden;
        }
        
        .user-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        
        .user-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            margin: 0 auto 15px;
            color: white;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        
        .user-status {
            position: absolute;
            top: 10px;
            left: 10px;
        }
        
        .status-active { background-color: #d1e7dd; color: #0f5132; }
        .status-inactive { background-color: #fff3cd; color: #664d03; }
        .status-suspended { background-color: #f8d7da; color: #842029; }
        
        .role-badge {
            font-size: 0.75rem;
            padding: 0.25rem 0.5rem;
        }
        
        .role-admin { background-color: #dc3545; }
        .role-manager { background-color: #6f42c1; }
        .role-user { background-color: #20c997; }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
        }
        
        .last-login {
            font-size: 0.8rem;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <!-- السايدبار -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- الشريط العلوي -->
        <?php include 'includes/header.php'; ?>
        
        <!-- بطاقة الترحيب -->
        <div class="welcome-card fade-in">
            <div class="container p-4 position-relative">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h2 class="mb-2">إدارة المستخدمين</h2>
                        <p class="mb-0 opacity-75">إدارة حسابات المستخدمين والصلاحيات</p>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <button class="btn btn-light" data-bs-toggle="modal" data-bs-target="#addUserModal">
                            <i class="bi bi-person-plus me-1"></i>إضافة مستخدم
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- بطاقات الإحصائيات -->
        <div class="row mb-4 fade-in">
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card h-100 border-primary">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">إجمالي المستخدمين</h6>
                                <h3 class="mb-0 text-primary"><?php echo $stats['total_users']; ?></h3>
                                <small class="text-primary stat-label">مستخدم في النظام</small>
                            </div>
                            <div class="stat-icon bg-primary bg-opacity-10 text-primary">
                                <i class="bi bi-people"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card h-100 border-success">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">المستخدمين النشطين</h6>
                                <h3 class="mb-0 text-success"><?php echo $stats['active_users']; ?></h3>
                                <small class="text-success stat-label">يمكنهم الدخول</small>
                            </div>
                            <div class="stat-icon bg-success bg-opacity-10 text-success">
                                <i class="bi bi-person-check"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card h-100 border-warning">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">المديرين</h6>
                                <h3 class="mb-0 text-warning"><?php echo $stats['admin_users']; ?></h3>
                                <small class="text-warning stat-label">صلاحيات كاملة</small>
                            </div>
                            <div class="stat-icon bg-warning bg-opacity-10 text-warning">
                                <i class="bi bi-shield-check"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card h-100 border-info">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">مستخدمين جدد</h6>
                                <h3 class="mb-0 text-info"><?php echo $stats['last_7_days']; ?></h3>
                                <small class="text-info stat-label">خلال 7 أيام</small>
                            </div>
                            <div class="stat-icon bg-info bg-opacity-10 text-info">
                                <i class="bi bi-person-plus"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- فلترة البحث -->
        <div class="card mb-4 fade-in">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-6">
                        <input type="text" class="form-control" name="search" 
                               placeholder="بحث بالاسم، اسم المستخدم، البريد، الهاتف" 
                               value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="col-md-4">
                        <select class="form-select" name="status">
                            <option value="">جميع الحالات</option>
                            <option value="active" <?php echo $status_filter == 'active' ? 'selected' : ''; ?>>نشط</option>
                            <option value="inactive" <?php echo $status_filter == 'inactive' ? 'selected' : ''; ?>>غير نشط</option>
                            <option value="suspended" <?php echo $status_filter == 'suspended' ? 'selected' : ''; ?>>موقوف</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-search"></i> بحث
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- عرض المستخدمين -->
        <div class="dashboard-table fade-in">
            <?php if(count($users) > 0): ?>
                <div class="row">
                    <?php foreach($users as $user): 
                        $status_class = 'status-' . $user['status'];
                        $role_class = 'role-' . ($user['role'] === 'مدير' ? 'admin' : ($user['role'] === 'مدير مخازن' ? 'manager' : 'user'));
                    ?>
                    <div class="col-xl-4 col-lg-6 col-md-6 mb-4">
                        <div class="card user-card h-100">
                            <div class="user-status">
                                <span class="badge <?php echo $status_class; ?>">
                                    <?php 
                                    switch($user['status']) {
                                        case 'active': echo 'نشط'; break;
                                        case 'inactive': echo 'غير نشط'; break;
                                        case 'suspended': echo 'موقوف'; break;
                                        default: echo $user['status'];
                                    }
                                    ?>
                                </span>
                            </div>
                            
                            <div class="card-body text-center p-4">
                                <div class="user-avatar">
                                    <?php 
                                    $initials = '';
                                    $names = explode(' ', $user['full_name']);
                                    foreach($names as $name) {
                                        $initials .= strtoupper(substr($name, 0, 1));
                                    }
                                    echo substr($initials, 0, 2);
                                    ?>
                                </div>
                                
                                <h5 class="card-title mb-1">
                                    <?php echo htmlspecialchars($user['full_name']); ?>
                                </h5>
                                
                                <p class="text-muted mb-2">
                                    <small>@<?php echo htmlspecialchars($user['username']); ?></small>
                                </p>
                                
                                <div class="mb-3">
                                    <span class="badge <?php echo $role_class; ?> role-badge">
                                        <?php echo htmlspecialchars($user['role']); ?>
                                    </span>
                                </div>
                                
                                <div class="user-info mb-3">
                                    <?php if($user['email']): ?>
                                    <div class="mb-1">
                                        <i class="bi bi-envelope me-1 text-muted"></i>
                                        <small><?php echo htmlspecialchars($user['email']); ?></small>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if($user['phone']): ?>
                                    <div class="mb-1">
                                        <i class="bi bi-telephone me-1 text-muted"></i>
                                        <small><?php echo htmlspecialchars($user['phone']); ?></small>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if($user['last_login_formatted']): ?>
                                    <div class="mb-1">
                                        <i class="bi bi-clock-history me-1 text-muted"></i>
                                        <small class="last-login">آخر دخول: <?php echo $user['last_login_formatted']; ?></small>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <div class="mb-1">
                                        <i class="bi bi-arrow-left-right me-1 text-muted"></i>
                                        <small><?php echo $user['transactions_count']; ?> عملية</small>
                                    </div>
                                </div>
                                
                                <div class="btn-group w-100">
                                    <button class="btn btn-outline-info btn-sm" 
                                            onclick="viewUser(<?php echo $user['id']; ?>)"
                                            title="عرض التفاصيل">
                                        <i class="bi bi-eye"></i>
                                    </button>
                                    <button class="btn btn-outline-warning btn-sm"
                                            onclick="editUser(<?php echo $user['id']; ?>)"
                                            title="تعديل">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <?php if($user['id'] != $_SESSION['user_id'] ?? 0): ?>
                                    <button class="btn btn-outline-danger btn-sm" 
                                            onclick="deleteUser(<?php echo $user['id']; ?>, '<?php echo htmlspecialchars($user['full_name']); ?>')"
                                            title="حذف">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                    <?php else: ?>
                                    <button class="btn btn-outline-secondary btn-sm" disabled
                                            title="لا يمكن حذف حسابك">
                                        <i class="bi bi-shield-lock"></i>
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="card">
                    <div class="card-body">
                        <div class="text-center py-5">
                            <i class="bi bi-people display-1 text-muted"></i>
                            <h5 class="mt-3">لا يوجد مستخدمين</h5>
                            <p class="text-muted">ابدأ بإضافة مستخدمين جديدين للنظام</p>
                            <button class="btn btn-primary mt-3" data-bs-toggle="modal" data-bs-target="#addUserModal">
                                <i class="bi bi-person-plus me-1"></i>إضافة أول مستخدم
                            </button>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- المستخدمين الموقوفين (إن وجدت) -->
        <?php 
        $suspended_users = array_filter($users, function($user) {
            return $user['status'] == 'suspended';
        });
        
        if(count($suspended_users) > 0): ?>
        <div class="row mt-4 fade-in">
            <div class="col-12">
                <div class="dashboard-table">
                    <div class="card border-danger">
                        <div class="card-header bg-danger bg-opacity-10">
                            <h5 class="mb-0">
                                <i class="bi bi-exclamation-triangle me-2 text-danger"></i> المستخدمين الموقوفين
                                <span class="badge bg-danger"><?php echo count($suspended_users); ?></span>
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>اسم المستخدم</th>
                                            <th>الاسم الكامل</th>
                                            <th>الدور</th>
                                            <th>تاريخ الإضافة</th>
                                            <th>آخر دخول</th>
                                            <th>الإجراءات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($suspended_users as $index => $user): ?>
                                        <tr>
                                            <td><?php echo $index + 1; ?></td>
                                            <td>
                                                <strong>@<?php echo htmlspecialchars($user['username']); ?></strong>
                                            </td>
                                            <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                                            <td>
                                                <span class="badge bg-secondary">
                                                    <?php echo htmlspecialchars($user['role']); ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('Y-m-d', strtotime($user['created_at'])); ?></td>
                                            <td>
                                                <?php if($user['last_login_formatted']): ?>
                                                <span class="text-muted"><?php echo $user['last_login_formatted']; ?></span>
                                                <?php else: ?>
                                                <span class="text-muted">لم يسجل دخول</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <button class="btn btn-outline-success"
                                                            onclick="activateUser(<?php echo $user['id']; ?>)">
                                                        <i class="bi bi-check-circle me-1"></i>تفعيل
                                                    </button>
                                                    <button class="btn btn-outline-warning"
                                                            onclick="editUser(<?php echo $user['id']; ?>)">
                                                        <i class="bi bi-pencil me-1"></i>تعديل
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <!-- الفوتر -->
    <?php include 'includes/footer.php'; ?>
    
    <!-- مودال إضافة مستخدم -->
    <div class="modal fade" id="addUserModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">إضافة مستخدم جديد</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="addUserForm" method="POST">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">اسم المستخدم *</label>
                                <input type="text" class="form-control" name="username" required>
                                <div class="form-text">اسم فريد لدخول النظام</div>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">الاسم الكامل *</label>
                                <input type="text" class="form-control" name="full_name" required>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">كلمة المرور *</label>
                                <input type="password" class="form-control" name="password" required>
                                <div class="form-text">كلمة مرور قوية</div>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">تأكيد كلمة المرور *</label>
                                <input type="password" class="form-control" name="confirm_password" required>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">البريد الإلكتروني</label>
                                <input type="email" class="form-control" name="email">
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">رقم الهاتف</label>
                                <input type="tel" class="form-control" name="phone">
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">الدور *</label>
                                <select class="form-select" name="role" required>
                                    <option value="">اختر الدور</option>
                                    <option value="مدير">مدير</option>
                                    <option value="مدير مخازن">مدير مخازن</option>
                                    <option value="موظف">موظف</option>
                                    <option value="مشرف">مشرف</option>
                                </select>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">الحالة *</label>
                                <select class="form-select" name="status" required>
                                    <option value="active">نشط</option>
                                    <option value="inactive">غير نشط</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary">حفظ المستخدم</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- مودال تعديل مستخدم -->
    <div class="modal fade" id="editUserModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">تعديل المستخدم</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="editUserForm" method="POST">
                    <input type="hidden" name="user_id" id="edit_user_id">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">اسم المستخدم *</label>
                                <input type="text" class="form-control" name="username" id="edit_username" required>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">الاسم الكامل *</label>
                                <input type="text" class="form-control" name="full_name" id="edit_full_name" required>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">كلمة المرور الجديدة</label>
                                <input type="password" class="form-control" name="password">
                                <div class="form-text">اتركها فارغة للحفاظ على كلمة المرور الحالية</div>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">تأكيد كلمة المرور</label>
                                <input type="password" class="form-control" name="confirm_password">
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">البريد الإلكتروني</label>
                                <input type="email" class="form-control" name="email" id="edit_email">
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">رقم الهاتف</label>
                                <input type="tel" class="form-control" name="phone" id="edit_phone">
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">الدور *</label>
                                <select class="form-select" name="role" id="edit_role" required>
                                    <option value="مدير">مدير</option>
                                    <option value="مدير مخازن">مدير مخازن</option>
                                    <option value="موظف">موظف</option>
                                    <option value="مشرف">مشرف</option>
                                </select>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">الحالة *</label>
                                <select class="form-select" name="status" id="edit_status" required>
                                    <option value="active">نشط</option>
                                    <option value="inactive">غير نشط</option>
                                    <option value="suspended">موقوف</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle me-2"></i>
                            <small>تاريخ الإنشاء: <span id="edit_created_at"></span></small><br>
                            <small>آخر دخول: <span id="edit_last_login"></span></small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary">تحديث المستخدم</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- الاسكريبتات العامة -->
    <?php include 'includes/scripts.php'; ?>
    
    <script>
    // وظائف خاصة بصفحة المستخدمين
    
    function viewUser(id) {
        window.location.href = 'user_details.php?id=' + id;
    }
    
    function editUser(id) {
        // جلب بيانات المستخدم عبر AJAX
        fetch(`api/get_user.php?id=${id}`)
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    document.getElementById('edit_user_id').value = data.user.id;
                    document.getElementById('edit_username').value = data.user.username;
                    document.getElementById('edit_full_name').value = data.user.full_name;
                    document.getElementById('edit_email').value = data.user.email || '';
                    document.getElementById('edit_phone').value = data.user.phone || '';
                    document.getElementById('edit_role').value = data.user.role;
                    document.getElementById('edit_status').value = data.user.status;
                    document.getElementById('edit_created_at').textContent = data.user.created_at;
                    document.getElementById('edit_last_login').textContent = data.user.last_login_formatted || 'لم يسجل دخول';
                    
                    // عرض المودال
                    const modal = new bootstrap.Modal(document.getElementById('editUserModal'));
                    modal.show();
                } else {
                    alert('حدث خطأ في جلب بيانات المستخدم');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('حدث خطأ في الاتصال');
            });
    }
    
    function deleteUser(id, name) {
        if(confirm(`هل أنت متأكد من حذف المستخدم "${name}"؟\n\nملاحظة: لا يمكن التراجع عن هذا الإجراء.`)) {
            fetch(`api/delete_user.php?id=${id}`, {
                method: 'DELETE'
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    alert('تم حذف المستخدم بنجاح');
                    window.location.reload();
                } else {
                    alert(data.message || 'حدث خطأ أثناء الحذف');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('حدث خطأ في الاتصال');
            });
        }
    }
    
    function activateUser(id) {
        if(confirm('هل تريد تفعيل هذا المستخدم؟')) {
            fetch(`api/activate_user.php?id=${id}`, {
                method: 'POST'
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    alert('تم تفعيل المستخدم بنجاح');
                    window.location.reload();
                } else {
                    alert(data.message || 'حدث خطأ أثناء التفعيل');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('حدث خطأ في الاتصال');
            });
        }
    }
    
    // معالجة نموذج إضافة مستخدم
    document.getElementById('addUserForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const password = formData.get('password');
        const confirmPassword = formData.get('confirm_password');
        
        // التحقق من تطابق كلمات المرور
        if (password !== confirmPassword) {
            alert('كلمات المرور غير متطابقة');
            return;
        }
        
        // التحقق من قوة كلمة المرور
        if (password.length < 6) {
            alert('كلمة المرور يجب أن تكون 6 أحرف على الأقل');
            return;
        }
        
        fetch('api/save_user.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                alert('تم إضافة المستخدم بنجاح');
                window.location.reload();
            } else {
                alert('حدث خطأ: ' + (data.message || 'غير معروف'));
            }
        })
        .catch(error => {
            alert('حدث خطأ في الاتصال بالخادم');
        });
    });
    
    // معالجة نموذج تعديل مستخدم
    document.getElementById('editUserForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const password = formData.get('password');
        const confirmPassword = formData.get('confirm_password');
        
        // التحقق من تطابق كلمات المرور (إذا تم إدخال كلمة مرور جديدة)
        if (password && password !== confirmPassword) {
            alert('كلمات المرور غير متطابقة');
            return;
        }
        
        // التحقق من قوة كلمة المرور (إذا تم إدخال كلمة مرور جديدة)
        if (password && password.length < 6) {
            alert('كلمة المرور يجب أن تكون 6 أحرف على الأقل');
            return;
        }
        
        fetch('api/update_user.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                alert('تم تحديث المستخدم بنجاح');
                window.location.reload();
            } else {
                alert('حدث خطأ: ' + (data.message || 'غير معروف'));
            }
        })
        .catch(error => {
            alert('حدث خطأ في الاتصال بالخادم');
        });
    });
    
    // تهيئة أدوات التلميح
    document.addEventListener('DOMContentLoaded', function() {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    });
    </script>
</body>
</html>