<?php
session_start();

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

require_once 'includes/db_connection.php';
require_once 'includes/auth_check.php';

$page_title = "لوحة التحكم";

// جلب إحصائيات سريعة
try {
    // إجمالي المنتجات
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM products");
    $total_products = $stmt->fetch()['total'];
    
    // إجمالي الحركات اليوم
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM transactions WHERE DATE(trans_date) = CURDATE()");
    $today_transactions = $stmt->fetch()['total'];
    
    // إجمالي جهات الاتصال
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM contacts");
    $total_contacts = $stmt->fetch()['total'];
    
    // المنتجات منخفضة المخزون
    $stmt = $pdo->query("
        SELECT COUNT(*) as total 
        FROM products p 
        WHERE (
            COALESCE((SELECT SUM(CASE WHEN t.trans_type IN ('in', 'return') THEN td.quantity ELSE 0 END) 
            FROM transaction_details td 
            JOIN transactions t ON td.trans_id = t.trans_id 
            WHERE td.product_id = p.product_id), 0)
            -
            COALESCE((SELECT SUM(CASE WHEN t.trans_type IN ('out', 'issue') THEN td.quantity ELSE 0 END) 
            FROM transaction_details td 
            JOIN transactions t ON td.trans_id = t.trans_id 
            WHERE td.product_id = p.product_id), 0)
        ) <= p.min_stock_level
    ");
    $low_stock = $stmt->fetch()['total'];
    
    // آخر 5 حركات
    $stmt = $pdo->query("
        SELECT t.*, c.contact_name, 
               CASE t.trans_type 
                   WHEN 'in' THEN 'وارد'
                   WHEN 'out' THEN 'صادر'
                   WHEN 'issue' THEN 'صرف'
                   WHEN 'return' THEN 'مرتجع'
                   WHEN 'transfer' THEN 'تحويل'
               END as trans_type_arabic
        FROM transactions t
        LEFT JOIN contacts c ON t.contact_id = c.contact_id
        ORDER BY t.trans_date DESC
        LIMIT 5
    ");
    $recent_transactions = $stmt->fetchAll();
    
    // المنتجات الأكثر حركة (الأعلى في الصادر)
    $stmt = $pdo->query("
        SELECT p.product_name, 
               SUM(CASE WHEN t.trans_type IN ('out', 'issue') THEN td.quantity ELSE 0 END) as total_out
        FROM products p
        LEFT JOIN transaction_details td ON p.product_id = td.product_id
        LEFT JOIN transactions t ON td.trans_id = t.trans_id
        GROUP BY p.product_id
        ORDER BY total_out DESC
        LIMIT 5
    ");
    $top_products = $stmt->fetchAll();
    
} catch (PDOException $e) {
    // في حالة خطأ، نعطي قيم افتراضية
    $total_products = 0;
    $today_transactions = 0;
    $total_contacts = 0;
    $low_stock = 0;
    $recent_transactions = [];
    $top_products = [];
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - StoreMate</title>
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.rtl.min.css" 
          onerror="this.onerror=null;this.href='assets/css/bootstrap.min.css';">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/css/bootstrap-icons.css">
    
    <!-- الخط العربي -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    
    <!-- الأنماط العامة -->
    <?php include 'includes/styles.php'; ?>
    
    <style>
        .dashboard-card {
            border-radius: 15px;
            border: none;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            height: 100%;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
        }
        
        .bg-products { background: linear-gradient(135deg, #4dabf7, #339af0); }
        .bg-transactions { background: linear-gradient(135deg, #ff922b, #fd7e14); }
        .bg-contacts { background: linear-gradient(135deg, #51cf66, #40c057); }
        .bg-warning { background: linear-gradient(135deg, #ffd43b, #fab005); }
        
        .quick-action-btn {
            border-radius: 10px;
            padding: 15px;
            text-align: center;
            border: none;
            background: white;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            height: 100%;
        }
        
        .quick-action-btn:hover {
            background: #f8f9fa;
            transform: translateY(-3px);
            box-shadow: 0 6px 18px rgba(0,0,0,0.1);
        }
        
        .quick-action-btn i {
            font-size: 24px;
            margin-bottom: 10px;
        }
        
        .recent-table th {
            background-color: #f8f9fa;
            border-bottom: 2px solid #dee2e6;
        }
    </style>
</head>
<body>
    <!-- السايدبار -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- الشريط العلوي -->
        <?php include 'includes/header.php'; ?>
        
        <!-- بطاقة الترحيب -->
        <div class="welcome-card fade-in">
            <div class="container p-4 position-relative">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h2 class="mb-2">مرحباً <?php echo $_SESSION['full_name']; ?></h2>
                        <p class="mb-0 opacity-75">إحصائيات وأداء متجرك في لمحة</p>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <span class="badge bg-light text-dark fs-6">
                            <i class="bi bi-calendar me-1"></i>
                            <?php echo date('Y-m-d'); ?>
                        </span>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- بطاقات الإحصائيات -->
        <div class="row mb-4 fade-in">
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card dashboard-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">إجمالي الأصناف</h6>
                                <h3 class="mb-0"><?php echo $total_products; ?></h3>
                                <small class="text-primary">صنف في النظام</small>
                            </div>
                            <div class="stat-icon bg-products">
                                <i class="bi bi-box-seam"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card dashboard-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">الحركات اليوم</h6>
                                <h3 class="mb-0"><?php echo $today_transactions; ?></h3>
                                <small class="text-warning">حركة اليوم</small>
                            </div>
                            <div class="stat-icon bg-transactions">
                                <i class="bi bi-arrow-left-right"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card dashboard-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">جهات الاتصال</h6>
                                <h3 class="mb-0"><?php echo $total_contacts; ?></h3>
                                <small class="text-success">عميل/مورد/مقاول</small>
                            </div>
                            <div class="stat-icon bg-contacts">
                                <i class="bi bi-people"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card dashboard-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">منخفضة المخزون</h6>
                                <h3 class="mb-0"><?php echo $low_stock; ?></h3>
                                <small class="text-danger">تحتاج لإعادة تزويد</small>
                            </div>
                            <div class="stat-icon bg-warning">
                                <i class="bi bi-exclamation-triangle"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- الأزرار السريعة -->
        <div class="row mb-4 fade-in">
            <div class="col-12 mb-3">
                <h5 class="mb-3">إجراءات سريعة</h5>
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4 col-6 mb-3">
                <button class="btn quick-action-btn w-100" onclick="window.location.href='products.php'">
                    <i class="bi bi-plus-circle text-primary"></i>
                    <div class="mt-2">إضافة صنف</div>
                </button>
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4 col-6 mb-3">
                <button class="btn quick-action-btn w-100" onclick="window.location.href='transactions.php?type=in'">
                    <i class="bi bi-box-arrow-in-down text-success"></i>
                    <div class="mt-2">وارد جديد</div>
                </button>
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4 col-6 mb-3">
                <button class="btn quick-action-btn w-100" onclick="window.location.href='transactions.php?type=out'">
                    <i class="bi bi-box-arrow-up text-danger"></i>
                    <div class="mt-2">صادر جديد</div>
                </button>
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4 col-6 mb-3">
                <button class="btn quick-action-btn w-100" onclick="window.location.href='contacts.php?type=customer'">
                    <i class="bi bi-person-plus text-info"></i>
                    <div class="mt-2">إضافة عميل</div>
                </button>
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4 col-6 mb-3">
                <button class="btn quick-action-btn w-100" onclick="window.location.href='reports.php'">
                    <i class="bi bi-graph-up text-warning"></i>
                    <div class="mt-2">تقارير المخزون</div>
                </button>
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4 col-6 mb-3">
                <button class="btn quick-action-btn w-100" onclick="window.location.href='inventory.php'">
                    <i class="bi bi-clipboard-data text-secondary"></i>
                    <div class="mt-2">جرد المخزون</div>
                </button>
            </div>
        </div>
        
        <!-- آخر الحركات والمنتجات الأكثر حركة -->
        <div class="row fade-in">
            <div class="col-lg-6 mb-4">
                <div class="card dashboard-card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="bi bi-clock-history me-2"></i> آخر الحركات
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if(count($recent_transactions) > 0): ?>
                        <div class="table-responsive">
                            <table class="table recent-table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>النوع</th>
                                        <th>التاريخ</th>
                                        <th>الجهة</th>
                                        <th>المبلغ</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($recent_transactions as $index => $trans): ?>
                                    <tr>
                                        <td><?php echo $index + 1; ?></td>
                                        <td>
                                            <span class="badge 
                                                <?php 
                                                if($trans['trans_type'] == 'in') echo 'bg-success';
                                                elseif($trans['trans_type'] == 'out') echo 'bg-danger';
                                                else echo 'bg-info';
                                                ?>">
                                                <?php echo $trans['trans_type_arabic']; ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('H:i', strtotime($trans['trans_date'])); ?></td>
                                        <td><?php echo htmlspecialchars($trans['contact_name'] ?? '---'); ?></td>
                                        <td><?php echo number_format($trans['total_amount'], 2); ?> ج.م</td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <a href="transactions.php" class="btn btn-sm btn-outline-primary w-100 mt-3">
                            <i class="bi bi-arrow-left me-1"></i> عرض جميع الحركات
                        </a>
                        <?php else: ?>
                        <div class="text-center py-4">
                            <i class="bi bi-clock display-4 text-muted"></i>
                            <p class="mt-3">لا توجد حركات حديثة</p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-6 mb-4">
                <div class="card dashboard-card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="bi bi-graph-up-arrow me-2"></i> المنتجات الأكثر حركة
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if(count($top_products) > 0): ?>
                        <div class="table-responsive">
                            <table class="table recent-table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>اسم المنتج</th>
                                        <th>كمية الصادر</th>
                                        <th>النسبة</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $max_out = max(array_column($top_products, 'total_out'));
                                    foreach($top_products as $index => $product): 
                                        $percentage = $max_out > 0 ? ($product['total_out'] / $max_out) * 100 : 0;
                                    ?>
                                    <tr>
                                        <td><?php echo $index + 1; ?></td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($product['product_name']); ?></strong>
                                        </td>
                                        <td><?php echo number_format($product['total_out'], 2); ?></td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="progress flex-grow-1 me-2" style="height: 8px;">
                                                    <div class="progress-bar bg-info" 
                                                         style="width: <?php echo $percentage; ?>%"
                                                         role="progressbar"></div>
                                                </div>
                                                <small><?php echo number_format($percentage, 0); ?>%</small>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <a href="reports.php?report=top_products" class="btn btn-sm btn-outline-primary w-100 mt-3">
                            <i class="bi bi-bar-chart me-1"></i> تقرير تفصيلي
                        </a>
                        <?php else: ?>
                        <div class="text-center py-4">
                            <i class="bi bi-box display-4 text-muted"></i>
                            <p class="mt-3">لا توجد بيانات عن المنتجات</p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- الفوتر -->
    <?php include 'includes/footer.php'; ?>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- الاسكريبتات العامة -->
    <?php include 'includes/scripts.php'; ?>
    
    <script>
    // تهيئة أدوات التلميح
    document.addEventListener('DOMContentLoaded', function() {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    });
    </script>
</body>
</html>