<?php
// edit_product.php
session_start();

// تعريف متغيرات الجلسة إذا لم تكن موجودة
if (!isset($_SESSION['full_name'])) {
    $_SESSION['full_name'] = 'مستخدم النظام';
    $_SESSION['role'] = 'مدير';
}

require_once 'includes/db_connection.php';
require_once 'includes/auth_check.php';

$page_title = "تعديل منتج";

// التحقق من وجود معرف المنتج
$product_id = $_GET['id'] ?? 0;
if (!$product_id) {
    header('Location: products.php');
    exit;
}

// جلب بيانات المنتج الحالية
try {
    $stmt = $pdo->prepare("
        SELECT p.*, c.category_name 
        FROM products p 
        LEFT JOIN categories c ON p.category_id = c.category_id 
        WHERE p.product_id = ?
    ");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch();
    
    if (!$product) {
        header('Location: products.php');
        exit;
    }
} catch (PDOException $e) {
    die("<div class='alert alert-danger'>خطأ في جلب بيانات المنتج: " . $e->getMessage() . "</div>");
}

// جلب الوحدات الحالية للمنتج
try {
    $units_stmt = $pdo->prepare("SELECT * FROM product_units WHERE product_id = ? ORDER BY conversion_factor");
    $units_stmt->execute([$product_id]);
    $existing_units = $units_stmt->fetchAll();
} catch (PDOException $e) {
    $existing_units = [];
}

// جلب الفئات لعرضها في القائمة المنسدلة
try {
    $categories = $pdo->query("SELECT * FROM categories ORDER BY category_name")->fetchAll();
} catch (PDOException $e) {
    $categories = [];
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title . ' - ' . htmlspecialchars($product['product_name']); ?> - StoreMate</title>
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.rtl.min.css" onerror="this.onerror=null;this.href='assets/css/bootstrap.min.css';">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    
    <!-- الخط العربي -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    
    <!-- الأنماط العامة -->
    <?php include 'includes/styles.php'; ?>
    
    <style>
        .edit-header {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .unit-row {
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 10px;
            background-color: #f8f9fa;
        }
        
        .unit-row:last-child {
            margin-bottom: 0;
        }
        
        .required-field::after {
            content: " *";
            color: #dc3545;
        }
        
        .form-section {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            border: 1px solid #dee2e6;
        }
        
        .form-section h5 {
            border-bottom: 2px solid #6c757d;
            padding-bottom: 10px;
            margin-bottom: 20px;
            color: #495057;
        }
        
        .back-button {
            transition: all 0.3s;
        }
        
        .back-button:hover {
            transform: translateX(-5px);
        }
    </style>
</head>
<body>
    <!-- السايدبار -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- الشريط العلوي -->
        <?php include 'includes/header.php'; ?>
        
        <!-- رأس صفحة التعديل -->
        <div class="container mt-4">
            <div class="edit-header fade-in">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <div class="d-flex align-items-center mb-3">
                            <a href="product_details.php?id=<?php echo $product_id; ?>" class="btn btn-light btn-sm me-3 back-button">
                                <i class="bi bi-arrow-right me-1"></i> رجوع للتفاصيل
                            </a>
                            <h2 class="mb-0">
                                <i class="bi bi-pencil-square me-2"></i>تعديل منتج
                            </h2>
                        </div>
                        <p class="mb-0 opacity-75">
                            تعديل: <strong><?php echo htmlspecialchars($product['product_name']); ?></strong>
                            <?php if($product['product_code']): ?>
                            - كود: <?php echo htmlspecialchars($product['product_code']); ?>
                            <?php endif; ?>
                        </p>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <a href="products.php" class="btn btn-light">
                            <i class="bi bi-box-seam me-1"></i> جميع المنتجات
                        </a>
                        <a href="product_details.php?id=<?php echo $product_id; ?>" class="btn btn-info">
                            <i class="bi bi-eye me-1"></i> عرض
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- رسالة نجاح/خطأ -->
        <div id="messageContainer" class="container mb-4" style="display: none;">
            <div class="alert" id="messageAlert">
                <!-- سيتم ملؤها بالجافاسكريبت -->
            </div>
        </div>
        
        <!-- نموذج التعديل -->
        <div class="container mb-5">
            <form id="editProductForm" method="POST">
                <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                
                <div class="form-section">
                    <h5><i class="bi bi-info-circle me-2"></i> المعلومات الأساسية</h5>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label required-field">اسم المنتج</label>
                            <input type="text" class="form-control" name="product_name" 
                                   value="<?php echo htmlspecialchars($product['product_name']); ?>" required>
                            <div class="form-text">الاسم الذي سيظهر في القوائم والتقارير</div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label">كود المنتج (باركود)</label>
                            <input type="text" class="form-control" name="product_code" 
                                   value="<?php echo htmlspecialchars($product['product_code'] ?? ''); ?>">
                            <div class="form-text">كود فريد للمنتج (اختياري)</div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label">الفئة</label>
                            <select class="form-select" name="category_id">
                                <option value="">اختر الفئة</option>
                                <?php foreach($categories as $cat): ?>
                                <option value="<?php echo $cat['category_id']; ?>"
                                    <?php echo ($product['category_id'] == $cat['category_id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cat['category_name']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="form-text">تصنيف المنتج لتسهيل البحث والترتيب</div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label">رصيد أول المدة</label>
                            <input type="number" class="form-control" name="initial_balance" 
                                   value="<?php echo number_format($product['initial_balance'] ?? 0, 3, '.', ''); ?>" 
                                   step="0.001" min="0">
                            <div class="form-text">الكمية المتوفرة حالياً في المخزون</div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label">حد الطلب الأدنى</label>
                            <input type="number" class="form-control" name="min_stock_level" 
                                   value="<?php echo number_format($product['min_stock_level'] ?? 0, 2, '.', ''); ?>" 
                                   step="0.01" min="0">
                            <div class="form-text">الحد الأدنى للمخزون قبل إرسال تنبيه</div>
                        </div>
                        
                        <div class="col-12 mb-3">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" id="is_cable" 
                                       name="is_cable" value="1"
                                       <?php echo ($product['is_cable'] ?? 0) ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="is_cable">
                                    منتج من نوع كابل
                                </label>
                                <div class="form-text">تحديد إذا كان المنتج من نوع الكابلات (سيكون له معاملات خاصة)</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- قسم الوحدات -->
                <div class="form-section">
                    <h5><i class="bi bi-rulers me-2"></i> إعدادات الوحدات والأسعار</h5>
                    
                    <div class="alert alert-info mb-4">
                        <i class="bi bi-info-circle me-2"></i>
                        <strong>ملاحظة:</strong> الوحدة الأساسية هي أول وحدة في القائمة، يجب أن يكون معامل التحويل لها = 1
                    </div>
                    
                    <!-- عرض الوحدات الحالية -->
                    <div id="unitsContainer">
                        <?php if(count($existing_units) > 0): ?>
                            <?php foreach($existing_units as $index => $unit): ?>
                            <div class="unit-row" data-unit-id="<?php echo $unit['unit_id']; ?>">
                                <div class="row g-3 align-items-end">
                                    <div class="col-md-4">
                                        <label class="form-label">
                                            <?php echo ($index == 0) ? 'الوحدة الأساسية *' : 'اسم الوحدة *'; ?>
                                        </label>
                                        <input type="text" class="form-control" 
                                               name="units[<?php echo $index; ?>][name]" 
                                               value="<?php echo htmlspecialchars($unit['unit_name']); ?>" required>
                                    </div>
                                    
                                    <div class="col-md-3">
                                        <label class="form-label">سعر البيع (ج.م)</label>
                                        <input type="number" class="form-control" 
                                               name="units[<?php echo $index; ?>][price]" 
                                               value="<?php echo number_format($unit['base_unit_price'] ?? 0, 2, '.', ''); ?>" 
                                               step="0.01">
                                    </div>
                                    
                                    <div class="col-md-3">
                                        <label class="form-label">
                                            <?php echo ($index == 0) ? 'معامل التحويل (يجب أن يكون 1)' : 'معامل التحويل *'; ?>
                                        </label>
                                        <input type="number" class="form-control" 
                                               name="units[<?php echo $index; ?>][factor]" 
                                               value="<?php echo number_format($unit['conversion_factor'] ?? 1, 3, '.', ''); ?>" 
                                               step="0.001" min="0.001" required
                                               <?php echo ($index == 0) ? 'readonly' : ''; ?>>
                                    </div>
                                    
                                    <div class="col-md-2 text-end">
                                        <?php if($index == 0): ?>
                                        <span class="badge bg-success d-block mb-2">الوحدة الأساسية</span>
                                        <?php else: ?>
                                        <button type="button" class="btn btn-sm btn-danger" onclick="removeUnitRow(this)">
                                            <i class="bi bi-trash"></i> حذف
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <input type="hidden" name="units[<?php echo $index; ?>][unit_id]" value="<?php echo $unit['unit_id']; ?>">
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <!-- إذا لم تكن هناك وحدات، نعرض وحدة أساسية افتراضية -->
                            <div class="unit-row">
                                <div class="row g-3 align-items-end">
                                    <div class="col-md-4">
                                        <label class="form-label">الوحدة الأساسية *</label>
                                        <input type="text" class="form-control" 
                                               name="units[0][name]" 
                                               placeholder="مثلاً: قطعة" required>
                                    </div>
                                    
                                    <div class="col-md-3">
                                        <label class="form-label">سعر البيع (ج.م)</label>
                                        <input type="number" class="form-control" 
                                               name="units[0][price]" 
                                               value="0" step="0.01">
                                    </div>
                                    
                                    <div class="col-md-3">
                                        <label class="form-label">معامل التحويل</label>
                                        <input type="number" class="form-control" 
                                               name="units[0][factor]" 
                                               value="1" step="0.001" min="0.001" readonly>
                                    </div>
                                    
                                    <div class="col-md-2">
                                        <span class="badge bg-success d-block mb-2">الوحدة الأساسية</span>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- زر إضافة وحدة جديدة -->
                    <div class="text-center mt-4">
                        <button type="button" class="btn btn-outline-primary" onclick="addUnitRow()">
                            <i class="bi bi-plus-circle me-1"></i> إضافة وحدة كبرى جديدة
                        </button>
                        <div class="form-text mt-2">
                            الوحدة الكبرى: مثل كرتونة = 12 قطعة (معامل التحويل = 12)
                        </div>
                    </div>
                </div>
                
                <!-- أزرار الحفظ والإلغاء -->
                <div class="form-section">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="bi bi-check-circle me-2"></i> حفظ التعديلات
                                </button>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="d-grid">
                                <a href="product_details.php?id=<?php echo $product_id; ?>" 
                                   class="btn btn-secondary btn-lg">
                                    <i class="bi bi-x-circle me-2"></i> إلغاء والعودة
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    
    <!-- الفوتر -->
    <?php include 'includes/footer.php'; ?>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- الاسكريبتات العامة -->
    <?php include 'includes/scripts.php'; ?>
    
    <script>
    // عداد لوحدات جديدة
    let unitCounter = <?php echo count($existing_units) ?: 1; ?>;
    
    // دالة لإضافة صف وحدة جديد
    function addUnitRow() {
        const container = document.getElementById('unitsContainer');
        const unitIndex = unitCounter;
        
        const html = `
            <div class="unit-row">
                <div class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label class="form-label">اسم الوحدة الكبرى *</label>
                        <input type="text" class="form-control" 
                               name="units[${unitIndex}][name]" 
                               placeholder="مثلاً: كرتونة" required>
                    </div>
                    
                    <div class="col-md-3">
                        <label class="form-label">سعر البيع (ج.م)</label>
                        <input type="number" class="form-control" 
                               name="units[${unitIndex}][price]" 
                               value="0" step="0.01">
                    </div>
                    
                    <div class="col-md-3">
                        <label class="form-label">معامل التحويل *</label>
                        <input type="number" class="form-control" 
                               name="units[${unitIndex}][factor]" 
                               placeholder="مثال: 12" 
                               step="0.001" min="0.001" required>
                        <div class="form-text">كم وحدة أساسية تساوي هذه الوحدة؟</div>
                    </div>
                    
                    <div class="col-md-2 text-end">
                        <button type="button" class="btn btn-sm btn-danger" onclick="removeUnitRow(this)">
                            <i class="bi bi-trash"></i> حذف
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        container.insertAdjacentHTML('beforeend', html);
        unitCounter++;
    }
    
    // دالة لحذف صف وحدة
    function removeUnitRow(button) {
        const row = button.closest('.unit-row');
        if (row) {
            row.remove();
            // إعادة ترقيم الوحدات المتبقية
            renumberUnits();
        }
    }
    
    // دالة لإعادة ترقيم الوحدات
    function renumberUnits() {
        const rows = document.querySelectorAll('.unit-row');
        let newIndex = 0;
        
        rows.forEach((row, index) => {
            // تحديث حقول الاسم
            const nameInput = row.querySelector('input[name*="[name]"]');
            const priceInput = row.querySelector('input[name*="[price]"]');
            const factorInput = row.querySelector('input[name*="[factor]"]');
            const unitIdInput = row.querySelector('input[name*="[unit_id]"]');
            
            if (nameInput && priceInput && factorInput) {
                // تحديث أسماء الحقول
                nameInput.name = `units[${newIndex}][name]`;
                priceInput.name = `units[${newIndex}][price]`;
                factorInput.name = `units[${newIndex}][factor]`;
                
                if (unitIdInput) {
                    unitIdInput.name = `units[${newIndex}][unit_id]`;
                }
                
                // إذا كانت الوحدة الأولى (الأساسية)، جعل معامل التحويل مقروءاً
                if (newIndex === 0) {
                    factorInput.readOnly = true;
                    factorInput.value = '1';
                    
                    // إضافة أو إزالة بادج "الوحدة الأساسية"
                    const badgeArea = row.querySelector('.col-md-2.text-end, .col-md-2');
                    if (badgeArea) {
                        const existingBadge = badgeArea.querySelector('.badge.bg-success');
                        if (!existingBadge) {
                            badgeArea.innerHTML = '<span class="badge bg-success d-block mb-2">الوحدة الأساسية</span>';
                        }
                    }
                } else {
                    factorInput.readOnly = false;
                    
                    // إضافة زر الحذف إذا لم يكن موجوداً
                    const badgeArea = row.querySelector('.col-md-2.text-end, .col-md-2');
                    if (badgeArea && !badgeArea.querySelector('.btn-danger')) {
                        badgeArea.innerHTML = `
                            <button type="button" class="btn btn-sm btn-danger" onclick="removeUnitRow(this)">
                                <i class="bi bi-trash"></i> حذف
                            </button>
                        `;
                    }
                }
                
                newIndex++;
            }
        });
        
        // تحديث العداد
        unitCounter = newIndex;
    }
    
    // معالجة إرسال النموذج
    document.getElementById('editProductForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        // إظهار تحميل
        const submitBtn = this.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="bi bi-hourglass-split me-2"></i> جاري الحفظ...';
        submitBtn.disabled = true;
        
        const formData = new FormData(this);
        
        fetch('api/update_product.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                showMessage('success', data.message);
                
                // إعادة توجيه بعد ثانيتين
                setTimeout(() => {
                    window.location.href = 'product_details.php?id=' + <?php echo $product_id; ?>;
                }, 2000);
            } else {
                showMessage('danger', data.message);
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }
        })
        .catch(error => {
            showMessage('danger', 'حدث خطأ في الاتصال بالخادم: ' + error.message);
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        });
    });
    
    // دالة لعرض الرسائل
    function showMessage(type, text) {
        const container = document.getElementById('messageContainer');
        const alert = document.getElementById('messageAlert');
        
        alert.className = `alert alert-${type} alert-dismissible fade show`;
        alert.innerHTML = `
            <i class="bi bi-${type === 'success' ? 'check-circle' : 'exclamation-triangle'} me-2"></i>
            ${text}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        container.style.display = 'block';
        
        // تمرير للرسالة تلقائياً بعد 5 ثواني
        setTimeout(() => {
            if (alert.classList.contains('show')) {
                const closeBtn = alert.querySelector('.btn-close');
                if (closeBtn) closeBtn.click();
            }
        }, 5000);
    }
    
    // تهيئة بعد تحميل الصفحة
    document.addEventListener('DOMContentLoaded', function() {
        // التأكد من أن الوحدة الأولى (الأساسية) معاملها = 1 وغير قابلة للتعديل
        const firstFactorInput = document.querySelector('input[name*="[factor]"]');
        if (firstFactorInput) {
            firstFactorInput.readOnly = true;
            firstFactorInput.value = '1';
        }
        
        // إضافة مؤشر الحقول المطلوبة
        const requiredLabels = document.querySelectorAll('.required-field');
        requiredLabels.forEach(label => {
            if (!label.querySelector('.required-star')) {
                label.innerHTML += ' <span class="text-danger">*</span>';
            }
        });
    });
    </script>
</body>
</html>