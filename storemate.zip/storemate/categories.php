<?php
// categories.php
session_start();

// تعريف متغيرات الجلسة إذا لم تكن موجودة
if (!isset($_SESSION['full_name'])) {
    $_SESSION['full_name'] = 'مستخدم النظام';
    $_SESSION['role'] = 'مدير';
}

require_once 'includes/db_connection.php';
require_once 'includes/auth_check.php';

$page_title = "الفئات";

// جلب الفئات
$search = $_GET['search'] ?? '';

$query = "SELECT c.*, 
          (SELECT COUNT(*) FROM products p WHERE p.category_id = c.category_id) as product_count
          FROM categories c 
          WHERE 1=1";

$params = [];

if (!empty($search)) {
    $query .= " AND (c.category_name LIKE ? OR c.category_description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$query .= " ORDER BY c.category_name";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $categories = $stmt->fetchAll();
} catch (PDOException $e) {
    $categories = [];
    echo "<div class='alert alert-danger'>خطأ في جلب البيانات: " . $e->getMessage() . "</div>";
}

// إحصائيات
$stats = [
    'total_categories' => 0,
    'total_products_in_categories' => 0,
    'categories_without_products' => 0,
    'most_products_category' => ['name' => '---', 'count' => 0]
];

if ($categories) {
    $stats['total_categories'] = count($categories);
    
    foreach($categories as $category) {
        $stats['total_products_in_categories'] += $category['product_count'];
        
        if($category['product_count'] == 0) {
            $stats['categories_without_products']++;
        }
        
        if($category['product_count'] > $stats['most_products_category']['count']) {
            $stats['most_products_category'] = [
                'name' => $category['category_name'],
                'count' => $category['product_count']
            ];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - StoreMate</title>
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.rtl.min.css" onerror="this.onerror=null;this.href='assets/css/bootstrap.min.css';">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    
    <!-- الخط العربي -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    
    <!-- الأنماط العامة -->
    <?php include 'includes/styles.php'; ?>
    
    <style>
        .category-card {
            transition: all 0.3s ease;
            border: 1px solid #dee2e6;
            border-radius: 10px;
            overflow: hidden;
        }
        
        .category-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            border-color: #0d6efd;
        }
        
        .category-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin: 0 auto 15px;
        }
        
        .category-badge {
            position: absolute;
            top: 10px;
            left: 10px;
        }
        
        .empty-category {
            opacity: 0.7;
            border-style: dashed;
        }
        
        .category-color-1 { background-color: #e3f2fd; color: #1565c0; }
        .category-color-2 { background-color: #f3e5f5; color: #7b1fa2; }
        .category-color-3 { background-color: #e8f5e8; color: #2e7d32; }
        .category-color-4 { background-color: #fff3e0; color: #ef6c00; }
        .category-color-5 { background-color: #fce4ec; color: #c2185b; }
        .category-color-6 { background-color: #e0f2f1; color: #00695c; }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
        }
    </style>
</head>
<body>
    <!-- السايدبار -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- الشريط العلوي -->
        <?php include 'includes/header.php'; ?>
        
        <!-- بطاقة الترحيب -->
        <div class="welcome-card fade-in">
            <div class="container p-4 position-relative">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h2 class="mb-2">إدارة الفئات</h2>
                        <p class="mb-0 opacity-75">تنظيم وتصنيف المنتجات في مجموعات</p>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <button class="btn btn-light" data-bs-toggle="modal" data-bs-target="#addCategoryModal">
                            <i class="bi bi-plus-circle me-1"></i>إضافة فئة
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- بطاقات الإحصائيات -->
        <div class="row mb-4 fade-in">
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card h-100 border-primary">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">إجمالي الفئات</h6>
                                <h3 class="mb-0 text-primary"><?php echo $stats['total_categories']; ?></h3>
                                <small class="text-primary stat-label">فئة في النظام</small>
                            </div>
                            <div class="stat-icon bg-primary bg-opacity-10 text-primary">
                                <i class="bi bi-tags"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card h-100 border-success">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">المنتجات المصنفة</h6>
                                <h3 class="mb-0 text-success"><?php echo $stats['total_products_in_categories']; ?></h3>
                                <small class="text-success stat-label">منتج مصنف</small>
                            </div>
                            <div class="stat-icon bg-success bg-opacity-10 text-success">
                                <i class="bi bi-box-seam"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card h-100 border-warning">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">فئات فارغة</h6>
                                <h3 class="mb-0 text-warning"><?php echo $stats['categories_without_products']; ?></h3>
                                <small class="text-warning stat-label">بدون منتجات</small>
                            </div>
                            <div class="stat-icon bg-warning bg-opacity-10 text-warning">
                                <i class="bi bi-folder-x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card h-100 border-info">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">أكثر فئة منتجات</h6>
                                <h5 class="mb-1 text-info"><?php echo htmlspecialchars($stats['most_products_category']['name']); ?></h5>
                                <small class="text-info stat-label"><?php echo $stats['most_products_category']['count']; ?> منتج</small>
                            </div>
                            <div class="stat-icon bg-info bg-opacity-10 text-info">
                                <i class="bi bi-trophy"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- فلترة البحث -->
        <div class="card mb-4 fade-in">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-10">
                        <input type="text" class="form-control" name="search" placeholder="بحث باسم الفئة أو الوصف" 
                               value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-search"></i> بحث
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- عرض الفئات -->
        <div class="dashboard-table fade-in">
            <?php if(count($categories) > 0): ?>
                <div class="row">
                    <?php 
                    $color_classes = ['category-color-1', 'category-color-2', 'category-color-3', 
                                     'category-color-4', 'category-color-5', 'category-color-6'];
                    ?>
                    
                    <?php foreach($categories as $index => $category): 
                        $color_class = $color_classes[$index % count($color_classes)];
                        $is_empty = $category['product_count'] == 0;
                    ?>
                    <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                        <div class="card category-card h-100 <?php echo $is_empty ? 'empty-category' : ''; ?>">
                            <?php if($is_empty): ?>
                            <span class="category-badge badge bg-warning">
                                <i class="bi bi-exclamation-triangle me-1"></i>فارغة
                            </span>
                            <?php endif; ?>
                            
                            <div class="card-body text-center p-4">
                                <div class="category-icon <?php echo $color_class; ?>">
                                    <i class="bi bi-folder"></i>
                                </div>
                                
                                <h5 class="card-title mb-2">
                                    <?php echo htmlspecialchars($category['category_name']); ?>
                                </h5>
                                
                                <?php if($category['category_description']): ?>
                                <p class="card-text text-muted mb-3" style="min-height: 40px;">
                                    <?php echo htmlspecialchars(substr($category['category_description'], 0, 100)); ?>
                                    <?php if(strlen($category['category_description']) > 100): ?>...<?php endif; ?>
                                </p>
                                <?php else: ?>
                                <p class="card-text text-muted mb-3" style="min-height: 40px;">
                                    <small>لا يوجد وصف</small>
                                </p>
                                <?php endif; ?>
                                
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <span class="badge bg-primary">
                                        <i class="bi bi-box me-1"></i>
                                        <?php echo $category['product_count']; ?> منتج
                                    </span>
                                    
                                    <small class="text-muted">
                                        <?php echo date('Y-m-d', strtotime($category['created_at'])); ?>
                                    </small>
                                </div>
                                
                                <div class="btn-group w-100">
                                    <button class="btn btn-outline-info btn-sm" 
                                            onclick="viewCategory(<?php echo $category['category_id']; ?>)"
                                            title="عرض التفاصيل">
                                        <i class="bi bi-eye"></i>
                                    </button>
                                    <button class="btn btn-outline-warning btn-sm"
                                            onclick="editCategory(<?php echo $category['category_id']; ?>)"
                                            title="تعديل">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <button class="btn btn-outline-danger btn-sm" 
                                            onclick="deleteCategory(<?php echo $category['category_id']; ?>, '<?php echo htmlspecialchars($category['category_name']); ?>')"
                                            title="حذف">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="card">
                    <div class="card-body">
                        <div class="text-center py-5">
                            <i class="bi bi-tags display-1 text-muted"></i>
                            <h5 class="mt-3">لا توجد فئات</h5>
                            <p class="text-muted">ابدأ بإضافة فئات جديدة لتصنيف المنتجات</p>
                            <button class="btn btn-primary mt-3" data-bs-toggle="modal" data-bs-target="#addCategoryModal">
                                <i class="bi bi-plus-circle me-1"></i>إضافة أول فئة
                            </button>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- الفئات الفارغة (إن وجدت) -->
        <?php 
        $empty_categories = array_filter($categories, function($cat) {
            return $cat['product_count'] == 0;
        });
        
        if(count($empty_categories) > 0): ?>
        <div class="row mt-4 fade-in">
            <div class="col-12">
                <div class="dashboard-table">
                    <div class="card border-warning">
                        <div class="card-header bg-warning bg-opacity-10">
                            <h5 class="mb-0">
                                <i class="bi bi-exclamation-triangle me-2 text-warning"></i> الفئات الفارغة
                                <span class="badge bg-warning"><?php echo count($empty_categories); ?></span>
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>اسم الفئة</th>
                                            <th>تاريخ الإضافة</th>
                                            <th>الإجراءات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($empty_categories as $index => $category): ?>
                                        <tr>
                                            <td><?php echo $index + 1; ?></td>
                                            <td>
                                                <strong><?php echo htmlspecialchars($category['category_name']); ?></strong>
                                            </td>
                                            <td><?php echo date('Y-m-d', strtotime($category['created_at'])); ?></td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <button class="btn btn-outline-warning"
                                                            onclick="editCategory(<?php echo $category['category_id']; ?>)">
                                                        <i class="bi bi-pencil me-1"></i>تعديل
                                                    </button>
                                                    <button class="btn btn-outline-danger" 
                                                            onclick="deleteCategory(<?php echo $category['category_id']; ?>, '<?php echo htmlspecialchars($category['category_name']); ?>')">
                                                        <i class="bi bi-trash me-1"></i>حذف
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <!-- الفوتر -->
    <?php include 'includes/footer.php'; ?>
    
    <!-- مودال إضافة فئة -->
    <div class="modal fade" id="addCategoryModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">إضافة فئة جديدة</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="addCategoryForm" method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">اسم الفئة *</label>
                            <input type="text" class="form-control" name="category_name" required>
                            <div class="form-text">اسم واضح يميز هذه الفئة عن غيرها</div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">وصف الفئة</label>
                            <textarea class="form-control" name="category_description" rows="3"></textarea>
                            <div class="form-text">وصف مختصر للفئة (اختياري)</div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary">حفظ الفئة</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- مودال تعديل فئة -->
    <div class="modal fade" id="editCategoryModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">تعديل الفئة</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="editCategoryForm" method="POST">
                    <input type="hidden" name="category_id" id="edit_category_id">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">اسم الفئة *</label>
                            <input type="text" class="form-control" name="category_name" id="edit_category_name" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">وصف الفئة</label>
                            <textarea class="form-control" name="category_description" id="edit_category_description" rows="3"></textarea>
                        </div>
                        
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle me-2"></i>
                            <small>تاريخ الإنشاء: <span id="edit_created_at"></span></small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary">تحديث الفئة</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- الاسكريبتات العامة -->
    <?php include 'includes/scripts.php'; ?>
    
    <script>
    // وظائف خاصة بصفحة الفئات
    
    function viewCategory(id) {
        window.location.href = 'category_products.php?id=' + id;
    }
    
    function editCategory(id) {
        // جلب بيانات الفئة عبر AJAX
        fetch(`api/get_category.php?id=${id}`)
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    document.getElementById('edit_category_id').value = data.category.category_id;
                    document.getElementById('edit_category_name').value = data.category.category_name;
                    document.getElementById('edit_category_description').value = data.category.category_description || '';
                    document.getElementById('edit_created_at').textContent = data.category.created_at;
                    
                    // عرض المودال
                    const modal = new bootstrap.Modal(document.getElementById('editCategoryModal'));
                    modal.show();
                } else {
                    alert('حدث خطأ في جلب بيانات الفئة');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('حدث خطأ في الاتصال');
            });
    }
    
    function deleteCategory(id, name) {
        if(confirm(`هل أنت متأكد من حذف الفئة "${name}"؟\n\nملاحظة: لا يمكن حذف الفئة إذا كانت تحتوي على منتجات.`)) {
            fetch(`api/delete_category.php?id=${id}`, {
                method: 'DELETE'
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    alert('تم حذف الفئة بنجاح');
                    window.location.reload();
                } else {
                    alert(data.message || 'حدث خطأ أثناء الحذف');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('حدث خطأ في الاتصال');
            });
        }
    }
    
    // معالجة نموذج إضافة فئة
    document.getElementById('addCategoryForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        
        fetch('api/save_category.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                alert('تم إضافة الفئة بنجاح');
                window.location.reload();
            } else {
                alert('حدث خطأ: ' + (data.message || 'غير معروف'));
            }
        })
        .catch(error => {
            alert('حدث خطأ في الاتصال بالخادم');
        });
    });
    
    // معالجة نموذج تعديل فئة
    document.getElementById('editCategoryForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        
        fetch('api/update_category.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                alert('تم تحديث الفئة بنجاح');
                window.location.reload();
            } else {
                alert('حدث خطأ: ' + (data.message || 'غير معروف'));
            }
        })
        .catch(error => {
            alert('حدث خطأ في الاتصال بالخادم');
        });
    });
    
    // تهيئة أدوات التلميح
    document.addEventListener('DOMContentLoaded', function() {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    });
    </script>
</body>
</html>