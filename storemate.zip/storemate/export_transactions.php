<?php
session_start();

if (!isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}

require_once 'includes/db_connection.php';
require_once 'includes/auth_check.php';

// جلب معايير البحث
$trans_type = $_GET['trans_type'] ?? '';
$contact_id = $_GET['contact_id'] ?? '';
$project_id = $_GET['project_id'] ?? '';
$warehouse_id = $_GET['warehouse_id'] ?? '';
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';
$search = $_GET['search'] ?? '';

$query = "SELECT t.*, c.contact_name, p.project_name, 
          w1.warehouse_name as from_warehouse_name, 
          w2.warehouse_name as to_warehouse_name,
          u.full_name as user_name
          FROM transactions t 
          LEFT JOIN contacts c ON t.contact_id = c.contact_id
          LEFT JOIN projects p ON t.project_id = p.project_id
          LEFT JOIN warehouses w1 ON t.from_warehouse_id = w1.warehouse_id
          LEFT JOIN warehouses w2 ON t.to_warehouse_id = w2.warehouse_id
          LEFT JOIN users u ON t.user_id = u.id
          WHERE 1=1";

$params = [];

if (!empty($search)) {
    $searchTerm = "%$search%";
    $query .= " AND (t.notes LIKE ? OR c.contact_name LIKE ? OR t.trans_id LIKE ?)";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

if (!empty($trans_type)) {
    $query .= " AND t.trans_type = ?";
    $params[] = $trans_type;
}

if (!empty($contact_id)) {
    $query .= " AND t.contact_id = ?";
    $params[] = $contact_id;
}

if (!empty($project_id)) {
    $query .= " AND t.project_id = ?";
    $params[] = $project_id;
}

if (!empty($warehouse_id)) {
    $query .= " AND (t.from_warehouse_id = ? OR t.to_warehouse_id = ?)";
    $params[] = $warehouse_id;
    $params[] = $warehouse_id;
}

if (!empty($start_date)) {
    $query .= " AND DATE(t.trans_date) >= ?";
    $params[] = $start_date;
}

if (!empty($end_date)) {
    $query .= " AND DATE(t.trans_date) <= ?";
    $params[] = $end_date;
}

$query .= " ORDER BY t.trans_date DESC";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $transactions = $stmt->fetchAll();
} catch (PDOException $e) {
    $transactions = [];
}

// رأس ملف Excel
header('Content-Type: application/vnd.ms-excel; charset=utf-8');
header('Content-Disposition: attachment; filename="حركات_المخزون_' . date('Y-m-d') . '.xls"');
header('Pragma: no-cache');
header('Expires: 0');

echo '<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<style>
body { font-family: Arial, sans-serif; direction: rtl; }
table { border-collapse: collapse; width: 100%; }
th { background-color: #f2f2f2; border: 1px solid #ddd; padding: 8px; text-align: right; }
td { border: 1px solid #ddd; padding: 8px; text-align: right; }
.in { color: green; font-weight: bold; }
.out { color: red; font-weight: bold; }
</style>
</head>
<body>';

echo '<h2 style="text-align: center;">تقرير حركات المخزون</h2>';
echo '<p style="text-align: center;">تاريخ التصدير: ' . date('Y-m-d H:i:s') . '</p>';

echo '<table border="1">
<tr>
    <th>#</th>
    <th>رقم الحركة</th>
    <th>التاريخ</th>
    <th>نوع الحركة</th>
    <th>جهة الاتصال</th>
    <th>القيمة</th>
    <th>المشروع</th>
    <th>المخزن</th>
    <th>ملاحظات</th>
</tr>';

$total_amount = 0;
$total_in = 0;
$total_out = 0;

foreach ($transactions as $index => $trans) {
    echo '<tr>';
    echo '<td>' . ($index + 1) . '</td>';
    echo '<td>#' . $trans['trans_id'] . '</td>';
    echo '<td>' . date('Y/m/d H:i', strtotime($trans['trans_date'])) . '</td>';
    
    // نوع الحركة
    $type_names = [
        'in' => 'وارد', 'out' => 'صادر', 'issue' => 'صرف', 
        'return' => 'مرتجع', 'transfer' => 'تحويل'
    ];
    echo '<td>' . ($type_names[$trans['trans_type']] ?? $trans['trans_type']) . '</td>';
    
    echo '<td>' . htmlspecialchars($trans['contact_name'] ?? '') . '</td>';
    
    $amount = $trans['total_amount'] ?? 0;
    if (in_array($trans['trans_type'], ['in', 'return'])) {
        echo '<td class="in">' . number_format($amount, 2) . ' ج.م</td>';
        $total_in += $amount;
    } else {
        echo '<td class="out">' . number_format($amount, 2) . ' ج.م</td>';
        $total_out += $amount;
    }
    
    $total_amount += $amount;
    
    echo '<td>' . htmlspecialchars($trans['project_name'] ?? '') . '</td>';
    
    if ($trans['trans_type'] == 'transfer') {
        echo '<td>' . htmlspecialchars(($trans['from_warehouse_name'] ?? '') . ' → ' . ($trans['to_warehouse_name'] ?? '')) . '</td>';
    } else {
        echo '<td>' . htmlspecialchars($trans['from_warehouse_name'] ?? $trans['to_warehouse_name'] ?? '') . '</td>';
    }
    
    echo '<td>' . htmlspecialchars($trans['notes'] ?? '') . '</td>';
    echo '</tr>';
}

// الإجماليات
echo '<tr style="background-color: #f8f9fa; font-weight: bold;">';
echo '<td colspan="5">الإجماليات:</td>';
echo '<td class="in">' . number_format($total_in, 2) . ' ج.م</td>';
echo '<td class="out">' . number_format($total_out, 2) . ' ج.م</td>';
echo '<td colspan="3"></td>';
echo '</tr>';

echo '<tr style="background-color: #e9ecef; font-weight: bold;">';
echo '<td colspan="5">الصافي:</td>';
echo '<td colspan="5">' . number_format($total_in - $total_out, 2) . ' ج.م</td>';
echo '</tr>';

echo '</table>';

echo '<br><p><strong>عدد الحركات:</strong> ' . count($transactions) . '</p>';
echo '</body></html>';
exit;
?>