<?php
session_start();
require_once 'includes/db_connection.php';
require_once 'includes/auth_check.php';

$page_title = "الأدوات والمعدات";

// جلب الأدوات والمعدات
$search = $_GET['search'] ?? '';
$status = $_GET['status'] ?? '';

$query = "SELECT t.*, c.contact_name, c.phone_number
          FROM tools_assets t
          LEFT JOIN contacts c ON t.assigned_to_contact_id = c.contact_id
          WHERE 1=1";

$params = [];

if(!empty($search)) {
    $query .= " AND (t.tool_name LIKE ? OR t.serial_number LIKE ? OR c.contact_name LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if(!empty($status)) {
    $query .= " AND t.current_status = ?";
    $params[] = $status;
}

$query .= " ORDER BY t.tool_name";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$tools = $stmt->fetchAll();

// حساب إحصائيات الأدوات
$stats = [
    'total_tools' => 0,
    'in_store' => 0,
    'with_contractor' => 0,
    'maintenance' => 0,
    'lost' => 0
];

foreach($tools as $tool) {
    $stats['total_tools']++;
    switch($tool['current_status']) {
        case 'in_store': $stats['in_store']++; break;
        case 'with_contractor': $stats['with_contractor']++; break;
        case 'maintenance': $stats['maintenance']++; break;
        case 'lost': $stats['lost']++; break;
    }
}

// حالات الأدوات
$tool_statuses = [
    'in_store' => ['name' => 'في المخزن', 'color' => 'success', 'icon' => 'bi-box'],
    'with_contractor' => ['name' => 'مع مقاول', 'color' => 'warning', 'icon' => 'bi-person'],
    'maintenance' => ['name' => 'صيانة', 'color' => 'info', 'icon' => 'bi-tools'],
    'lost' => ['name' => 'مفقود', 'color' => 'danger', 'icon' => 'bi-exclamation-triangle']
];
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - StoreMate</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- الخط العربي -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    <!-- CSS المخصص -->
    <link rel="stylesheet" href="style.css">
    
    <style>
        .tool-card {
            border: none;
            border-radius: 12px;
            overflow: hidden;
            transition: all 0.3s ease;
            height: 100%;
        }
        
        .tool-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }
        
        .tool-status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
        }
        
        .tool-assigned {
            background-color: #fff3cd;
            border-right: 4px solid #ffc107;
        }
        
        .tool-available {
            background-color: #d1e7dd;
            border-right: 4px solid #198754;
        }
    </style>
</head>
<body>
    <!-- السايدبار -->
    <div class="sidebar d-none d-md-block">
        <?php include 'sidebar.php'; ?>
    </div>
    
    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <nav class="navbar navbar-expand-lg navbar-dark navbar-custom mb-4">
            <div class="container">
                <button class="navbar-toggler d-md-none" type="button" onclick="toggleSidebar()">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
                <a class="navbar-brand d-flex align-items-center" href="dashboard.php">
                    <i class="bi bi-box-seam me-2 fs-4"></i>
                    <span class="fw-bold fs-4">StoreMate</span>
                </a>
                
                <div class="d-flex align-items-center">
                    <!-- الملف الشخصي -->
                    <div class="dropdown">
                        <button class="btn btn-outline-light dropdown-toggle d-flex align-items-center" type="button" data-bs-toggle="dropdown">
                            <div class="user-avatar me-2">
                                <?php echo substr($_SESSION['full_name'], 0, 1); ?>
                            </div>
                            <div class="text-start">
                                <small class="d-block"><?php echo $_SESSION['full_name']; ?></small>
                                <small class="d-block opacity-75"><?php echo $_SESSION['role']; ?></small>
                            </div>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="profile.php">
                                <i class="bi bi-person me-2"></i> الملف الشخصي
                            </a></li>
                            <li><a class="dropdown-item" href="settings.php">
                                <i class="bi bi-gear me-2"></i> الإعدادات
                            </a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="logout.php">
                                <i class="bi bi-box-arrow-right me-2"></i> تسجيل الخروج
                            </a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
        
        <!-- بطاقة الترحيب -->
        <div class="welcome-card fade-in">
            <div class="container p-4 position-relative">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h2 class="mb-2">إدارة الأدوات والمعدات</h2>
                        <p class="mb-0 opacity-75">تتبع وإدارة جميع أدوات ومعدات المؤسسة</p>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <button class="btn btn-light" data-bs-toggle="modal" data-bs-target="#addToolModal">
                            <i class="bi bi-plus-circle me-1"></i>إضافة أداة
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- بطاقات الإحصائيات -->
        <div class="row mb-4 fade-in">
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">إجمالي الأدوات</h6>
                                <h3 class="mb-0"><?php echo $stats['total_tools']; ?></h3>
                                <small class="text-primary">أداة في النظام</small>
                            </div>
                            <div class="stat-icon">
                                <i class="bi bi-tools"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card success">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">متاحة في المخزن</h6>
                                <h3 class="mb-0"><?php echo $stats['in_store']; ?></h3>
                                <small class="text-success">جاهزة للاستخدام</small>
                            </div>
                            <div class="stat-icon success">
                                <i class="bi bi-box"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card warning">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">مع المقاولين</h6>
                                <h3 class="mb-0"><?php echo $stats['with_contractor']; ?></h3>
                                <small class="text-warning">معارة حالياً</small>
                            </div>
                            <div class="stat-icon warning">
                                <i class="bi bi-person"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card info">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">قيد الصيانة</h6>
                                <h3 class="mb-0"><?php echo $stats['maintenance']; ?></h3>
                                <small class="text-info">تحت الإصلاح</small>
                            </div>
                            <div class="stat-icon info">
                                <i class="bi bi-wrench"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- فلترة البحث -->
        <div class="card mb-4 fade-in">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-4">
                        <input type="text" class="form-control" name="search" 
                               placeholder="بحث بالاسم أو الرقم التسلسلي أو المقاول" 
                               value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="col-md-3">
                        <select class="form-select" name="status">
                            <option value="">كل الحالات</option>
                            <?php foreach($tool_statuses as $key => $status_info): ?>
                            <option value="<?php echo $key; ?>" <?php echo $status == $key ? 'selected' : ''; ?>>
                                <?php echo $status_info['name']; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-search"></i> بحث
                        </button>
                    </div>
                    <div class="col-md-2">
                        <a href="tools.php" class="btn btn-secondary w-100">
                            <i class="bi bi-arrow-clockwise"></i> إعادة تعيين
                        </a>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- الأزرار السريعة -->
        <div class="row mb-4 fade-in">
            <div class="col-12 mb-3">
                <h5 class="section-header">حالات الأدوات</h5>
            </div>
            <?php foreach($tool_statuses as $key => $status_info): ?>
            <div class="col-xl-3 col-lg-4 col-md-6 mb-3">
                <a href="tools.php?status=<?php echo $key; ?>" 
                   class="btn quick-action-btn text-decoration-none">
                    <i class="bi <?php echo $status_info['icon']; ?> text-<?php echo $status_info['color']; ?>"></i>
                    <span class="fw-bold"><?php echo $status_info['name']; ?></span>
                    <small class="text-muted">(<?php echo $stats[$key] ?? 0; ?>)</small>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
        
        <!-- بطاقات الأدوات -->
        <div class="row fade-in">
            <?php if(count($tools) > 0): ?>
                <?php foreach($tools as $tool): 
                    $status_info = $tool_statuses[$tool['current_status']] ?? 
                                  ['name' => 'غير محدد', 'color' => 'secondary', 'icon' => 'bi-question-circle'];
                ?>
                <div class="col-md-4 mb-4">
                    <div class="card tool-card <?php echo $tool['current_status'] == 'with_contractor' ? 'tool-assigned' : 'tool-available'; ?>">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <div>
                                    <h5 class="card-title mb-1"><?php echo htmlspecialchars($tool['tool_name']); ?></h5>
                                    <p class="text-muted mb-0">
                                        <i class="bi bi-upc-scan me-1"></i>
                                        <?php echo htmlspecialchars($tool['serial_number'] ?? 'بدون رقم تسلسلي'); ?>
                                    </p>
                                </div>
                                <span class="badge bg-<?php echo $status_info['color']; ?> tool-status-badge">
                                    <i class="bi <?php echo $status_info['icon']; ?> me-1"></i>
                                    <?php echo $status_info['name']; ?>
                                </span>
                            </div>
                            
                            <?php if($tool['assigned_to_contact_id']): ?>
                            <div class="mb-3">
                                <p class="mb-1">
                                    <i class="bi bi-person me-1"></i>
                                    <strong>مع:</strong> <?php echo htmlspecialchars($tool['contact_name'] ?? '---'); ?>
                                </p>
                                <?php if($tool['phone_number']): ?>
                                <p class="mb-0">
                                    <i class="bi bi-telephone me-1"></i>
                                    <?php echo htmlspecialchars($tool['phone_number']); ?>
                                </p>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                            
                            <?php if($tool['last_check_out']): ?>
                            <div class="mb-3">
                                <small class="text-muted">
                                    <i class="bi bi-calendar me-1"></i>
                                    تاريخ الإعارة: <?php echo date('Y-m-d', strtotime($tool['last_check_out'])); ?>
                                </small>
                            </div>
                            <?php endif; ?>
                            
                            <?php if($tool['notes']): ?>
                            <div class="mb-3">
                                <small class="text-muted">
                                    <i class="bi bi-chat-left-text me-1"></i>
                                    <?php echo htmlspecialchars(substr($tool['notes'], 0, 50)); ?>...
                                </small>
                            </div>
                            <?php endif; ?>
                            
                            <div class="d-flex justify-content-between">
                                <button class="btn btn-sm btn-outline-info" 
                                        onclick="viewTool(<?php echo $tool['tool_id']; ?>)">
                                    <i class="bi bi-eye"></i> عرض
                                </button>
                                <button class="btn btn-sm btn-outline-warning"
                                        onclick="editTool(<?php echo $tool['tool_id']; ?>)">
                                    <i class="bi bi-pencil"></i> تعديل
                                </button>
                                <button class="btn btn-sm btn-outline-danger" 
                                        onclick="deleteTool(<?php echo $tool['tool_id']; ?>, '<?php echo htmlspecialchars($tool['tool_name']); ?>')">
                                    <i class="bi bi-trash"></i> حذف
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
            <div class="col-12">
                <div class="text-center py-5">
                    <i class="bi bi-inbox display-1 text-muted"></i>
                    <h5 class="mt-3">لا توجد أدوات</h5>
                    <p>ابدأ بإضافة أدوات جديدة إلى النظام</p>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- مودال إضافة أداة -->
    <div class="modal fade" id="addToolModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">إضافة أداة/معدة جديدة</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form action="api/save_tool.php" method="POST" id="toolForm">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">اسم الأداة *</label>
                            <input type="text" class="form-control" name="tool_name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">الرقم التسلسلي</label>
                            <input type="text" class="form-control" name="serial_number">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">الحالة الحالية</label>
                            <select class="form-select" name="current_status">
                                <?php foreach($tool_statuses as $key => $status_info): ?>
                                <option value="<?php echo $key; ?>"><?php echo $status_info['name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">معارة إلى</label>
                            <select class="form-select" name="assigned_to_contact_id" id="assignedToSelect">
                                <option value="">غير معارة</option>
                                <?php 
                                $contractors = $pdo->query("SELECT * FROM contacts WHERE contact_type = 'contractor' ORDER BY contact_name")->fetchAll();
                                foreach($contractors as $contractor): ?>
                                <option value="<?php echo $contractor['contact_id']; ?>">
                                    <?php echo htmlspecialchars($contractor['contact_name']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">تاريخ آخر إعارة</label>
                            <input type="date" class="form-control" name="last_check_out">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">ملاحظات</label>
                            <textarea class="form-control" name="notes" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary">حفظ الأداة</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- زر إظهار/إخفاء السايدبار في الجوال -->
    <button class="sidebar-toggle d-md-none" onclick="toggleSidebar()">
        <i class="bi bi-list"></i>
    </button>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="script.js"></script>
    <script>
    function viewTool(id) {
        window.location.href = 'tool_details.php?id=' + id;
    }

    function editTool(id) {
        window.location.href = 'edit_tool.php?id=' + id;
    }

    function deleteTool(id, name) {
        if(confirm(`هل أنت متأكد من حذف الأداة "${name}"؟`)) {
            fetch(`api/delete_tool.php?id=${id}`, {
                method: 'DELETE'
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    alert('تم الحذف بنجاح');
                    window.location.reload();
                } else {
                    alert(data.message || 'حدث خطأ أثناء الحذف');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('حدث خطأ في الاتصال');
            });
        }
    }
    
    // تحديث حقل تاريخ الإعارة بناءً على حالة الأداة
    document.querySelector('select[name="current_status"]').addEventListener('change', function() {
        const assignedSelect = document.getElementById('assignedToSelect');
        const dateInput = document.querySelector('input[name="last_check_out"]');
        
        if(this.value === 'with_contractor') {
            assignedSelect.required = true;
            dateInput.required = true;
        } else {
            assignedSelect.required = false;
            dateInput.required = false;
        }
    });
    
    // معالجة نموذج إضافة الأداة
    document.getElementById('toolForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        
        fetch('api/save_tool.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                alert('تم إضافة الأداة بنجاح');
                window.location.reload();
            } else {
                alert('حدث خطأ: ' + (data.message || 'غير معروف'));
            }
        })
        .catch(error => {
            alert('حدث خطأ في الاتصال بالخادم');
        });
    });
    </script>
</body>
</html>