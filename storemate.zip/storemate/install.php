<?php
if(file_exists('includes/db_connection.php')) {
    header('Location: index.html');
    exit();
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $host = $_POST['host'];
    $dbname = $_POST['dbname'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    try {
        // اختبار الاتصال
        $pdo = new PDO("mysql:host=$host;charset=utf8mb4", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // إنشاء قاعدة البيانات إذا لم تكن موجودة
        $pdo->exec("CREATE DATABASE IF NOT EXISTS $dbname CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci");
        $pdo->exec("USE $dbname");
        
        // تنفيذ SQL
        $sql = file_get_contents('store_mate.sql');
        $pdo->exec($sql);
        
        // إنشاء ملف اتصال قاعدة البيانات
        $config_content = "<?php
// معلومات الاتصال
\$host = '$host';
\$dbname = '$dbname';
\$username = '$username';
\$password = '$password';

// إنشاء اتصال
try {
    \$pdo = new PDO(\"mysql:host=\$host;dbname=\$dbname;charset=utf8mb4\", \$username, \$password);
    \$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    \$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException \$e) {
    die(\"<div style='text-align: center; padding: 50px;'>
        <h3 style='color: #dc3545;'>خطأ في الاتصال بقاعدة البيانات</h3>
        <p>تعذر الاتصال بقاعدة البيانات. الرجاء التحقق من معلومات الاتصال.</p>
    </div>\");
}
?>";
        
        file_put_contents('includes/db_connection.php', $config_content);
        
        // توجيه إلى صفحة تسجيل الدخول
        header('Location: login.php?install=success');
        exit();
        
    } catch(PDOException $e) {
        $error = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تثبيت StoreMate</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .install-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            max-width: 500px;
            width: 100%;
        }
        
        .install-header {
            background: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
            color: white;
            padding: 30px;
            border-radius: 20px 20px 0 0;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="install-card">
        <div class="install-header">
            <h3><i class="bi bi-box-seam me-2"></i>StoreMate</h3>
            <p class="mb-0">إعداد النظام للمرة الأولى</p>
        </div>
        
        <div class="p-4">
            <?php if(isset($error)): ?>
            <div class="alert alert-danger">
                <i class="bi bi-exclamation-triangle me-2"></i>
                <?php echo $error; ?>
            </div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">خادم قاعدة البيانات (Host)</label>
                    <input type="text" class="form-control" name="host" value="localhost" required>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">اسم قاعدة البيانات</label>
                    <input type="text" class="form-control" name="dbname" value="store_mate" required>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">اسم المستخدم</label>
                    <input type="text" class="form-control" name="username" value="root" required>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">كلمة المرور</label>
                    <input type="password" class="form-control" name="password">
                </div>
                
                <div class="alert alert-info">
                    <i class="bi bi-info-circle me-2"></i>
                    تأكد من تشغيل خادم MySQL (XAMPP/WAMP/MAMP)
                </div>
                
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-gear me-2"></i> بدء التثبيت
                    </button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>