<?php
// api/delete_category.php
session_start();
require_once '../includes/db_connection.php';
require_once '../includes/auth_check.php';

header('Content-Type: application/json');

$category_id = intval($_GET['id'] ?? 0);

if ($category_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'معرف الفئة غير صالح']);
    exit;
}

try {
    // التحقق من وجود منتجات مرتبطة بالفئة
    $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE category_id = ?");
    $checkStmt->execute([$category_id]);
    $product_count = $checkStmt->fetchColumn();

    if ($product_count > 0) {
        echo json_encode([
            'success' => false, 
            'message' => 'لا يمكن حذف الفئة لأنها تحتوي على ' . $product_count . ' منتج'
        ]);
        exit;
    }

    // حذف الفئة
    $stmt = $pdo->prepare("DELETE FROM categories WHERE category_id = ?");
    $stmt->execute([$category_id]);

    echo json_encode([
        'success' => true, 
        'message' => 'تم حذف الفئة بنجاح'
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'حدث خطأ في حذف الفئة: ' . $e->getMessage()
    ]);
}
?>