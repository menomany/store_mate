<?php
session_start();
require_once '../includes/db_connection.php';
require_once '../includes/auth_check.php';

header('Content-Type: application/json');

$tool_id = $_GET['id'] ?? 0;

try {
    $stmt = $pdo->prepare("DELETE FROM tools_assets WHERE tool_id = ?");
    $stmt->execute([$tool_id]);
    
    echo json_encode(['success' => true, 'message' => 'تم حذف الأداة بنجاح']);
    
} catch(PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'حدث خطأ: ' . $e->getMessage()]);
}
?>