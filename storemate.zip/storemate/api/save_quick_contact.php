<?php
// api/save_quick_contact.php
session_start();
require_once '../includes/db_connection.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'غير مصرح بالوصول']);
    exit;
}

// قراءة البيانات المرسلة
$data = json_decode(file_get_contents('php://input'), true);

// التحقق من البيانات
if (empty($data['contact_name']) || empty($data['contact_type'])) {
    echo json_encode(['success' => false, 'message' => 'الاسم ونوع الجهة مطلوبان']);
    exit;
}

try {
    $contact_name = trim($data['contact_name']);
    $contact_type = $data['contact_type'];
    $phone_number = !empty($data['phone_number']) ? trim($data['phone_number']) : null;
    
    // التحقق من عدم التكرار
    $check_stmt = $pdo->prepare("SELECT contact_id FROM contacts WHERE contact_name = ?");
    $check_stmt->execute([$contact_name]);
    
    if ($check_stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'جهة الاتصال موجودة بالفعل']);
        exit;
    }
    
    // إدخال جهة الاتصال الجديدة
    $stmt = $pdo->prepare("
        INSERT INTO contacts 
        (contact_name, contact_type, phone_number, created_at)
        VALUES (?, ?, ?, NOW())
    ");
    
    $stmt->execute([$contact_name, $contact_type, $phone_number]);
    
    $contact_id = $pdo->lastInsertId();
    
    echo json_encode([
        'success' => true,
        'message' => 'تم إضافة الجهة بنجاح',
        'contact_id' => $contact_id,
        'contact_name' => $contact_name
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطأ في قاعدة البيانات: ' . $e->getMessage()
    ]);
}