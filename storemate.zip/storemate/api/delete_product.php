<?php
// api/delete_product.php
session_start();
require_once '../includes/db_connection.php';
require_once '../includes/auth_check.php';

header('Content-Type: application/json');

$product_id = $_GET['id'] ?? 0;

try {
    // التحقق من وجود حركات للمنتج
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM transaction_details WHERE product_id = ?");
    $stmt->execute([$product_id]);
    $result = $stmt->fetch();
    
    if ($result['count'] > 0) {
        echo json_encode([
            'success' => false,
            'message' => 'لا يمكن حذف المنتج لوجود حركات مرتبطة به'
        ]);
        exit();
    }
    
    $stmt = $pdo->prepare("DELETE FROM products WHERE product_id = ?");
    $stmt->execute([$product_id]);
    
    echo json_encode(['success' => true, 'message' => 'تم حذف المنتج بنجاح']);
    
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'حدث خطأ: ' . $e->getMessage()]);
}
?>