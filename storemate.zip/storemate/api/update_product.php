<?php

session_start();
require_once '../includes/db_connection.php';
require_once '../includes/auth_check.php';

header('Content-Type: application/json');

try {
    $pdo->beginTransaction();

    // 1. استلام البيانات من النموذج
    $product_id   = intval($_POST['product_id'] ?? 0);
    $product_name = trim($_POST['product_name'] ?? '');
    $product_code = !empty($_POST['product_code']) ? trim($_POST['product_code']) : null;
    $category_id  = !empty($_POST['category_id']) ? intval($_POST['category_id']) : null;
    $is_cable     = isset($_POST['is_cable']) ? 1 : 0;
    $min_stock    = floatval($_POST['min_stock_level'] ?? 0);
    $initial_balance = floatval($_POST['initial_balance'] ?? 0);
    $units        = $_POST['units'] ?? [];

    // 2. التحقق من البيانات المطلوبة
    if (empty($product_name)) {
        echo json_encode(['success' => false, 'message' => 'اسم المنتج مطلوب']);
        exit;
    }

    if ($product_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'معرف المنتج غير صالح']);
        exit;
    }

    // 3. التحقق من وجود وحدات على الأقل
    if (empty($units) || !is_array($units)) {
        echo json_encode(['success' => false, 'message' => 'يجب إضافة وحدة واحدة على الأقل']);
        exit;
    }

    // 4. التحقق من تكرار الكود (استثناء المنتج الحالي)
    if ($product_code !== null) {
        $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE product_code = ? AND product_id != ?");
        $checkStmt->execute([$product_code, $product_id]);
        if ($checkStmt->fetchColumn() > 0) {
            echo json_encode(['success' => false, 'message' => 'عذراً، كود المنتج (الباركود) مستخدم مسبقاً']);
            exit;
        }
    }

    // 5. تحديث بيانات المنتج الأساسية (بدون سعر)
    $sqlProd = "UPDATE products SET 
                product_name = ?, 
                product_code = ?, 
                category_id = ?, 
                is_cable = ?, 
                min_stock_level = ?, 
                initial_balance = ?
                WHERE product_id = ?";
    
    $stmtProd = $pdo->prepare($sqlProd);
    $stmtProd->execute([
        $product_name, 
        $product_code, 
        $category_id, 
        $is_cable, 
        $min_stock,
        $initial_balance,
        $product_id
    ]);

    // 6. معالجة الوحدات
    if (!empty($units) && is_array($units)) {
        // حذف الوحدات القديمة أولاً
        $deleteStmt = $pdo->prepare("DELETE FROM product_units WHERE product_id = ?");
        $deleteStmt->execute([$product_id]);

        // إضافة الوحدات الجديدة
        $sqlUnit = "INSERT INTO product_units (product_id, unit_name, conversion_factor, is_base_unit, unit_price) 
                    VALUES (?, ?, ?, ?, ?)";
        $stmtUnit = $pdo->prepare($sqlUnit);

        foreach ($units as $index => $unit) {
            $u_name   = trim($unit['name'] ?? '');
            $u_price  = floatval($unit['price'] ?? 0);
            $u_factor = floatval($unit['factor'] ?? 1);
            $u_id     = intval($unit['unit_id'] ?? 0);
            
            // تحديد ما إذا كانت الوحدة أساسية (الوحدة الأولى)
            $is_base_unit = ($index == 0) ? 1 : 0;

            if (!empty($u_name)) {
                $stmtUnit->execute([
                    $product_id, 
                    $u_name, 
                    $u_factor, 
                    $is_base_unit, 
                    $u_price
                ]);
            }
        }
    }

    $pdo->commit();
    
    echo json_encode([
        'success' => true, 
        'message' => 'تم تحديث المنتج بنجاح',
        'product_id' => $product_id
    ]);

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    echo json_encode([
        'success' => false, 
        'message' => 'حدث خطأ في تحديث المنتج: ' . $e->getMessage()
    ]);
}
?>