<?php
// api/save_user.php
session_start();
require_once '../includes/db_connection.php';
require_once '../includes/auth_check.php';

header('Content-Type: application/json');

// التحقق من صلاحيات المستخدم
if ($_SESSION['role'] !== 'مدير') {
    echo json_encode(['success' => false, 'message' => 'ليس لديك صلاحية لهذا الإجراء']);
    exit;
}

try {
    // استلام البيانات
    $username = trim($_POST['username'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $email = !empty($_POST['email']) ? trim($_POST['email']) : null;
    $phone = !empty($_POST['phone']) ? trim($_POST['phone']) : null;
    $role = trim($_POST['role'] ?? '');
    $status = trim($_POST['status'] ?? 'active');

    // التحقق من البيانات المطلوبة
    if (empty($username) || empty($full_name) || empty($password) || empty($role)) {
        echo json_encode(['success' => false, 'message' => 'جميع الحقول المطلوبة يجب ملؤها']);
        exit;
    }

    if ($password !== $confirm_password) {
        echo json_encode(['success' => false, 'message' => 'كلمات المرور غير متطابقة']);
        exit;
    }

    if (strlen($password) < 6) {
        echo json_encode(['success' => false, 'message' => 'كلمة المرور يجب أن تكون 6 أحرف على الأقل']);
        exit;
    }

    // التحقق من عدم تكرار اسم المستخدم
    $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
    $checkStmt->execute([$username]);
    if ($checkStmt->fetchColumn() > 0) {
        echo json_encode(['success' => false, 'message' => 'اسم المستخدم موجود مسبقاً']);
        exit;
    }

    // التحقق من عدم تكرار البريد الإلكتروني (إذا تم إدخاله)
    if ($email) {
        $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
        $checkStmt->execute([$email]);
        if ($checkStmt->fetchColumn() > 0) {
            echo json_encode(['success' => false, 'message' => 'البريد الإلكتروني مستخدم مسبقاً']);
            exit;
        }
    }

    // تشفير كلمة المرور
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // حفظ المستخدم
    $sql = "INSERT INTO users (username, full_name, password, email, phone, role, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$username, $full_name, $hashed_password, $email, $phone, $role, $status]);

    echo json_encode([
        'success' => true, 
        'message' => 'تم إضافة المستخدم بنجاح',
        'user_id' => $pdo->lastInsertId()
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'حدث خطأ في حفظ المستخدم: ' . $e->getMessage()
    ]);
}
?>