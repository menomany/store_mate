<?php
// api/activate_user.php
session_start();
require_once '../includes/db_connection.php';
require_once '../includes/auth_check.php';

header('Content-Type: application/json');

// التحقق من صلاحيات المستخدم
if ($_SESSION['role'] !== 'مدير') {
    echo json_encode(['success' => false, 'message' => 'ليس لديك صلاحية لهذا الإجراء']);
    exit;
}

$user_id = intval($_POST['id'] ?? 0);

if ($user_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'معرف المستخدم غير صالح']);
    exit;
}

try {
    // تفعيل المستخدم
    $stmt = $pdo->prepare("UPDATE users SET status = 'active' WHERE id = ?");
    $stmt->execute([$user_id]);

    echo json_encode([
        'success' => true, 
        'message' => 'تم تفعيل المستخدم بنجاح'
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'حدث خطأ في تفعيل المستخدم: ' . $e->getMessage()
    ]);
}
?>