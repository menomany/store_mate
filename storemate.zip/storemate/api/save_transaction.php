<?php
session_start();
require_once '../includes/db_connection.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'غير مصرح بالوصول']);
    exit;
}

// تسجيل البيانات للتصحيح
error_log("=== بدء حفظ حركة جديد ===");
error_log("POST Data: " . print_r($_POST, true));

try {
    $pdo->beginTransaction();
    
    // التحقق من البيانات الأساسية
    $trans_type = $_POST['trans_type'] ?? '';
    $trans_date = $_POST['trans_date'] ?? date('Y-m-d H:i:s');
    
    if (empty($trans_type)) {
        echo json_encode(['success' => false, 'message' => 'نوع الحركة مطلوب']);
        exit;
    }
    
    // معالجة القيم الفارغة وتحويلها إلى NULL
    function cleanValue($value) {
        if (is_null($value) || $value === '' || $value === '0') {
            return null;
        }
        return $value;
    }
    
    $contact_id = cleanValue($_POST['contact_id'] ?? null);
    $project_id = cleanValue($_POST['project_id'] ?? null);
    $from_warehouse_id = cleanValue($_POST['from_warehouse_id'] ?? null);
    $to_warehouse_id = cleanValue($_POST['to_warehouse_id'] ?? null);
    $notes = $_POST['notes'] ?? '';
    $total_amount = floatval($_POST['total_amount'] ?? 0);
    $user_id = $_SESSION['user_id'];
    
    // التحقق من البيانات حسب نوع الحركة
    if ($trans_type !== 'transfer' && $trans_type !== 'issue') {
        if ($contact_id === null) {
            echo json_encode(['success' => false, 'message' => 'جهة الاتصال مطلوبة لهذا النوع من الحركة']);
            exit;
        }
    }
    
    if ($trans_type === 'transfer') {
        if ($from_warehouse_id === null || $to_warehouse_id === null) {
            echo json_encode(['success' => false, 'message' => 'يجب تحديد المخزن المصدر والهدف للتحويل']);
            exit;
        }
    }
    
    // إدخال الحركة الرئيسية
    $stmt = $pdo->prepare("
        INSERT INTO transactions 
        (trans_date, trans_type, contact_id, project_id, from_warehouse_id, to_warehouse_id, total_amount, notes, user_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $trans_date,
        $trans_type,
        $contact_id,
        $project_id,
        $from_warehouse_id,
        $to_warehouse_id,
        $total_amount,
        $notes,
        $user_id
    ]);
    
    $trans_id = $pdo->lastInsertId();
    error_log("تم إدخال الحركة رقم: " . $trans_id);
    
    // معالجة تفاصيل الأصناف
    if(isset($_POST['items']) && is_array($_POST['items']) && count($_POST['items']) > 0) {
        $items_added = 0;
        
        foreach($_POST['items'] as $item_key => $item) {
            // تخطي العناصر الفارغة
            if(empty($item['product_id']) || empty($item['quantity'])) {
                continue;
            }
            
            $product_id = intval($item['product_id']);
            $unit_id = cleanValue($item['unit_id'] ?? null);
            $quantity = floatval($item['quantity']);
            $start_read = floatval($item['start_read'] ?? 0);
            $end_read = floatval($item['end_read'] ?? 0);
            
            // الحصول على سعر الوحدة
            $unit_price = 0;
            if($unit_id) {
                $price_stmt = $pdo->prepare("SELECT unit_price FROM product_units WHERE unit_id = ?");
                $price_stmt->execute([$unit_id]);
                $unit_data = $price_stmt->fetch();
                $unit_price = $unit_data ? floatval($unit_data['unit_price']) : 0;
            }
            
            $total_item_price = $quantity * $unit_price;
            
            // إدخال تفاصيل الحركة
            $detail_stmt = $pdo->prepare("
                INSERT INTO transaction_details 
                (trans_id, product_id, unit_id, start_read, end_read, quantity, unit_price, total_item_price)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $detail_stmt->execute([
                $trans_id,
                $product_id,
                $unit_id,
                $start_read,
                $end_read,
                $quantity,
                $unit_price,
                $total_item_price
            ]);
            
            $items_added++;
        }
        
        if ($items_added === 0) {
            throw new Exception("لم يتم إضافة أي أصناف صحيحة للحركة");
        }
        
        error_log("تم إضافة " . $items_added . " صنف للحركة");
    } else {
        throw new Exception("لم يتم إضافة أي أصناف للحركة");
    }
    
    // تحديث رصيد جهة الاتصال
    if($contact_id && $total_amount > 0) {
        if ($trans_type === 'in') {
            $balance_change = -$total_amount; // مورد يشتري (يزيد مديونيته)
        } elseif ($trans_type === 'out') {
            $balance_change = $total_amount; // عميل يشتري (يزيد رصيده)
        } elseif ($trans_type === 'return') {
            $balance_change = -$total_amount; // مرتجع من عميل (يقل رصيده)
        } else {
            $balance_change = 0;
        }
        
        if ($balance_change != 0) {
            $balance_stmt = $pdo->prepare("
                UPDATE contacts 
                SET current_balance = COALESCE(current_balance, 0) + ?
                WHERE contact_id = ?
            ");
            $balance_stmt->execute([$balance_change, $contact_id]);
            error_log("تم تحديث رصيد جهة الاتصال: " . $balance_change);
        }
    }
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'تم حفظ الحركة بنجاح',
        'trans_id' => $trans_id
    ]);
    
} catch (PDOException $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("خطأ في قاعدة البيانات: " . $e->getMessage());
    error_log("رمز الخطأ: " . $e->getCode());
    echo json_encode([
        'success' => false,
        'message' => 'خطأ في قاعدة البيانات: ' . $e->getMessage(),
        'error_code' => $e->getCode()
    ]);
} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("خطأ عام: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}