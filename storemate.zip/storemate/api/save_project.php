<?php
session_start();
require_once '../includes/db_connection.php';
require_once '../includes/auth_check.php';

header('Content-Type: application/json');

$project_id = $_POST['project_id'] ?? null;
$project_name = trim($_POST['project_name']);
$client_name = trim($_POST['client_name'] ?? '');
$project_location = trim($_POST['project_location'] ?? '');
$budget_limit = $_POST['budget_limit'] ?: null;
$start_date = $_POST['start_date'] ?: null;
$project_status = $_POST['project_status'] ?? 'active';

try {
    if($project_id) {
        // تحديث مشروع موجود
        $stmt = $pdo->prepare("UPDATE projects SET 
            project_name = ?, client_name = ?, project_location = ?, 
            budget_limit = ?, start_date = ?, project_status = ?
            WHERE project_id = ?");
        $stmt->execute([
            $project_name, $client_name, $project_location,
            $budget_limit, $start_date, $project_status,
            $project_id
        ]);
        
        echo json_encode(['success' => true, 'message' => 'تم تحديث المشروع بنجاح']);
    } else {
        // إضافة مشروع جديد
        $stmt = $pdo->prepare("INSERT INTO projects 
            (project_name, client_name, project_location, budget_limit, start_date, project_status) 
            VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $project_name, $client_name, $project_location,
            $budget_limit, $start_date, $project_status
        ]);
        
        echo json_encode(['success' => true, 'message' => 'تم إضافة المشروع بنجاح']);
    }
} catch(PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'حدث خطأ: ' . $e->getMessage()]);
}
?>