<?php
// api/delete_transaction.php
session_start();
require_once '../includes/db_connection.php';

header('Content-Type: application/json');

// التحقق من الصلاحيات
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'غير مسموح بالوصول']);
    exit;
}

// التحقق من وجود المعرف
$trans_id = $_GET['id'] ?? null;
if (!$trans_id) {
    echo json_encode(['success' => false, 'message' => 'معرف الحركة مطلوب']);
    exit;
}

try {
    // بدء معاملة قاعدة البيانات
    $pdo->beginTransaction();
    
    // جلب بيانات الحركة لتحديث الرصيد
    $stmt = $pdo->prepare("SELECT trans_type, contact_id, total_amount FROM transactions WHERE trans_id = ?");
    $stmt->execute([$trans_id]);
    $transaction = $stmt->fetch();
    
    if (!$transaction) {
        echo json_encode(['success' => false, 'message' => 'الحركة غير موجودة']);
        exit;
    }
    
    // تحديث رصيد جهة الاتصال (عكس العملية)
    if (in_array($transaction['trans_type'], ['in', 'out', 'return', 'issue']) && $transaction['contact_id']) {
        $balance_change = 0;
        if (in_array($transaction['trans_type'], ['in', 'return'])) {
            // نقص في المديونية (عكس الإضافة)
            $balance_change = -$transaction['total_amount'];
        } elseif (in_array($transaction['trans_type'], ['out', 'issue'])) {
            // زيادة في المديونية (عكس الإضافة)
            $balance_change = $transaction['total_amount'];
        }
        
        if ($balance_change != 0) {
            $stmt = $pdo->prepare("
                UPDATE contacts 
                SET current_balance = current_balance + ? 
                WHERE contact_id = ?
            ");
            $stmt->execute([$balance_change, $transaction['contact_id']]);
        }
    }
    
    // حذف تفاصيل الحركة
    $stmt = $pdo->prepare("DELETE FROM transaction_details WHERE trans_id = ?");
    $stmt->execute([$trans_id]);
    
    // حذف الحركة الرئيسية
    $stmt = $pdo->prepare("DELETE FROM transactions WHERE trans_id = ?");
    $stmt->execute([$trans_id]);
    
    // تأكيد المعاملة
    $pdo->commit();
    
    echo json_encode(['success' => true, 'message' => 'تم حذف الحركة بنجاح']);
    
} catch (PDOException $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'خطأ في قاعدة البيانات: ' . $e->getMessage()]);
}
?>