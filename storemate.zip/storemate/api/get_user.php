<?php
// api/get_user.php
session_start();
require_once '../includes/db_connection.php';
require_once '../includes/auth_check.php';

header('Content-Type: application/json');

$user_id = intval($_GET['id'] ?? 0);

if ($user_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'معرف المستخدم غير صالح']);
    exit;
}

try {
    $stmt = $pdo->prepare("
        SELECT *, 
        DATE_FORMAT(last_login, '%Y-%m-%d %H:%i') as last_login_formatted,
        DATE_FORMAT(created_at, '%Y-%m-%d %H:%i') as created_at
        FROM users WHERE id = ?
    ");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if ($user) {
        // إزالة كلمة المرور من البيانات المرسلة
        unset($user['password']);
        
        echo json_encode([
            'success' => true,
            'user' => $user
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'المستخدم غير موجود']);
    }

} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'حدث خطأ في جلب بيانات المستخدم: ' . $e->getMessage()
    ]);
}
?>