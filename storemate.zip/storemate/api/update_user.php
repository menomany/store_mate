<?php
// api/update_user.php
session_start();
require_once '../includes/db_connection.php';
require_once '../includes/auth_check.php';

header('Content-Type: application/json');

// التحقق من صلاحيات المستخدم
if ($_SESSION['role'] !== 'مدير') {
    echo json_encode(['success' => false, 'message' => 'ليس لديك صلاحية لهذا الإجراء']);
    exit;
}

try {
    // استلام البيانات
    $user_id = intval($_POST['user_id'] ?? 0);
    $username = trim($_POST['username'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $email = !empty($_POST['email']) ? trim($_POST['email']) : null;
    $phone = !empty($_POST['phone']) ? trim($_POST['phone']) : null;
    $role = trim($_POST['role'] ?? '');
    $status = trim($_POST['status'] ?? 'active');

    // التحقق من البيانات المطلوبة
    if (empty($username) || empty($full_name) || empty($role)) {
        echo json_encode(['success' => false, 'message' => 'جميع الحقول المطلوبة يجب ملؤها']);
        exit;
    }

    if ($user_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'معرف المستخدم غير صالح']);
        exit;
    }

    // التحقق من تطابق كلمات المرور (إذا تم إدخال كلمة مرور جديدة)
    if ($password && $password !== $confirm_password) {
        echo json_encode(['success' => false, 'message' => 'كلمات المرور غير متطابقة']);
        exit;
    }

    if ($password && strlen($password) < 6) {
        echo json_encode(['success' => false, 'message' => 'كلمة المرور يجب أن تكون 6 أحرف على الأقل']);
        exit;
    }

    // التحقق من عدم تكرار اسم المستخدم (استثناء المستخدم الحالي)
    $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? AND id != ?");
    $checkStmt->execute([$username, $user_id]);
    if ($checkStmt->fetchColumn() > 0) {
        echo json_encode(['success' => false, 'message' => 'اسم المستخدم موجود مسبقاً']);
        exit;
    }

    // التحقق من عدم تكرار البريد الإلكتروني (إذا تم إدخاله)
    if ($email) {
        $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ? AND id != ?");
        $checkStmt->execute([$email, $user_id]);
        if ($checkStmt->fetchColumn() > 0) {
            echo json_encode(['success' => false, 'message' => 'البريد الإلكتروني مستخدم مسبقاً']);
            exit;
        }
    }

    // بناء استعلام التحديث
    $update_fields = [
        'username' => $username,
        'full_name' => $full_name,
        'email' => $email,
        'phone' => $phone,
        'role' => $role,
        'status' => $status
    ];

    // إذا تم إدخال كلمة مرور جديدة
    if ($password) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $update_fields['password'] = $hashed_password;
    }

    // بناء SQL ديناميكي
    $sql = "UPDATE users SET ";
    $params = [];
    $updates = [];

    foreach ($update_fields as $field => $value) {
        if ($value !== null) {
            $updates[] = "$field = ?";
            $params[] = $value;
        }
    }

    $sql .= implode(', ', $updates);
    $sql .= " WHERE id = ?";
    $params[] = $user_id;

    // تحديث المستخدم
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    echo json_encode([
        'success' => true, 
        'message' => 'تم تحديث المستخدم بنجاح'
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'حدث خطأ في تحديث المستخدم: ' . $e->getMessage()
    ]);
}
?>