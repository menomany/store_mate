<?php
// api/delete_contact.php
session_start();
require_once '../includes/db_connection.php';

header('Content-Type: application/json');

// التحقق من الصلاحيات
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'غير مسموح بالوصول']);
    exit;
}

// التحقق من وجود المعرف
$contact_id = $_GET['id'] ?? null;
if (!$contact_id) {
    echo json_encode(['success' => false, 'message' => 'معرف جهة الاتصال مطلوب']);
    exit;
}

try {
    // التحقق من وجود حركات مرتبطة بجهة الاتصال
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM transactions WHERE contact_id = ?");
    $stmt->execute([$contact_id]);
    $result = $stmt->fetch();
    
    if ($result['count'] > 0) {
        echo json_encode(['success' => false, 'message' => 'لا يمكن حذف جهة اتصال لها حركات مرتبطة']);
        exit;
    }
    
    // حذف جهة الاتصال
    $stmt = $pdo->prepare("DELETE FROM contacts WHERE contact_id = ?");
    $stmt->execute([$contact_id]);
    
    echo json_encode(['success' => true, 'message' => 'تم حذف جهة الاتصال بنجاح']);
    
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'خطأ في قاعدة البيانات: ' . $e->getMessage()]);
}
?>