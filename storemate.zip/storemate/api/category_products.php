<?php
// category_products.php - لعرض منتجات فئة معينة
session_start();

if (!isset($_SESSION['full_name'])) {
    $_SESSION['full_name'] = 'مستخدم النظام';
    $_SESSION['role'] = 'مدير';
}

require_once 'includes/db_connection.php';
require_once 'includes/auth_check.php';

$page_title = "منتجات الفئة";

// التحقق من وجود معرف الفئة
$category_id = $_GET['id'] ?? 0;
if (!$category_id) {
    header('Location: categories.php');
    exit;
}

// جلب بيانات الفئة
try {
    $stmt = $pdo->prepare("SELECT * FROM categories WHERE category_id = ?");
    $stmt->execute([$category_id]);
    $category = $stmt->fetch();
    
    if (!$category) {
        header('Location: categories.php');
        exit;
    }
} catch (PDOException $e) {
    die("<div class='alert alert-danger'>خطأ في جلب بيانات الفئة: " . $e->getMessage() . "</div>");
}

// جلب منتجات الفئة
try {
    $products_stmt = $pdo->prepare("
        SELECT p.*, 
               COALESCE(p.initial_balance, 0) as initial_balance,
               (SELECT COALESCE(SUM(CASE WHEN t.trans_type IN ('in', 'return') THEN td.quantity ELSE 0 END), 0)
                FROM transaction_details td 
                JOIN transactions t ON td.trans_id = t.trans_id 
                WHERE td.product_id = p.product_id) as total_in,
               (SELECT COALESCE(SUM(CASE WHEN t.trans_type IN ('out', 'issue') THEN td.quantity ELSE 0 END), 0)
                FROM transaction_details td 
                JOIN transactions t ON td.trans_id = t.trans_id 
                WHERE td.product_id = p.product_id) as total_out
        FROM products p 
        WHERE p.category_id = ?
        ORDER BY p.product_name
    ");
    $products_stmt->execute([$category_id]);
    $products = $products_stmt->fetchAll();
} catch (PDOException $e) {
    $products = [];
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($category['category_name']) . ' - ' . $page_title; ?> - StoreMate</title>
    
    <?php include 'includes/styles.php'; ?>
    
    <style>
        .category-header {
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            color: white;
            border-radius: 10px;
            padding: 2rem;
            margin-bottom: 2rem;
        }
        
        .back-button {
            transition: all 0.3s;
        }
        
        .back-button:hover {
            transform: translateX(-5px);
        }
    </style>
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include 'includes/header.php'; ?>
        
        <div class="container mt-4">
            <div class="category-header fade-in">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <div class="d-flex align-items-center mb-3">
                            <a href="categories.php" class="btn btn-light btn-sm me-3 back-button">
                                <i class="bi bi-arrow-right me-1"></i> رجوع للفئات
                            </a>
                            <h2 class="mb-0"><?php echo htmlspecialchars($category['category_name']); ?></h2>
                        </div>
                        <?php if($category['category_description']): ?>
                        <p class="mb-0 opacity-75"><?php echo htmlspecialchars($category['category_description']); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <span class="badge bg-light text-dark fs-6">
                            <i class="bi bi-box-seam me-1"></i>
                            <?php echo count($products); ?> منتج
                        </span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="container">
            <?php if(count($products) > 0): ?>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="bi bi-list-ul me-2"></i> منتجات الفئة
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>اسم المنتج</th>
                                        <th>الكود</th>
                                        <th>المخزون</th>
                                        <th>حد الطلب</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($products as $index => $product): 
                                        $current_stock = (($product['initial_balance'] ?? 0) + ($product['total_in'] ?? 0)) - ($product['total_out'] ?? 0);
                                        $is_low_stock = $current_stock <= ($product['min_stock_level'] ?? 0);
                                    ?>
                                    <tr class="<?php echo $is_low_stock ? 'table-warning' : ''; ?>">
                                        <td><?php echo $index + 1; ?></td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($product['product_name']); ?></strong>
                                            <?php if($product['is_cable'] ?? 0): ?>
                                            <span class="badge bg-info ms-2">كابل</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($product['product_code'] ?? '---'); ?></td>
                                        <td>
                                            <span class="<?php echo $is_low_stock ? 'text-danger fw-bold' : 'text-success'; ?>">
                                                <?php echo number_format($current_stock, 3); ?>
                                            </span>
                                        </td>
                                        <td><?php echo number_format($product['min_stock_level'] ?? 0, 2); ?></td>
                                        <td>
                                            <a href="product_details.php?id=<?php echo $product['product_id']; ?>" 
                                               class="btn btn-sm btn-outline-info">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="card">
                    <div class="card-body">
                        <div class="text-center py-5">
                            <i class="bi bi-inbox display-1 text-muted"></i>
                            <h5 class="mt-3">لا توجد منتجات في هذه الفئة</h5>
                            <p class="text-muted">يمكنك إضافة منتجات جديدة وتصنيفها تحت هذه الفئة</p>
                            <a href="products.php" class="btn btn-primary mt-3">
                                <i class="bi bi-plus-circle me-1"></i>إضافة منتجات
                            </a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php include 'includes/footer.php'; ?>
    <?php include 'includes/scripts.php'; ?>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // يمكن إضافة أي سكريبتات إضافية هنا
    });
    </script>
</body>
</html>