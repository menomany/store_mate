<?php
// api/save_contact.php
session_start();
require_once '../includes/db_connection.php';
require_once '../includes/auth_check.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true) ?: $_POST;

$contact_id = $data['contact_id'] ?? null;
$contact_name = trim($data['contact_name']);
$contact_type = $data['contact_type'];
$phone_number = $data['phone_number'] ?? '';
$address = $data['address'] ?? '';
$initial_balance = $data['initial_balance'] ?: 0;

try {
    if ($contact_id) {
        // تحديث جهة موجودة
        $stmt = $pdo->prepare("UPDATE contacts SET 
            contact_name = ?, contact_type = ?, phone_number = ?, address = ?, 
            initial_balance = ?, current_balance = ? 
            WHERE contact_id = ?");
        $stmt->execute([
            $contact_name, $contact_type, $phone_number, $address,
            $initial_balance, $initial_balance,
            $contact_id
        ]);
        
        echo json_encode(['success' => true, 'message' => 'تم تحديث الجهة بنجاح']);
    } else {
        // إضافة جهة جديدة
        $stmt = $pdo->prepare("INSERT INTO contacts 
            (contact_name, contact_type, phone_number, address, initial_balance, current_balance) 
            VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $contact_name, $contact_type, $phone_number, $address,
            $initial_balance, $initial_balance
        ]);
        
        echo json_encode(['success' => true, 'message' => 'تم إضافة الجهة بنجاح']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'حدث خطأ: ' . $e->getMessage()]);
}
?>