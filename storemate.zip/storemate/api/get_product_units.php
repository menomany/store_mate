<?php
session_start();

// التحقق من وجود المستخدم
if (!isset($_SESSION['full_name'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'غير مصرح']);
    exit;
}

require_once '../includes/db_connection.php';

header('Content-Type: application/json');

$product_id = $_GET['product_id'] ?? 0;

if ($product_id) {
    try {
        // جلب وحدات المنتج
        $stmt = $pdo->prepare("
            SELECT unit_id, unit_name, conversion_factor, is_base_unit, base_unit_price 
            FROM product_units 
            WHERE product_id = ? 
            ORDER BY is_base_unit DESC, conversion_factor
        ");
        $stmt->execute([$product_id]);
        $units = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if ($units) {
            echo json_encode([
                'success' => true,
                'units' => $units
            ]);
        } else {
            // إذا لم توجد وحدات محددة، أنشئ وحدة افتراضية
            echo json_encode([
                'success' => true,
                'units' => [[
                    'unit_id' => 0,
                    'unit_name' => 'قطعة',
                    'conversion_factor' => 1,
                    'is_base_unit' => 1,
                    'base_unit_price' => 0
                ]]
            ]);
        }
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'خطأ في قاعدة البيانات: ' . $e->getMessage()
        ]);
        error_log("خطأ في get_product_units: " . $e->getMessage());
    }
} else {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'لم يتم تحديد المنتج'
    ]);
}
?>