<?php
// api/save_category.php
session_start();
require_once '../includes/db_connection.php';
require_once '../includes/auth_check.php';

header('Content-Type: application/json');

try {
    // استلام البيانات
    $category_name = trim($_POST['category_name'] ?? '');
    $category_description = trim($_POST['category_description'] ?? '');

    // التحقق من البيانات المطلوبة
    if (empty($category_name)) {
        echo json_encode(['success' => false, 'message' => 'اسم الفئة مطلوب']);
        exit;
    }

    // التحقق من عدم تكرار اسم الفئة
    $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM categories WHERE category_name = ?");
    $checkStmt->execute([$category_name]);
    if ($checkStmt->fetchColumn() > 0) {
        echo json_encode(['success' => false, 'message' => 'اسم الفئة موجود مسبقاً']);
        exit;
    }

    // حفظ الفئة
    $sql = "INSERT INTO categories (category_name, category_description) VALUES (?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$category_name, $category_description]);

    echo json_encode([
        'success' => true, 
        'message' => 'تم إضافة الفئة بنجاح',
        'category_id' => $pdo->lastInsertId()
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'حدث خطأ في حفظ الفئة: ' . $e->getMessage()
    ]);
}
?>