<?php
// includes/product_functions.php

/**
 * الحصول على سعر الوحدة الأساسية للمنتج
 * @param int $product_id معرف المنتج
 * @param PDO $pdo كائن الاتصال بقاعدة البيانات
 * @return float سعر الوحدة الأساسية
 */
function getProductBasePrice($product_id, $pdo) {
    try {
        $stmt = $pdo->prepare("SELECT unit_price FROM product_units WHERE product_id = ? AND is_base_unit = 1 LIMIT 1");
        $stmt->execute([$product_id]);
        $result = $stmt->fetch();
        return $result ? floatval($result['unit_price']) : 0.00;
    } catch (Exception $e) {
        return 0.00;
    }
}

/**
 * الحصول على جميع وحدات المنتج
 * @param int $product_id معرف المنتج
 * @param PDO $pdo كائن الاتصال بقاعدة البيانات
 * @return array وحدات المنتج
 */
function getProductUnits($product_id, $pdo) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM product_units WHERE product_id = ? ORDER BY conversion_factor");
        $stmt->execute([$product_id]);
        return $stmt->fetchAll();
    } catch (Exception $e) {
        return [];
    }
}

/**
 * الحصول على الوحدة الأساسية للمنتج
 * @param int $product_id معرف المنتج
 * @param PDO $pdo كائن الاتصال بقاعدة البيانات
 * @return array بيانات الوحدة الأساسية
 */
function getProductBaseUnit($product_id, $pdo) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM product_units WHERE product_id = ? AND is_base_unit = 1 LIMIT 1");
        $stmt->execute([$product_id]);
        return $stmt->fetch();
    } catch (Exception $e) {
        return null;
    }
}
?>