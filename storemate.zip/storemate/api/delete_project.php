<?php
session_start();
require_once '../includes/db_connection.php';
require_once '../includes/auth_check.php';

header('Content-Type: application/json');

$project_id = $_GET['id'] ?? 0;

try {
    // التحقق من وجود حركات للمشروع
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM transactions WHERE project_id = ?");
    $stmt->execute([$project_id]);
    $result = $stmt->fetch();
    
    if($result['count'] > 0) {
        echo json_encode([
            'success' => false,
            'message' => 'لا يمكن حذف المشروع لوجود حركات مرتبطة به'
        ]);
        exit();
    }
    
    $stmt = $pdo->prepare("DELETE FROM projects WHERE project_id = ?");
    $stmt->execute([$project_id]);
    
    echo json_encode(['success' => true, 'message' => 'تم حذف المشروع بنجاح']);
    
} catch(PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'حدث خطأ: ' . $e->getMessage()]);
}
?>