<?php
// api/update_category.php
session_start();
require_once '../includes/db_connection.php';
require_once '../includes/auth_check.php';

header('Content-Type: application/json');

try {
    // استلام البيانات
    $category_id = intval($_POST['category_id'] ?? 0);
    $category_name = trim($_POST['category_name'] ?? '');
    $category_description = trim($_POST['category_description'] ?? '');

    // التحقق من البيانات المطلوبة
    if (empty($category_name)) {
        echo json_encode(['success' => false, 'message' => 'اسم الفئة مطلوب']);
        exit;
    }

    if ($category_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'معرف الفئة غير صالح']);
        exit;
    }

    // التحقق من عدم تكرار اسم الفئة (استثناء الفئة الحالية)
    $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM categories WHERE category_name = ? AND category_id != ?");
    $checkStmt->execute([$category_name, $category_id]);
    if ($checkStmt->fetchColumn() > 0) {
        echo json_encode(['success' => false, 'message' => 'اسم الفئة موجود مسبقاً']);
        exit;
    }

    // تحديث الفئة
    $sql = "UPDATE categories SET category_name = ?, category_description = ? WHERE category_id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$category_name, $category_description, $category_id]);

    echo json_encode([
        'success' => true, 
        'message' => 'تم تحديث الفئة بنجاح'
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'حدث خطأ في تحديث الفئة: ' . $e->getMessage()
    ]);
}
?>