<?php
// api/delete_user.php
session_start();
require_once '../includes/db_connection.php';
require_once '../includes/auth_check.php';

header('Content-Type: application/json');

// التحقق من صلاحيات المستخدم
if ($_SESSION['role'] !== 'مدير') {
    echo json_encode(['success' => false, 'message' => 'ليس لديك صلاحية لهذا الإجراء']);
    exit;
}

$user_id = intval($_GET['id'] ?? 0);

if ($user_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'معرف المستخدم غير صالح']);
    exit;
}

// منع حذف المستخدم الحالي
if ($user_id == ($_SESSION['user_id'] ?? 0)) {
    echo json_encode(['success' => false, 'message' => 'لا يمكنك حذف حسابك الشخصي']);
    exit;
}

try {
    // التحقق من وجود عمليات مرتبطة بالمستخدم
    $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM transactions WHERE user_id = ?");
    $checkStmt->execute([$user_id]);
    $transactions_count = $checkStmt->fetchColumn();

    if ($transactions_count > 0) {
        echo json_encode([
            'success' => false, 
            'message' => 'لا يمكن حذف المستخدم لأنه قام بـ ' . $transactions_count . ' عملية'
        ]);
        exit;
    }

    // حذف المستخدم
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$user_id]);

    echo json_encode([
        'success' => true, 
        'message' => 'تم حذف المستخدم بنجاح'
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'حدث خطأ في حذف المستخدم: ' . $e->getMessage()
    ]);
}
?>