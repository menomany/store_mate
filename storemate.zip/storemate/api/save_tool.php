<?php
session_start();
require_once '../includes/db_connection.php';
require_once '../includes/auth_check.php';

header('Content-Type: application/json');

$tool_id = $_POST['tool_id'] ?? null;
$tool_name = trim($_POST['tool_name']);
$serial_number = trim($_POST['serial_number'] ?? '');
$current_status = $_POST['current_status'] ?? 'in_store';
$assigned_to_contact_id = $_POST['assigned_to_contact_id'] ?: null;
$notes = trim($_POST['notes'] ?? '');

try {
    if($tool_id) {
        // تحديث أداة موجودة
        $stmt = $pdo->prepare("UPDATE tools_assets SET 
            tool_name = ?, serial_number = ?, current_status = ?, 
            assigned_to_contact_id = ?, notes = ?
            WHERE tool_id = ?");
        $stmt->execute([
            $tool_name, $serial_number, $current_status,
            $assigned_to_contact_id, $notes,
            $tool_id
        ]);
        
        echo json_encode(['success' => true, 'message' => 'تم تحديث الأداة بنجاح']);
    } else {
        // إضافة أداة جديدة
        $stmt = $pdo->prepare("INSERT INTO tools_assets 
            (tool_name, serial_number, current_status, assigned_to_contact_id, notes) 
            VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([
            $tool_name, $serial_number, $current_status,
            $assigned_to_contact_id, $notes
        ]);
        
        echo json_encode(['success' => true, 'message' => 'تم إضافة الأداة بنجاح']);
    }
} catch(PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'حدث خطأ: ' . $e->getMessage()]);
}
?>