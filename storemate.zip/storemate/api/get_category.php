<?php
// api/get_category.php
session_start();
require_once '../includes/db_connection.php';
require_once '../includes/auth_check.php';

header('Content-Type: application/json');

$category_id = intval($_GET['id'] ?? 0);

if ($category_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'معرف الفئة غير صالح']);
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT * FROM categories WHERE category_id = ?");
    $stmt->execute([$category_id]);
    $category = $stmt->fetch();

    if ($category) {
        echo json_encode([
            'success' => true,
            'category' => $category
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'الفئة غير موجودة']);
    }

} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'حدث خطأ في جلب بيانات الفئة: ' . $e->getMessage()
    ]);
}
?>