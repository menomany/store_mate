<?php
// header.php - شريط التنقل العلوي المشترك
if(!isset($page_title)) {
    $page_title = "StoreMate";
}
?>
<!-- شريط التنقل العلوي -->
<nav class="navbar navbar-expand-lg navbar-dark navbar-custom mb-4">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="dashboard.php">
            <i class="bi bi-box-seam me-2 fs-4"></i>
            <span class="fw-bold fs-4">StoreMate</span>
        </a>
        
        <div class="d-flex align-items-center">
            <!-- شريط البحث -->
            <div class="search-box me-3">
                <input type="text" class="form-control" placeholder="بحث سريع..." style="width: 250px;">
                <i class="bi bi-search"></i>
            </div>
            
            <!-- الإشعارات -->
            <div class="dropdown me-3">
                <button class="btn btn-outline-light position-relative" type="button" data-bs-toggle="dropdown">
                    <i class="bi bi-bell"></i>
                    <?php 
                    // جلب عدد المنتجات منخفضة المخزون للإشعارات
                    $low_stock_count = 0;
                    if(isset($pdo)) {
                        $stmt = $pdo->query("SELECT COUNT(*) as low_stock FROM products p WHERE (SELECT COALESCE(SUM(CASE WHEN t.trans_type IN ('in', 'return') THEN td.quantity ELSE -td.quantity END), 0) FROM transaction_details td JOIN transactions t ON td.trans_id = t.trans_id WHERE td.product_id = p.product_id) <= p.min_stock_level");
                        $low_stock_count = $stmt->fetch()['low_stock'];
                    }
                    ?>
                    <?php if($low_stock_count > 0): ?>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        <?php echo $low_stock_count; ?>
                    </span>
                    <?php endif; ?>
                </button>
                <div class="dropdown-menu dropdown-menu-end p-0" style="min-width: 300px;">
                    <div class="dropdown-header bg-light">
                        <h6 class="mb-0">الإشعارات</h6>
                    </div>
                    <div class="dropdown-body" style="max-height: 300px; overflow-y: auto;">
                        <?php if($low_stock_count > 0): ?>
                        <a href="products.php?low_stock=1" class="dropdown-item d-flex align-items-center py-2">
                            <div class="bg-warning text-white rounded-circle p-2 me-2">
                                <i class="bi bi-exclamation-triangle"></i>
                            </div>
                            <div>
                                <small class="d-block">منتجات منخفضة المخزون</small>
                                <small class="text-muted"><?php echo $low_stock_count; ?> منتج يحتاج للتزويد</small>
                            </div>
                        </a>
                        <?php endif; ?>
                    </div>
                    <div class="dropdown-footer text-center p-2 border-top">
                        <small><a href="#" class="text-decoration-none">عرض الكل</a></small>
                    </div>
                </div>
            </div>
            
            <!-- الملف الشخصي -->
            <div class="dropdown">
                <button class="btn btn-outline-light dropdown-toggle d-flex align-items-center" type="button" data-bs-toggle="dropdown">
                    <div class="user-avatar me-2">
                        <?php echo isset($_SESSION['full_name']) ? substr($_SESSION['full_name'], 0, 1) : 'U'; ?>
                    </div>
                    <div class="text-start">
                        <small class="d-block"><?php echo $_SESSION['full_name'] ?? 'مستخدم'; ?></small>
                        <small class="d-block opacity-75"><?php echo $_SESSION['role'] ?? 'مستخدم'; ?></small>
                    </div>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="profile.php">
                        <i class="bi bi-person me-2"></i> الملف الشخصي
                    </a></li>
                    <li><a class="dropdown-item" href="settings.php">
                        <i class="bi bi-gear me-2"></i> الإعدادات
                    </a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger" href="logout.php">
                        <i class="bi bi-box-arrow-right me-2"></i> تسجيل الخروج
                    </a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>