<?php
session_start();

if (!isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}

require_once 'includes/db_connection.php';
require_once 'includes/auth_check.php';

$page_title = "التقارير والإحصائيات";

// التواريخ الافتراضية (الشهر الحالي)
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-t');
$report_type = $_GET['report_type'] ?? 'sales';

// تقرير المبيعات
if ($report_type === 'sales') {
    // حساب إجمالي المبيعات
    $sales_query = "
        SELECT 
            DATE(t.trans_date) as date,
            COUNT(*) as count,
            SUM(t.total_amount) as total
        FROM transactions t
        WHERE t.trans_type IN ('out', 'issue')
        AND DATE(t.trans_date) BETWEEN ? AND ?
        GROUP BY DATE(t.trans_date)
        ORDER BY date
    ";
    
    $sales_stmt = $pdo->prepare($sales_query);
    $sales_stmt->execute([$start_date, $end_date]);
    $sales_data = $sales_stmt->fetchAll();
    
    $total_sales = 0;
    foreach($sales_data as $sale) {
        $total_sales += $sale['total'];
    }
}

// تقرير المشتريات
if ($report_type === 'purchases') {
    $purchases_query = "
        SELECT 
            DATE(t.trans_date) as date,
            COUNT(*) as count,
            SUM(t.total_amount) as total
        FROM transactions t
        WHERE t.trans_type = 'in'
        AND DATE(t.trans_date) BETWEEN ? AND ?
        GROUP BY DATE(t.trans_date)
        ORDER BY date
    ";
    
    $purchases_stmt = $pdo->prepare($purchases_query);
    $purchases_stmt->execute([$start_date, $end_date]);
    $purchases_data = $purchases_stmt->fetchAll();
    
    $total_purchases = 0;
    foreach($purchases_data as $purchase) {
        $total_purchases += $purchase['total'];
    }
}

// تقرير المخزون
if ($report_type === 'inventory') {
    // المنتجات المنخفضة المخزون
    $low_stock_query = "
        SELECT p.*, c.category_name,
            (COALESCE((SELECT SUM(CASE WHEN t.trans_type IN ('in', 'return') THEN td.quantity ELSE 0 END)
                FROM transaction_details td 
                JOIN transactions t ON td.trans_id = t.trans_id 
                WHERE td.product_id = p.product_id), 0)
            -
            COALESCE((SELECT SUM(CASE WHEN t.trans_type IN ('out', 'issue') THEN td.quantity ELSE 0 END)
                FROM transaction_details td 
                JOIN transactions t ON td.trans_id = t.trans_id 
                WHERE td.product_id = p.product_id), 0)) as current_stock
        FROM products p 
        LEFT JOIN categories c ON p.category_id = c.category_id
        HAVING current_stock <= p.min_stock_level
        ORDER BY current_stock ASC
        LIMIT 20
    ";
    
    $low_stock_stmt = $pdo->query($low_stock_query);
    $low_stock_products = $low_stock_stmt->fetchAll();
    
    // المنتجات الأكثر مبيعاً
    $top_selling_query = "
        SELECT 
            p.product_id,
            p.product_name,
            c.category_name,
            SUM(td.quantity) as total_sold,
            SUM(td.total_item_price) as total_revenue
        FROM transaction_details td
        JOIN transactions t ON td.trans_id = t.trans_id
        JOIN products p ON td.product_id = p.product_id
        LEFT JOIN categories c ON p.category_id = c.category_id
        WHERE t.trans_type IN ('out', 'issue')
        AND DATE(t.trans_date) BETWEEN ? AND ?
        GROUP BY p.product_id
        ORDER BY total_sold DESC
        LIMIT 10
    ";
    
    $top_selling_stmt = $pdo->prepare($top_selling_query);
    $top_selling_stmt->execute([$start_date, $end_date]);
    $top_selling_products = $top_selling_stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - StoreMate</title>
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.rtl.min.css">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/css/bootstrap-icons.css">
    
    <!-- الخط العربي -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <!-- الأنماط العامة -->
    <?php include 'includes/styles.php'; ?>
    
    <style>
        .report-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            height: 100%;
        }
        
        .stat-number {
            font-size: 2.5rem;
            font-weight: bold;
            color: var(--primary-color);
        }
        
        .chart-container {
            position: relative;
            height: 300px;
            width: 100%;
        }
        
        .nav-tabs .nav-link {
            border: none;
            color: #666;
            font-weight: 600;
            padding: 10px 20px;
        }
        
        .nav-tabs .nav-link.active {
            color: var(--primary-color);
            border-bottom: 3px solid var(--primary-color);
        }
    </style>
</head>
<body>
    <!-- السايدبار -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- الشريط العلوي -->
        <?php include 'includes/header.php'; ?>
        
        <!-- بطاقة الترحيب -->
        <div class="welcome-card fade-in">
            <div class="container p-4 position-relative">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h2 class="mb-2">التقارير والإحصائيات</h2>
                        <p class="mb-0 opacity-75">تحليلات وأداء النظام</p>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <button class="btn btn-light" onclick="printReport()">
                            <i class="bi bi-printer me-1"></i>طباعة التقرير
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- فلترة التقارير -->
        <div class="card mb-4 fade-in">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">نوع التقرير</label>
                        <select class="form-select" name="report_type" onchange="this.form.submit()">
                            <option value="sales" <?php echo $report_type === 'sales' ? 'selected' : ''; ?>>تقرير المبيعات</option>
                            <option value="purchases" <?php echo $report_type === 'purchases' ? 'selected' : ''; ?>>تقرير المشتريات</option>
                            <option value="inventory" <?php echo $report_type === 'inventory' ? 'selected' : ''; ?>>تقرير المخزون</option>
                            <option value="financial" <?php echo $report_type === 'financial' ? 'selected' : ''; ?>>تقرير مالي</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">من تاريخ</label>
                        <input type="date" class="form-control" name="start_date" 
                               value="<?php echo $start_date; ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">إلى تاريخ</label>
                        <input type="date" class="form-control" name="end_date" 
                               value="<?php echo $end_date; ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">&nbsp;</label>
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-filter me-1"></i> تصفية
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- إحصائيات سريعة -->
        <div class="row mb-4 fade-in">
            <div class="col-md-3">
                <div class="report-card">
                    <div class="card-body text-center">
                        <i class="bi bi-cart-check display-4 text-primary mb-3"></i>
                        <h5 class="stat-number">
                            <?php echo number_format($total_sales ?? 0, 2); ?> 
                            <small class="fs-6">EGP</small>
                        </h5>
                        <p class="text-muted mb-0">إجمالي المبيعات</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="report-card">
                    <div class="card-body text-center">
                        <i class="bi bi-truck display-4 text-success mb-3"></i>
                        <h5 class="stat-number">
                            <?php echo number_format($total_purchases ?? 0, 2); ?>
                            <small class="fs-6">EGP</small>
                        </h5>
                        <p class="text-muted mb-0">إجمالي المشتريات</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="report-card">
                    <div class="card-body text-center">
                        <i class="bi bi-box-seam display-4 text-warning mb-3"></i>
                        <h5 class="stat-number">
                            <?php echo count($low_stock_products ?? []); ?>
                        </h5>
                        <p class="text-muted mb-0">منتجات منخفضة المخزون</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="report-card">
                    <div class="card-body text-center">
                        <i class="bi bi-graph-up display-4 text-info mb-3"></i>
                        <h5 class="stat-number">
                            <?php 
                            $total_trans = 0;
                            if (isset($sales_data)) $total_trans += count($sales_data);
                            if (isset($purchases_data)) $total_trans += count($purchases_data);
                            echo $total_trans;
                            ?>
                        </h5>
                        <p class="text-muted mb-0">إجمالي الحركات</p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- التبويبات -->
        <div class="card fade-in">
            <div class="card-body">
                <ul class="nav nav-tabs mb-4" id="reportTabs">
                    <li class="nav-item">
                        <a class="nav-link <?php echo $report_type === 'sales' ? 'active' : ''; ?>" 
                           href="reports.php?report_type=sales&start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>">
                            المبيعات
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $report_type === 'purchases' ? 'active' : ''; ?>" 
                           href="reports.php?report_type=purchases&start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>">
                            المشتريات
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $report_type === 'inventory' ? 'active' : ''; ?>" 
                           href="reports.php?report_type=inventory&start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>">
                            المخزون
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $report_type === 'financial' ? 'active' : ''; ?>" 
                           href="reports.php?report_type=financial&start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>">
                            التقرير المالي
                        </a>
                    </li>
                </ul>
                
                <div id="reportContent">
                    <?php if ($report_type === 'sales'): ?>
                    <!-- تقرير المبيعات -->
                    <div class="row">
                        <div class="col-md-8">
                            <div class="chart-container">
                                <canvas id="salesChart"></canvas>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <h5>تفاصيل المبيعات</h5>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>التاريخ</th>
                                            <th>عدد الحركات</th>
                                            <th>الإجمالي</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($sales_data as $sale): ?>
                                        <tr>
                                            <td><?php echo $sale['date']; ?></td>
                                            <td><?php echo $sale['count']; ?></td>
                                            <td><?php echo number_format($sale['total'], 2); ?> EGP</td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <script>
                    const salesCtx = document.getElementById('salesChart').getContext('2d');
                    const salesChart = new Chart(salesCtx, {
                        type: 'line',
                        data: {
                            labels: [<?php echo implode(',', array_map(function($s) { return "'" . $s['date'] . "'"; }, $sales_data)); ?>],
                            datasets: [{
                                label: 'المبيعات اليومية',
                                data: [<?php echo implode(',', array_map(function($s) { return $s['total']; }, $sales_data)); ?>],
                                borderColor: '#3498db',
                                backgroundColor: 'rgba(52, 152, 219, 0.1)',
                                fill: true,
                                tension: 0.4
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                title: {
                                    display: true,
                                    text: 'تطور المبيعات اليومية'
                                }
                            },
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    title: {
                                        display: true,
                                        text: 'القيمة (EGP)'
                                    }
                                }
                            }
                        }
                    });
                    </script>
                    
                    <?php elseif ($report_type === 'purchases'): ?>
                    <!-- تقرير المشتريات -->
                    <div class="row">
                        <div class="col-md-8">
                            <div class="chart-container">
                                <canvas id="purchasesChart"></canvas>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <h5>تفاصيل المشتريات</h5>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>التاريخ</th>
                                            <th>عدد الحركات</th>
                                            <th>الإجمالي</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($purchases_data as $purchase): ?>
                                        <tr>
                                            <td><?php echo $purchase['date']; ?></td>
                                            <td><?php echo $purchase['count']; ?></td>
                                            <td><?php echo number_format($purchase['total'], 2); ?> EGP</td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <script>
                    const purchasesCtx = document.getElementById('purchasesChart').getContext('2d');
                    const purchasesChart = new Chart(purchasesCtx, {
                        type: 'bar',
                        data: {
                            labels: [<?php echo implode(',', array_map(function($p) { return "'" . $p['date'] . "'"; }, $purchases_data)); ?>],
                            datasets: [{
                                label: 'المشتريات اليومية',
                                data: [<?php echo implode(',', array_map(function($p) { return $p['total']; }, $purchases_data)); ?>],
                                backgroundColor: '#27ae60',
                                borderColor: '#219653',
                                borderWidth: 1
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                title: {
                                    display: true,
                                    text: 'تطور المشتريات اليومية'
                                }
                            },
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    title: {
                                        display: true,
                                        text: 'القيمة (EGP)'
                                    }
                                }
                            }
                        }
                    });
                    </script>
                    
                    <?php elseif ($report_type === 'inventory'): ?>
                    <!-- تقرير المخزون -->
                    <div class="row">
                        <div class="col-md-6">
                            <h5>المنتجات المنخفضة المخزون</h5>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>المنتج</th>
                                            <th>الفئة</th>
                                            <th>المخزون الحالي</th>
                                            <th>حد الطلب</th>
                                            <th>الحالة</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($low_stock_products as $product): 
                                            $status_class = ($product['current_stock'] <= 0) ? 'text-danger' : 'text-warning';
                                            $status_text = ($product['current_stock'] <= 0) ? 'نفذ' : 'منخفض';
                                        ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($product['product_name']); ?></td>
                                            <td><?php echo htmlspecialchars($product['category_name']); ?></td>
                                            <td><?php echo number_format($product['current_stock'], 2); ?></td>
                                            <td><?php echo number_format($product['min_stock_level'], 2); ?></td>
                                            <td class="<?php echo $status_class; ?> fw-bold">
                                                <?php echo $status_text; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <h5>المنتجات الأكثر مبيعاً</h5>
                            <div class="chart-container">
                                <canvas id="topProductsChart"></canvas>
                            </div>
                            
                            <div class="table-responsive mt-3">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>المنتج</th>
                                            <th>الكمية المباعة</th>
                                            <th>الإيرادات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($top_selling_products as $product): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($product['product_name']); ?></td>
                                            <td><?php echo number_format($product['total_sold'], 2); ?></td>
                                            <td><?php echo number_format($product['total_revenue'], 2); ?> EGP</td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <script>
                    const topCtx = document.getElementById('topProductsChart').getContext('2d');
                    const topChart = new Chart(topCtx, {
                        type: 'doughnut',
                        data: {
                            labels: [<?php echo implode(',', array_map(function($p) { return "'" . $p['product_name'] . "'"; }, array_slice($top_selling_products, 0, 5))); ?>],
                            datasets: [{
                                label: 'الكمية المباعة',
                                data: [<?php echo implode(',', array_map(function($p) { return $p['total_sold']; }, array_slice($top_selling_products, 0, 5))); ?>],
                                backgroundColor: [
                                    '#3498db',
                                    '#27ae60',
                                    '#e74c3c',
                                    '#f39c12',
                                    '#9b59b6'
                                ]
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                title: {
                                    display: true,
                                    text: 'المنتجات الأكثر مبيعاً'
                                },
                                legend: {
                                    position: 'bottom'
                                }
                            }
                        }
                    });
                    </script>
                    
                    <?php elseif ($report_type === 'financial'): ?>
                    <!-- التقرير المالي -->
                    <?php
                    // حساب الإيرادات
                    $revenue_query = "
                        SELECT SUM(total_amount) as total
                        FROM transactions
                        WHERE trans_type IN ('out', 'issue')
                        AND DATE(trans_date) BETWEEN ? AND ?
                    ";
                    
                    $revenue_stmt = $pdo->prepare($revenue_query);
                    $revenue_stmt->execute([$start_date, $end_date]);
                    $revenue = $revenue_stmt->fetch()['total'] ?? 0;
                    
                    // حساب المصروفات (المشتريات)
                    $expenses_query = "
                        SELECT SUM(total_amount) as total
                        FROM transactions
                        WHERE trans_type = 'in'
                        AND DATE(trans_date) BETWEEN ? AND ?
                    ";
                    
                    $expenses_stmt = $pdo->prepare($expenses_query);
                    $expenses_stmt->execute([$start_date, $end_date]);
                    $expenses = $expenses_stmt->fetch()['total'] ?? 0;
                    
                    // صافي الربح
                    $profit = $revenue - $expenses;
                    ?>
                    
                    <div class="row">
                        <div class="col-md-8">
                            <div class="chart-container">
                                <canvas id="financialChart"></canvas>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="row">
                                <div class="col-12 mb-3">
                                    <div class="card bg-success text-white">
                                        <div class="card-body text-center">
                                            <h6>الإيرادات</h6>
                                            <h3><?php echo number_format($revenue, 2); ?> EGP</h3>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-12 mb-3">
                                    <div class="card bg-danger text-white">
                                        <div class="card-body text-center">
                                            <h6>المصروفات</h6>
                                            <h3><?php echo number_format($expenses, 2); ?> EGP</h3>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-12">
                                    <div class="card bg-primary text-white">
                                        <div class="card-body text-center">
                                            <h6>صافي الربح</h6>
                                            <h3><?php echo number_format($profit, 2); ?> EGP</h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <script>
                    const financialCtx = document.getElementById('financialChart').getContext('2d');
                    const financialChart = new Chart(financialCtx, {
                        type: 'bar',
                        data: {
                            labels: ['الإيرادات', 'المصروفات', 'صافي الربح'],
                            datasets: [{
                                label: 'القيمة (EGP)',
                                data: [<?php echo $revenue; ?>, <?php echo $expenses; ?>, <?php echo $profit; ?>],
                                backgroundColor: [
                                    '#27ae60',
                                    '#e74c3c',
                                    '#3498db'
                                ]
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                title: {
                                    display: true,
                                    text: 'التحليل المالي'
                                }
                            },
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    title: {
                                        display: true,
                                        text: 'القيمة (EGP)'
                                    }
                                }
                            }
                        }
                    });
                    </script>
                    
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- الفوتر -->
    <?php include 'includes/footer.php'; ?>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    function printReport() {
        const printContent = document.getElementById('reportContent').innerHTML;
        const originalContent = document.body.innerHTML;
        
        document.body.innerHTML = `
            <!DOCTYPE html>
            <html lang="ar" dir="rtl">
            <head>
                <meta charset="UTF-8">
                <title>تقرير StoreMate</title>
                <style>
                    body { font-family: 'Cairo', sans-serif; padding: 20px; }
                    .print-header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #000; padding-bottom: 10px; }
                    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                    th, td { border: 1px solid #ddd; padding: 8px; text-align: right; }
                    th { background-color: #f2f2f2; }
                    .total-row { font-weight: bold; background-color: #f8f9fa; }
                    @media print {
                        .no-print { display: none; }
                    }
                </style>
            </head>
            <body>
                <div class="print-header">
                    <h2>تقرير StoreMate</h2>
                    <p>الفترة من <?php echo $start_date; ?> إلى <?php echo $end_date; ?></p>
                    <p>نوع التقرير: <?php 
                        $report_types = [
                            'sales' => 'تقرير المبيعات',
                            'purchases' => 'تقرير المشتريات', 
                            'inventory' => 'تقرير المخزون',
                            'financial' => 'التقرير المالي'
                        ];
                        echo $report_types[$report_type] ?? 'غير محدد';
                    ?></p>
                    <p>تاريخ الطباعة: <?php echo date('Y-m-d H:i'); ?></p>
                </div>
                ${printContent}
                <div class="no-print" style="text-align: center; margin-top: 30px;">
                    <button onclick="window.print()" class="btn btn-primary">طباعة</button>
                    <button onclick="document.body.innerHTML = originalContent; window.location.reload();" class="btn btn-secondary">إلغاء</button>
                </div>
            </body>
            </html>
        `;
        
        window.print();
        document.body.innerHTML = originalContent;
        window.location.reload();
    }
    </script>
</body>
</html>