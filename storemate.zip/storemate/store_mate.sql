-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 31 يناير 2026 الساعة 14:14
-- إصدار الخادم: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `store_mate`
--


-- --------------------------------------------------------

--
-- بنية الجدول `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `category_description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- إرجاع أو استيراد بيانات الجدول `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`, `category_description`, `created_at`) VALUES
(1, 'كهرباء', NULL, '2026-01-27 12:14:09'),
(2, 'سباكة', NULL, '2026-01-27 12:14:09'),
(3, 'عدد و أدوات', '', '2026-01-27 12:14:09'),
(4, 'فاير', 'انظمه مكافحه الحريق', '2026-01-30 10:38:13');

-- --------------------------------------------------------

--
-- بنية الجدول `company_profile`
--

CREATE TABLE `company_profile` (
  `id` int(11) NOT NULL DEFAULT 1,
  `company_name` varchar(255) NOT NULL,
  `logo_path` varchar(255) DEFAULT NULL,
  `tax_number` varchar(50) DEFAULT NULL,
  `commercial_register` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `phone_1` varchar(20) DEFAULT NULL,
  `phone_2` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `currency_name` varchar(20) DEFAULT 'EGP',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- إرجاع أو استيراد بيانات الجدول `company_profile`
--

INSERT INTO `company_profile` (`id`, `company_name`, `logo_path`, `tax_number`, `commercial_register`, `address`, `phone_1`, `phone_2`, `email`, `currency_name`, `updated_at`) VALUES
(1, 'DSS', NULL, '', '', '', '', '', '', 'EGP', '2026-01-28 08:47:24');

-- --------------------------------------------------------

--
-- بنية الجدول `contacts`
--

CREATE TABLE `contacts` (
  `contact_id` int(11) NOT NULL,
  `contact_name` varchar(255) NOT NULL,
  `contact_type` enum('supplier','contractor','customer') NOT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `initial_balance` decimal(15,2) DEFAULT 0.00,
  `current_balance` decimal(15,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- إرجاع أو استيراد بيانات الجدول `contacts`
--

INSERT INTO `contacts` (`contact_id`, `contact_name`, `contact_type`, `phone_number`, `address`, `initial_balance`, `current_balance`, `created_at`) VALUES
(1, 'مورد الكهرباء', 'supplier', '01012345678', NULL, '0.00', '0.00', '2026-01-27 12:14:09'),
(2, 'عميل أحمد', 'customer', '01123456789', '', '0.00', '0.00', '2026-01-27 12:14:09'),
(4, 'محمد النعماني', 'supplier', '01020063977', 'مركز المحمودية محافظة البحيرة', '0.00', '10000.00', '2026-01-28 08:06:19');

-- --------------------------------------------------------

--
-- بنية الجدول `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_code` varchar(50) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `initial_balance` decimal(10,2) DEFAULT NULL,
  `min_stock_level` decimal(10,2) DEFAULT NULL,
  `total_balance` decimal(15,3) DEFAULT NULL,
  `is_cable` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- إرجاع أو استيراد بيانات الجدول `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `product_code`, `category_id`, `initial_balance`, `min_stock_level`, `total_balance`, `is_cable`, `created_at`) VALUES
(29, 'مواسير الرحاب 20 مم', 'Y520', 1, '0.00', '0.00', NULL, 0, '2026-02-03 10:09:29'),
(30, 'مواسير الرحاب 25 مم', 'Y525', 1, '350.00', '0.00', NULL, 0, '2026-02-03 10:39:30'),
(31, 'مواسير الرحاب 32 مم', 'Y532', 1, '0.00', '0.00', NULL, 0, '2026-02-03 10:40:05'),
(32, 'مخرج نهايه 25 مم الرحاب', '525/1', 1, '0.00', '0.00', NULL, 0, '2026-02-03 10:42:08'),
(33, 'مخرج  ثرو 25 مم الرحاب', '525/2', 1, '0.00', '0.00', NULL, 0, '2026-02-03 10:42:53'),
(34, 'مخرج  زاوية 25 مم الرحاب', '525/12', 1, '0.00', '0.00', NULL, 0, '2026-02-03 10:44:23'),
(35, 'مخرج ثلاثي  25 مم الرحاب', '525/3', 1, '0.00', '0.00', NULL, 0, '2026-02-03 10:45:30'),
(36, 'مخرج رباعي 25 مم الرحاب', '525/4', 1, '0.00', '0.00', NULL, 0, '2026-02-03 10:47:27'),
(37, 'مخرج H 25 مم الرحاب', 'H/525', 1, '0.00', '0.00', NULL, 0, '2026-02-03 10:49:01'),
(38, 'مخرج Y 25 مم الرحاب', 'Y/525', 1, '0.00', '0.00', NULL, 0, '2026-02-03 10:50:04'),
(39, 'مخرج U 25 مم الرحاب', 'U/525', 1, '0.00', '0.00', NULL, 0, '2026-02-03 10:51:53'),
(40, 'جلاندة 25 مم الرحاب', '725/1', 1, '0.00', '0.00', NULL, 0, '2026-02-03 11:00:59'),
(41, 'جلاندة 32 مم الرحاب', '732/1', 1, '0.00', '0.00', NULL, 0, '2026-02-03 11:04:18'),
(42, 'ادابتر 25 مم الرحاب', '325', 1, '0.00', '0.00', NULL, 0, '2026-02-03 11:05:22'),
(43, 'ادابتر 32 مم الرحاب', '332', 1, '0.00', '0.00', NULL, 0, '2026-02-03 11:06:08'),
(44, 'فلكسيبل 25 مم الرحاب', '725', 1, '0.00', '0.00', NULL, 0, '2026-02-03 11:07:30'),
(45, 'فلكسيبل 32 مم الرحاب', '732', 1, '0.00', '0.00', NULL, 0, '2026-02-03 11:08:33'),
(46, 'جلبة 25 مم الرحاب', '125', 1, '0.00', '0.00', NULL, 0, '2026-02-03 11:09:43'),
(47, 'جلبة 32 مم الرحاب', '132', 1, '0.00', '0.00', NULL, 0, '2026-02-03 11:10:04'),
(48, 'خرطوم 25 مم الرحاب', 'Y325', 1, '0.00', '0.00', NULL, 0, '2026-02-03 11:12:12'),
(49, 'قفيز 25 مم الرحاب - بدون قاعدة', '425/1', 1, '0.00', '0.00', NULL, 0, '2026-02-03 11:14:24'),
(50, 'قفيز 32 مم الرحاب - بدون قاعدة', '432/1', 1, '0.00', '0.00', NULL, 0, '2026-02-03 11:14:43'),
(51, 'غطاء مخرج دائري الرحاب', '500', 1, '0.00', '0.00', NULL, 0, '2026-02-03 11:19:17'),
(52, 'بواط 10*10 الرحاب', 'W3/M', 1, '0.00', '0.00', NULL, 0, '2026-02-03 11:23:24'),
(53, 'بواط 38*30 الرحاب', 'W6/M', 1, '0.00', '0.00', NULL, 0, '2026-02-03 11:23:42'),
(54, 'علبة 7*7 الرحاب', 'P10/1', 1, '0.00', '0.00', NULL, 0, '2026-02-03 11:25:58'),
(55, 'علبة 7*10 الرحاب', 'P11/1', 1, '0.00', '0.00', NULL, 0, '2026-02-03 11:26:50');

-- --------------------------------------------------------

--
-- بنية الجدول `product_units`
--

CREATE TABLE `product_units` (
  `unit_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `unit_name` varchar(50) NOT NULL,
  `conversion_factor` decimal(15,3) DEFAULT 1.000,
  `unit_price` decimal(15,2) DEFAULT 0.00,
  `is_base_unit` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- إرجاع أو استيراد بيانات الجدول `product_units`
--

INSERT INTO `product_units` (`unit_id`, `product_id`, `unit_name`, `conversion_factor`, `unit_price`, `is_base_unit`) VALUES
(43, 29, 'ماسورة', '1.000', '0.00', 1),
(44, 29, 'لفه', '34.000', '0.00', 0),
(47, 31, 'ماسورة', '1.000', '0.00', 1),
(48, 31, 'لفه', '15.000', '0.00', 0),
(49, 32, 'قطعه', '1.000', '0.00', 1),
(50, 32, 'كرتونه', '55.000', '0.00', 0),
(51, 33, 'قطعه', '1.000', '0.00', 1),
(52, 33, 'كرتونه', '45.000', '0.00', 0),
(53, 34, 'قطعه', '1.000', '0.00', 1),
(54, 34, 'كرتونه', '45.000', '0.00', 0),
(55, 35, 'قطعه', '1.000', '0.00', 1),
(56, 35, 'كرتونه', '25.000', '0.00', 0),
(57, 36, 'قطعه', '1.000', '0.00', 1),
(58, 36, 'كرتونه', '25.000', '0.00', 0),
(59, 37, 'قطعه', '1.000', '0.00', 1),
(60, 37, 'كرتونه', '35.000', '0.00', 0),
(63, 38, 'قطعه', '1.000', '0.00', 1),
(64, 38, 'كرتونه', '35.000', '0.00', 0),
(65, 39, 'قطعه', '1.000', '0.00', 1),
(66, 39, 'كرتونه', '45.000', '0.00', 0),
(67, 30, 'ماسورة', '1.000', '0.00', 1),
(68, 30, 'لفه', '20.000', '0.00', 0),
(69, 40, 'قطعه', '1.000', '0.00', 1),
(70, 40, 'كيس', '100.000', '0.00', 0),
(71, 41, 'قطعه', '1.000', '0.00', 1),
(72, 42, 'قطعه', '1.000', '0.00', 1),
(73, 43, 'قطعه', '1.000', '0.00', 1),
(76, 44, 'متر', '1.000', '0.00', 1),
(77, 44, 'لفه', '30.000', '0.00', 0),
(78, 45, 'متر', '1.000', '0.00', 1),
(79, 45, 'لفه', '32.000', '0.00', 0),
(80, 46, 'قطعه', '1.000', '0.00', 1),
(81, 47, 'قطعه', '1.000', '0.00', 1),
(82, 48, 'متر', '1.000', '0.00', 1),
(83, 48, 'لفه', '50.000', '0.00', 0),
(84, 49, 'قطعه', '1.000', '0.00', 1),
(85, 50, 'قطعه', '1.000', '0.00', 1),
(86, 51, 'قطعه', '1.000', '0.00', 1),
(90, 54, 'قطعه', '1.000', '0.00', 1),
(91, 55, 'قطعه', '1.000', '0.00', 1),
(92, 53, 'قطعه', '1.000', '0.00', 1),
(93, 52, 'قطعه', '1.000', '0.00', 1);

-- --------------------------------------------------------

--
-- بنية الجدول `projects`
--

CREATE TABLE `projects` (
  `project_id` int(11) NOT NULL,
  `project_name` varchar(255) NOT NULL,
  `client_name` varchar(255) DEFAULT NULL,
  `project_location` varchar(255) DEFAULT NULL,
  `budget_limit` decimal(15,2) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `project_status` enum('active','completed','on_hold') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `remember_tokens`
--

CREATE TABLE `remember_tokens` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- إرجاع أو استيراد بيانات الجدول `remember_tokens`
--

INSERT INTO `remember_tokens` (`id`, `user_id`, `token`, `expires_at`, `ip_address`, `created_at`) VALUES
(3, 1, 'a029bea189a3137d565d2271058ceb017b0b75f649cbdb829228ddd824378f58', '2026-03-02 17:46:30', '154.188.125.137', '2026-01-31 15:46:30'),
(4, 1, '83f62171ba73433f710ba89b7a7a7d4f8bb6eee2d443a42523a46f51fc55b9b6', '2026-03-03 10:36:03', '196.152.208.4', '2026-02-01 08:36:03');

-- --------------------------------------------------------

--
-- بنية الجدول `tools_assets`
--

CREATE TABLE `tools_assets` (
  `tool_id` int(11) NOT NULL,
  `tool_name` varchar(255) NOT NULL,
  `serial_number` varchar(100) DEFAULT NULL,
  `current_status` enum('in_store','with_contractor','maintenance','lost') DEFAULT 'in_store',
  `assigned_to_contact_id` int(11) DEFAULT NULL,
  `last_check_out` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `transactions`
--

CREATE TABLE `transactions` (
  `trans_id` int(11) NOT NULL,
  `trans_date` datetime DEFAULT current_timestamp(),
  `trans_type` enum('in','out','issue','return','transfer') NOT NULL COMMENT 'in=وارد, out=صادر, issue=صرف, return=مرتجع, transfer=تحويل',
  `contact_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `from_warehouse_id` int(11) DEFAULT NULL,
  `to_warehouse_id` int(11) DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- إرجاع أو استيراد بيانات الجدول `transactions`
--

INSERT INTO `transactions` (`trans_id`, `trans_date`, `trans_type`, `contact_id`, `project_id`, `from_warehouse_id`, `to_warehouse_id`, `total_amount`, `notes`, `user_id`) VALUES
(1, '2026-01-29 15:05:00', 'in', 1, NULL, NULL, NULL, '0.00', '', 1);

-- --------------------------------------------------------

--
-- بنية الجدول `transaction_details`
--

CREATE TABLE `transaction_details` (
  `detail_id` int(11) NOT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `start_read` decimal(10,2) DEFAULT 0.00,
  `end_read` decimal(10,2) DEFAULT 0.00,
  `quantity` decimal(15,3) NOT NULL,
  `unit_price` decimal(15,2) DEFAULT NULL,
  `total_item_price` decimal(15,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `treasury`
--

CREATE TABLE `treasury` (
  `cash_id` int(11) NOT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `contact_id` int(11) DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL,
  `operation_type` enum('in','out') NOT NULL COMMENT 'in=دخل, out=خرج',
  `payment_method` enum('cash','transfer','check') DEFAULT 'cash',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) DEFAULT NULL,
  `status` enum('active','inactive','suspended') DEFAULT 'active',
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- إرجاع أو استيراد بيانات الجدول `users`
--

INSERT INTO `users` (`id`, `username`, `full_name`, `email`, `phone`, `password`, `role`, `status`, `last_login`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'محمد النعماني', 'mohammedelnomany2100@gmail.com', '01020063977', '$2y$10$riRE5MdNDZm9sveLE3OH8uDLMNNhbHZSYxaGZrZIG34IE3Z9Jwnrq', 'مدير', 'active', '2026-02-02 11:26:58', '2026-01-30 11:33:17', '2026-02-02 09:26:58'),
(3, 'salama', 'محمد سلامه', NULL, '01004560215', '$2y$10$8PJ7I6Kpa.hupZrruN2bQudRY.c2kO.f8ZbnSfsU2BFvhmBn0OP6q', 'مدير', 'active', '2026-01-31 16:38:44', '2026-01-31 13:55:21', '2026-01-31 15:01:24'),
(4, 'memo', 'mohammed', NULL, NULL, '$2y$10$E9et3A1b2/jO7z3DFzzEkeayk/ffFaT5mEeyvN0KDdTVTKVRWTN.G', 'مدير', 'active', '2026-01-31 17:01:09', '2026-01-31 15:00:09', '2026-01-31 15:01:09');

-- --------------------------------------------------------

--
-- بنية الجدول `user_activity`
--

CREATE TABLE `user_activity` (
  `activity_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` varchar(255) NOT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- إرجاع أو استيراد بيانات الجدول `user_activity`
--

INSERT INTO `user_activity` (`activity_id`, `user_id`, `action`, `details`, `ip_address`, `created_at`) VALUES
(1, 1, 'الدخول إلى لوحة التحكم', '', '::1', '2026-01-27 12:46:29'),
(2, 1, 'تسجيل الخروج', 'تم تسجيل الخروج من النظام', '::1', '2026-01-27 12:46:56'),
(3, 1, 'الدخول إلى لوحة التحكم', '', '::1', '2026-01-27 12:47:02'),
(4, 1, 'تسجيل الخروج', 'تم تسجيل الخروج من النظام', '::1', '2026-01-27 12:47:09'),
(5, 1, 'الدخول إلى لوحة التحكم', '', '::1', '2026-01-27 12:47:29'),
(6, 1, 'الدخول إلى لوحة التحكم', '', '::1', '2026-01-28 07:31:35'),
(7, 1, 'تسجيل الخروج', 'تم تسجيل الخروج من النظام', '::1', '2026-01-28 10:17:19'),
(8, 1, 'تسجيل الخروج', 'تم تسجيل الخروج من النظام', '::1', '2026-01-28 12:23:12'),
(9, 1, 'تسجيل الخروج', 'تم تسجيل الخروج من النظام', '::1', '2026-01-29 08:00:41'),
(10, 1, 'تسجيل الخروج', 'تم تسجيل الخروج من النظام', '::1', '2026-01-30 12:01:24'),
(11, 1, 'تسجيل الخروج', 'تم تسجيل الخروج من النظام', '::1', '2026-01-30 12:03:08'),
(12, 1, 'تسجيل الخروج', 'تم تسجيل الخروج من النظام', '::1', '2026-01-30 12:08:04'),
(13, 1, 'تسجيل الخروج', 'تم تسجيل الخروج من النظام', '::1', '2026-01-30 12:12:00'),
(14, 2, 'تسجيل الخروج', 'تم تسجيل الخروج من النظام', '::1', '2026-01-30 12:13:44'),
(15, 1, 'تسجيل الخروج', 'تم تسجيل الخروج من النظام', '::1', '2026-01-30 12:44:24'),
(16, 1, 'الدخول إلى لوحة التحكم', NULL, '::1', '2026-01-30 12:44:48'),
(17, 1, 'الدخول إلى لوحة التحكم', NULL, '::1', '2026-01-30 13:04:59'),
(18, 1, 'الدخول إلى لوحة التحكم', NULL, '::1', '2026-01-30 13:39:10'),
(19, 1, 'الدخول إلى لوحة التحكم', NULL, '::1', '2026-01-31 07:26:45'),
(20, 1, 'الدخول إلى لوحة التحكم', NULL, '::1', '2026-01-31 08:44:50'),
(21, 1, 'الدخول إلى لوحة التحكم', NULL, '::1', '2026-01-31 10:54:49'),
(22, 1, 'الدخول إلى لوحة التحكم', NULL, '::1', '2026-01-31 11:19:49'),
(23, 1, 'الدخول إلى لوحة التحكم', NULL, '::1', '2026-01-31 11:57:52'),
(24, 1, 'الدخول إلى لوحة التحكم', NULL, '196.152.145.38', '2026-01-31 13:54:14'),
(25, 1, 'الدخول إلى لوحة التحكم', NULL, '196.152.145.38', '2026-01-31 13:56:49'),
(26, 1, 'تسجيل الخروج', NULL, '196.152.145.38', '2026-01-31 13:59:03'),
(27, 3, 'الدخول إلى لوحة التحكم', NULL, '196.152.145.38', '2026-01-31 14:00:20'),
(28, 1, 'الدخول إلى لوحة التحكم', NULL, '196.152.145.38', '2026-01-31 14:03:19'),
(29, 1, 'الدخول إلى لوحة التحكم', NULL, '196.152.145.38', '2026-01-31 14:07:45'),
(30, 1, 'تسجيل الخروج', NULL, '196.152.145.38', '2026-01-31 14:10:27'),
(31, 1, 'الدخول إلى لوحة التحكم', NULL, '196.152.145.38', '2026-01-31 14:14:51'),
(32, 1, 'تسجيل الخروج', NULL, '196.152.145.38', '2026-01-31 14:15:01'),
(33, 3, 'الدخول إلى لوحة التحكم', NULL, '105.204.109.193', '2026-01-31 14:35:38'),
(34, 1, 'الدخول إلى لوحة التحكم', NULL, '196.152.145.38', '2026-01-31 14:36:54'),
(35, 3, 'تسجيل الخروج', NULL, '105.204.109.193', '2026-01-31 14:37:20'),
(36, 3, 'الدخول إلى لوحة التحكم', NULL, '105.204.109.193', '2026-01-31 14:37:23'),
(37, 1, 'تسجيل الخروج', NULL, '196.152.145.38', '2026-01-31 14:38:35'),
(38, 3, 'الدخول إلى لوحة التحكم', NULL, '196.152.145.38', '2026-01-31 14:38:44'),
(39, 3, 'تسجيل الخروج', NULL, '196.152.145.38', '2026-01-31 14:39:06'),
(40, 1, 'الدخول إلى لوحة التحكم', NULL, '196.152.145.38', '2026-01-31 14:47:20'),
(41, 4, 'الدخول إلى لوحة التحكم', NULL, '196.152.145.38', '2026-01-31 15:01:09'),
(42, 1, 'الدخول إلى لوحة التحكم', NULL, '196.152.145.38', '2026-01-31 15:01:50'),
(43, 1, 'الدخول إلى لوحة التحكم', NULL, '196.152.145.38', '2026-01-31 15:02:06'),
(44, 1, 'الدخول إلى لوحة التحكم', NULL, '196.152.145.38', '2026-01-31 15:35:03'),
(45, 1, 'الدخول إلى لوحة التحكم', NULL, '196.152.145.38', '2026-01-31 15:43:54'),
(46, 1, 'الدخول إلى لوحة التحكم', NULL, '154.188.125.137', '2026-01-31 15:46:30'),
(47, 1, 'الدخول إلى لوحة التحكم', NULL, '156.163.52.152', '2026-01-31 15:53:57'),
(48, 1, 'الدخول إلى لوحة التحكم', NULL, '196.152.208.4', '2026-02-01 08:36:03'),
(49, 1, 'الدخول إلى لوحة التحكم', NULL, '196.132.44.86', '2026-02-02 09:26:58');

-- --------------------------------------------------------

--
-- بنية الجدول `warehouses`
--

CREATE TABLE `warehouses` (
  `warehouse_id` int(11) NOT NULL,
  `warehouse_name` varchar(150) NOT NULL,
  `warehouse_location` varchar(255) DEFAULT NULL,
  `warehouse_phone` varchar(20) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- إرجاع أو استيراد بيانات الجدول `warehouses`
--

INSERT INTO `warehouses` (`warehouse_id`, `warehouse_name`, `warehouse_location`, `warehouse_phone`, `is_active`, `created_at`) VALUES
(1, 'المستودع الرئيسي', NULL, NULL, 1, '2026-01-27 12:14:09'),
(2, 'فرع المعادي', NULL, NULL, 1, '2026-01-27 12:14:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `company_profile`
--
ALTER TABLE `company_profile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD UNIQUE KEY `product_code` (`product_code`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `product_units`
--
ALTER TABLE `product_units`
  ADD PRIMARY KEY (`unit_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`project_id`);

--
-- Indexes for table `remember_tokens`
--
ALTER TABLE `remember_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_token` (`user_id`,`token`),
  ADD KEY `idx_token` (`token`),
  ADD KEY `idx_expires` (`expires_at`);

--
-- Indexes for table `tools_assets`
--
ALTER TABLE `tools_assets`
  ADD PRIMARY KEY (`tool_id`),
  ADD UNIQUE KEY `serial_number` (`serial_number`),
  ADD KEY `assigned_to_contact_id` (`assigned_to_contact_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`trans_id`),
  ADD KEY `contact_id` (`contact_id`),
  ADD KEY `project_id` (`project_id`),
  ADD KEY `from_warehouse_id` (`from_warehouse_id`),
  ADD KEY `to_warehouse_id` (`to_warehouse_id`);

--
-- Indexes for table `transaction_details`
--
ALTER TABLE `transaction_details`
  ADD PRIMARY KEY (`detail_id`),
  ADD KEY `trans_id` (`trans_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `unit_id` (`unit_id`);

--
-- Indexes for table `treasury`
--
ALTER TABLE `treasury`
  ADD PRIMARY KEY (`cash_id`),
  ADD KEY `trans_id` (`trans_id`),
  ADD KEY `contact_id` (`contact_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_activity`
--
ALTER TABLE `user_activity`
  ADD PRIMARY KEY (`activity_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `warehouses`
--
ALTER TABLE `warehouses`
  ADD PRIMARY KEY (`warehouse_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `product_units`
--
ALTER TABLE `product_units`
  MODIFY `unit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `project_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `remember_tokens`
--
ALTER TABLE `remember_tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tools_assets`
--
ALTER TABLE `tools_assets`
  MODIFY `tool_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `trans_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `transaction_details`
--
ALTER TABLE `transaction_details`
  MODIFY `detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `treasury`
--
ALTER TABLE `treasury`
  MODIFY `cash_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user_activity`
--
ALTER TABLE `user_activity`
  MODIFY `activity_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `warehouses`
--
ALTER TABLE `warehouses`
  MODIFY `warehouse_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- قيود الجداول المحفوظة
--

--
-- القيود للجدول `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- القيود للجدول `product_units`
--
ALTER TABLE `product_units`
  ADD CONSTRAINT `product_units_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- القيود للجدول `tools_assets`
--
ALTER TABLE `tools_assets`
  ADD CONSTRAINT `tools_assets_ibfk_1` FOREIGN KEY (`assigned_to_contact_id`) REFERENCES `contacts` (`contact_id`);

--
-- القيود للجدول `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`contact_id`),
  ADD CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`project_id`) REFERENCES `projects` (`project_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `transactions_ibfk_3` FOREIGN KEY (`from_warehouse_id`) REFERENCES `warehouses` (`warehouse_id`),
  ADD CONSTRAINT `transactions_ibfk_4` FOREIGN KEY (`to_warehouse_id`) REFERENCES `warehouses` (`warehouse_id`);

--
-- القيود للجدول `transaction_details`
--
ALTER TABLE `transaction_details`
  ADD CONSTRAINT `transaction_details_ibfk_1` FOREIGN KEY (`trans_id`) REFERENCES `transactions` (`trans_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transaction_details_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  ADD CONSTRAINT `transaction_details_ibfk_3` FOREIGN KEY (`unit_id`) REFERENCES `product_units` (`unit_id`);

--
-- القيود للجدول `treasury`
--
ALTER TABLE `treasury`
  ADD CONSTRAINT `treasury_ibfk_1` FOREIGN KEY (`trans_id`) REFERENCES `transactions` (`trans_id`),
  ADD CONSTRAINT `treasury_ibfk_2` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`contact_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
