<?php
// includes/sidebar.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// الحصول على اسم الصفحة الحالية
$current_page = basename($_SERVER['PHP_SELF']);

// التحقق من حالة السايدبار
$sidebar_collapsed = isset($_COOKIE['sidebar_collapsed']) && $_COOKIE['sidebar_collapsed'] === 'true';

// تعريف المتغيرات إذا لم تكن موجودة (للأمان)
if (!isset($_SESSION['full_name'])) {
    $_SESSION['full_name'] = 'مستخدم النظام';
    $_SESSION['role'] = 'موظف'; // القيمة الافتراضية
}
?>
<!-- السايدبار -->
<div class="sidebar-wrapper <?php echo $sidebar_collapsed ? 'collapsed' : ''; ?>">
    <div class="sidebar">
        <!-- شعار النظام -->
        <div class="sidebar-logo">
            <a href="dashboard.php" class="d-flex align-items-center text-decoration-none text-white">
                <i class="bi bi-box-seam me-2 fs-3"></i>
                <span class="logo-text fs-4 fw-bold">StoreMate</span>
            </a>
            <button class="sidebar-toggle-btn d-none d-lg-block" onclick="toggleSidebarPermanent()" title="طي/فتح الشريط الجانبي">
                <i class="bi bi-chevron-right"></i>
            </button>
        </div>
        
        <!-- قسم المستخدم -->
        <div class="sidebar-user">
            <div class="user-avatar">
                <?php 
                if (isset($_SESSION['full_name'])) {
                    $names = explode(' ', $_SESSION['full_name']);
                    $initials = '';
                    foreach($names as $name) {
                        $initials .= mb_substr($name, 0, 1, 'UTF-8');
                    }
                    echo mb_substr($initials, 0, 2, 'UTF-8');
                } else {
                    echo 'م';
                }
                ?>
            </div>
            <div class="user-info">
                <h6 class="mb-0"><?php echo $_SESSION['full_name'] ?? 'مستخدم'; ?></h6>
                <small class="text-muted">
                    <?php 
                    $role = $_SESSION['role'] ?? 'زائر';
                    switch($role) {
                        case 'مدير': echo '<span class="text-warning">مدير النظام</span>'; break;
                        case 'مدير مخازن': echo '<span class="text-info">مدير مخازن</span>'; break;
                        case 'موظف': echo '<span class="text-success">موظف</span>'; break;
                        default: echo '<span class="text-muted">' . $role . '</span>';
                    }
                    ?>
                </small>
            </div>
        </div>
        
        <!-- القائمة الرئيسية -->
        <div class="sidebar-menu">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link <?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
                        <i class="bi bi-speedometer2 me-2"></i>
                        <span class="menu-text">لوحة التحكم</span>
                    </a>
                </li>
                
                <li class="nav-item">
                    <a href="products.php" class="nav-link <?php echo $current_page == 'products.php' ? 'active' : ''; ?>">
                        <i class="bi bi-box-seam me-2"></i>
                        <span class="menu-text">الأصناف</span>
                    </a>
                </li>
                
                <li class="nav-item">
                    <a href="categories.php" class="nav-link <?php echo $current_page == 'categories.php' ? 'active' : ''; ?>">
                        <i class="bi bi-tags me-2"></i>
                        <span class="menu-text">الفئات</span>
                    </a>
                </li>
                
                <li class="nav-item">
                    <a href="transactions.php" class="nav-link <?php echo $current_page == 'transactions.php' ? 'active' : ''; ?>">
                        <i class="bi bi-arrow-left-right me-2"></i>
                        <span class="menu-text">الحركات</span>
                    </a>
                </li>
                
                <li class="nav-item">
                    <a href="reports.php" class="nav-link <?php echo $current_page == 'reports.php' ? 'active' : ''; ?>">
                        <i class="bi bi-bar-chart me-2"></i>
                        <span class="menu-text">التقارير</span>
                    </a>
                </li>
                
                <!-- رابط المستخدمين - فقط للمديرين -->
                <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'مدير'): ?>
                <li class="nav-item">
                    <a href="users.php" class="nav-link <?php echo $current_page == 'users.php' ? 'active' : ''; ?>">
                        <i class="bi bi-people me-2"></i>
                        <span class="menu-text">المستخدمين</span>
                        <span class="badge bg-warning ms-1" title="خاص بالإدارة">
                            <i class="bi bi-shield-lock"></i>
                        </span>
                    </a>
                </li>
                <?php endif; ?>
                
                <li class="nav-item">
                    <a href="warehouses.php" class="nav-link <?php echo $current_page == 'warehouses.php' ? 'active' : ''; ?>">
                        <i class="bi bi-shop me-2"></i>
                        <span class="menu-text">المخازن</span>
                    </a>
                </li>
                
                <li class="nav-item">
                    <a href="settings.php" class="nav-link <?php echo $current_page == 'settings.php' ? 'active' : ''; ?>">
                        <i class="bi bi-gear me-2"></i>
                        <span class="menu-text">الإعدادات</span>
                        <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'مدير'): ?>
                        <span class="badge bg-info ms-1" title="إعدادات متقدمة">
                            <i class="bi bi-star"></i>
                        </span>
                        <?php endif; ?>
                    </a>
                </li>
                
                <!-- رابط إضافي للصلاحيات - للمديرين ومديري المخازن -->
                <?php if (isset($_SESSION['role']) && in_array($_SESSION['role'], ['مدير', 'مدير مخازن'])): ?>
                <li class="nav-item">
                    <a href="inventory.php" class="nav-link <?php echo $current_page == 'inventory.php' ? 'active' : ''; ?>">
                        <i class="bi bi-clipboard-data me-2"></i>
                        <span class="menu-text">الجرد</span>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
        
        <!-- خروج -->
        <div class="sidebar-footer">
            <a href="logout.php" class="nav-link text-danger">
                <i class="bi bi-box-arrow-right me-2"></i>
                <span class="menu-text">تسجيل الخروج</span>
            </a>
        </div>
    </div>
    
    <!-- زر إغلاق السايدبار للشاشات الصغيرة -->
    <button class="sidebar-toggler d-lg-none" onclick="toggleSidebar()" type="button">
        <i class="bi bi-x-lg"></i>
    </button>
</div>

<!-- إضافة بعض الأنماط الإضافية -->
<style>
.user-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 1.1rem;
}

.sidebar-user {
    padding: 1.5rem 1rem;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    margin-bottom: 1rem;
}

.user-info h6 {
    color: white;
    font-weight: 600;
}

.nav-link.active {
    background-color: rgba(255,255,255,0.1);
    border-right: 3px solid #4dabf7;
}

.nav-link .badge {
    font-size: 0.6rem;
    padding: 0.2rem 0.4rem;
}
</style>

<script>
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar-wrapper');
    sidebar.classList.toggle('collapsed');
    
    // حفظ التفضيل في الكوكيز
    const isCollapsed = sidebar.classList.contains('collapsed');
    document.cookie = `sidebar_collapsed=${isCollapsed}; path=/; max-age=2592000`; // 30 يوم
}

function toggleSidebarPermanent() {
    const sidebar = document.querySelector('.sidebar-wrapper');
    sidebar.classList.toggle('collapsed');
    
    // حفظ التفضيل في الكوكيز
    const isCollapsed = sidebar.classList.contains('collapsed');
    document.cookie = `sidebar_collapsed=${isCollapsed}; path=/; max-age=2592000`; // 30 يوم
    
    // إعادة تحميل الصفحة لتطبيق التغييرات بشكل كامل
    setTimeout(() => {
        window.location.reload();
    }, 300);
}

// إغلاق السايدبار عند النقر على رابط في الشاشات الصغيرة
document.addEventListener('DOMContentLoaded', function() {
    if (window.innerWidth < 992) {
        const navLinks = document.querySelectorAll('.sidebar-menu .nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                const sidebar = document.querySelector('.sidebar-wrapper');
                sidebar.classList.add('collapsed');
            });
        });
    }
});
</script>