<?php
// includes/auth_check.php - النسخة المحسنة

// التحقق من وجود جلسة المستخدم
if (!isset($_SESSION['user_id'])) {
    // محاولة الحصول على user_id من قاعدة البيانات إذا كان موجوداً
    if (isset($_SESSION['full_name'])) {
        try {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE full_name = ? LIMIT 1");
            $stmt->execute([$_SESSION['full_name']]);
            $user = $stmt->fetch();
            
            if ($user) {
                $_SESSION['user_id'] = $user['id'];
            } else {
                $_SESSION['user_id'] = 1; // القيمة الافتراضية
            }
        } catch (Exception $e) {
            $_SESSION['user_id'] = 1;
        }
    } else {
        $_SESSION['user_id'] = 1;
    }
}

// يمكن إضافة المزيد من التحقق من الصلاحيات هنا
?>