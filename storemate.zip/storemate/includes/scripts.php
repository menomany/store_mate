<?php
// includes/scripts.php
?>
<script>
    // وظيفة تبديل السايدبار للشاشات الصغيرة
    function toggleSidebar() {
        const sidebar = document.querySelector('.sidebar-wrapper');
        sidebar.classList.toggle('show');
    }
    
    // وظيفة تبديل السايدبار بشكل دائم (لجميع الشاشات)
    function toggleSidebarPermanent() {
        const sidebar = document.querySelector('.sidebar-wrapper');
        const isCollapsed = sidebar.classList.toggle('collapsed');
        
        // حفظ الحالة في الكوكيز لمدة 30 يوم
        const date = new Date();
        date.setTime(date.getTime() + (30 * 24 * 60 * 60 * 1000));
        const expires = "expires=" + date.toUTCString();
        document.cookie = "sidebar_collapsed=" + isCollapsed + ";" + expires + ";path=/";
        
        // إعادة حساب عرض العناصر
        setTimeout(() => {
            window.dispatchEvent(new Event('resize'));
        }, 300);
    }
    
    // البحث السريع
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('globalSearch');
        if (searchInput) {
            searchInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    const query = this.value.trim();
                    if (query.length > 0) {
                        // البحث في صفحة المنتجات
                        if (window.location.pathname.includes('products.php')) {
                            window.location.href = 'products.php?search=' + encodeURIComponent(query);
                        } else {
                            window.location.href = 'products.php?search=' + encodeURIComponent(query);
                        }
                    }
                }
            });
        }
    });
    
    // إغلاق السايدبار عند النقر خارجها في الشاشات الصغيرة
    document.addEventListener('click', function(e) {
        if (window.innerWidth <= 992) {
            const sidebar = document.querySelector('.sidebar-wrapper');
            const toggler = document.querySelector('[onclick="toggleSidebar()"]');
            
            if (sidebar && !sidebar.contains(e.target) && toggler && !toggler.contains(e.target)) {
                sidebar.classList.remove('show');
            }
        }
    });
    
    // تهيئة أدوات التلميح
    document.addEventListener('DOMContentLoaded', function() {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    });
    
    // تحسين التجاوب مع تغيير حجم النافذة
    window.addEventListener('resize', function() {
        const sidebar = document.querySelector('.sidebar-wrapper');
        if (window.innerWidth <= 992 && sidebar) {
            sidebar.classList.remove('collapsed');
        }
    });
</script>