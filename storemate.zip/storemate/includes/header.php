<?php
// includes/header.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// تعريف المتغيرات الأساسية
$low_stock_count = 0; // قمنا بتعريفه أولاً لتجنب الأخطاء

// جلب إحصائيات المخزون المنخفض إذا كانت هناك اتصال بقاعدة البيانات
if (isset($pdo) && is_object($pdo)) {
    try {
        // استعلام مبسط للحصول على عدد المنتجات المنخفضة المخزون
        $stmt = $pdo->query("
            SELECT COUNT(*) as count 
            FROM products p 
            WHERE (
                COALESCE((SELECT SUM(CASE WHEN t.trans_type IN ('in', 'return') THEN td.quantity ELSE 0 END) 
                FROM transaction_details td 
                JOIN transactions t ON td.trans_id = t.trans_id 
                WHERE td.product_id = p.product_id), 0)
                -
                COALESCE((SELECT SUM(CASE WHEN t.trans_type IN ('out', 'issue') THEN td.quantity ELSE 0 END) 
                FROM transaction_details td 
                JOIN transactions t ON td.trans_id = t.trans_id 
                WHERE td.product_id = p.product_id), 0)
            ) <= p.min_stock_level
        ");
        $result = $stmt->fetch();
        $low_stock_count = $result['count'] ?? 0;
    } catch (Exception $e) {
        // تجاهل الخطأ
        $low_stock_count = 0;
    }
}
?>
<!-- شريط التنقل العلوي -->
<nav class="navbar navbar-expand-lg navbar-dark navbar-custom mb-4">
    <div class="container-fluid">
        <button class="btn btn-outline-light me-3 d-lg-none" onclick="toggleSidebar()" type="button">
            <i class="bi bi-list"></i>
        </button>
        
        <!-- زر التحكم في السايدبار للشاشات الكبيرة -->
        <button class="btn btn-outline-light me-3 d-none d-lg-block" onclick="toggleSidebarPermanent()" title="طي/فتح الشريط الجانبي" type="button">
            <i class="bi bi-layout-sidebar"></i>
        </button>
        
        <!-- عنوان الصفحة -->
        <div class="navbar-brand d-none d-md-block ms-auto me-auto">
            <h5 class="mb-0"><?php echo $page_title ?? 'لوحة التحكم'; ?></h5>
        </div>
        
        <div class="d-flex align-items-center">
            <!-- شريط البحث -->
            <div class="search-box me-3 d-none d-md-block">
                <input type="text" class="form-control" placeholder="بحث سريع..." style="width: 250px;" id="globalSearch">
                <i class="bi bi-search"></i>
            </div>
            
            <!-- الإشعارات -->
            <div class="dropdown me-3">
                <button class="btn btn-outline-light position-relative" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="bi bi-bell"></i>
                    <?php if($low_stock_count > 0): ?>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        <?php echo $low_stock_count; ?>
                        <span class="visually-hidden">إشعارات غير مقروءة</span>
                    </span>
                    <?php endif; ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end" style="min-width: 300px;">
                    <li><h6 class="dropdown-header">الإشعارات</h6></li>
                    <li><hr class="dropdown-divider"></li>
                    <?php if($low_stock_count > 0): ?>
                    <li>
                        <a class="dropdown-item" href="products.php?low_stock=1">
                            <div class="d-flex align-items-center">
                                <div class="bg-warning text-white rounded-circle p-2 me-2">
                                    <i class="bi bi-exclamation-triangle"></i>
                                </div>
                                <div>
                                    <div>منتجات منخفضة المخزون</div>
                                    <small class="text-muted"><?php echo $low_stock_count; ?> منتج يحتاج للتزويد</small>
                                </div>
                            </div>
                        </a>
                    </li>
                    <li><hr class="dropdown-divider"></li>
                    <?php endif; ?>
                    <li><a class="dropdown-item text-center text-muted" href="#">
                        <small>عرض جميع الإشعارات</small>
                    </a></li>
                </ul>
            </div>
            
            <!-- الملف الشخصي -->
            <div class="dropdown">
                <button class="btn btn-outline-light dropdown-toggle d-flex align-items-center" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <div class="user-avatar me-2">
                        <?php echo isset($_SESSION['full_name']) ? mb_substr($_SESSION['full_name'], 0, 1, 'UTF-8') : 'م'; ?>
                    </div>
                    <div class="text-start d-none d-md-block">
                        <small class="d-block"><?php echo $_SESSION['full_name'] ?? 'مستخدم'; ?></small>
                        <small class="d-block opacity-75"><?php echo $_SESSION['role'] ?? 'زائر'; ?></small>
                    </div>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="profile.php">
                        <i class="bi bi-person me-2"></i> الملف الشخصي
                    </a></li>
                    <li><a class="dropdown-item" href="settings.php">
                        <i class="bi bi-gear me-2"></i> الإعدادات
                    </a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger" href="logout.php">
                        <i class="bi bi-box-arrow-right me-2"></i> تسجيل الخروج
                    </a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>