<?php
// includes/styles.php
?>
<style>
    :root {
        --primary-color: #2c3e50;
        --secondary-color: #3498db;
        --success-color: #27ae60;
        --danger-color: #e74c3c;
        --warning-color: #f39c12;
        --info-color: #1abc9c;
        --light-color: #ecf0f1;
        --dark-color: #2c3e50;
    }
    
    * {
        font-family: 'Cairo', sans-serif;
    }
    
    body {
        background-color: #f8f9fa;
        min-height: 100vh;
        display: flex;
        flex-direction: column;
    }
    
    /* تصميم السايدبار القابل للطي */
    .sidebar-wrapper {
        position: fixed;
        top: 0;
        right: 0;
        height: 100vh;
        width: 250px;
        z-index: 1050;
        transition: all 0.3s ease;
    }

    .sidebar-wrapper.collapsed {
    width: 0;
    transform: translateX(100%);
    }

    .sidebar {
        background: linear-gradient(180deg, var(--primary-color) 0%, #1a2530 100%);
        color: white;
        height: 100%;
        display: flex;
        flex-direction: column;
        box-shadow: 5px 0 25px rgba(0,0,0,0.1);
        overflow-y: auto;
        padding-bottom: 20px;
    }

    .sidebar-logo {
        padding: 20px 15px;
        text-align: center;
        border-bottom: 1px solid rgba(255,255,255,0.1);
        margin-bottom: 15px;
        position: relative;
    }

    .sidebar-toggle-btn {
        position: absolute;
        left: -12px;
        top: 50%;
        transform: translateY(-50%);
        background: var(--secondary-color);
        color: white;
        border: none;
        width: 24px;
        height: 24px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s ease;
        z-index: 10;
    }

    .sidebar-toggle-btn:hover {
        background: var(--primary-color);
        transform: translateY(-50%) scale(1.1);
    }

    .logo-text {
        transition: opacity 0.3s ease;
    }

    .sidebar-wrapper.collapsed .logo-text {
        opacity: 0;
        display: none;
    }

    .sidebar-user {
        padding: 15px;
        display: flex;
        align-items: center;
        gap: 10px;
        border-bottom: 1px solid rgba(255,255,255,0.1);
        margin-bottom: 20px;
    }

    .sidebar-user .user-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--secondary-color) 0%, var(--info-color) 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        font-size: 18px;
    }

    .sidebar-user .user-info h6 {
        color: white;
        margin: 0;
        font-size: 14px;
    }

    .sidebar-user .user-info small {
        font-size: 12px;
        color: rgba(255,255,255,0.7);
    }

    .sidebar-menu {
        flex: 1;
        padding: 0 10px;
    }

    .sidebar-menu .nav-link {
        color: rgba(255,255,255,0.8);
        padding: 12px 15px;
        margin-bottom: 5px;
        border-radius: 8px;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
    }

    .sidebar-menu .nav-link:hover {
        background: rgba(255,255,255,0.1);
        color: white;
        transform: translateX(-5px);
    }

    .sidebar-menu .nav-link.active {
        background: linear-gradient(90deg, var(--secondary-color) 0%, #2980b9 100%);
        color: white;
        box-shadow: 0 4px 15px rgba(52, 152, 219, 0.3);
    }

    .sidebar-menu .nav-link i {
        width: 24px;
        font-size: 18px;
    }

    .menu-text {
        margin-right: 10px;
    }

    .sidebar-footer {
        padding: 15px;
        border-top: 1px solid rgba(255,255,255,0.1);
    }

    .sidebar-footer .nav-link {
        color: rgba(255,255,255,0.8);
        padding: 10px 15px;
        border-radius: 8px;
        transition: all 0.3s ease;
    }

    .sidebar-footer .nav-link:hover {
        background: rgba(220, 53, 69, 0.2);
        color: #ff6b6b;
    }

    .sidebar-toggler {
        display: none;
        position: absolute;
        top: 10px;
        left: -40px;
        background: var(--primary-color);
        color: white;
        border: none;
        width: 40px;
        height: 40px;
        border-radius: 8px 0 0 8px;
        align-items: center;
        justify-content: center;
        font-size: 18px;
    }

    /* المحتوى الرئيسي مع السايدبار */
    .main-content {
        margin-right: 250px;
        padding: 0 20px 20px 20px; /* الصفر هنا بيلغي الفراغ اللي فوق الهيدر */
        min-height: 100vh;
        transition: all 0.3s ease;
        flex: 1;
    }

    .sidebar-wrapper.collapsed ~ .main-content {
        margin-right: 0 !important;
    }

    /* شريط التنقل العلوي - تم حذف margin-right الثابت */
    .navbar-custom {
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
        border-radius: 0 0 10px 10px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        padding: 10px 0;
        margin-top: 0 !important;
        margin-right: 0 !important;
        width: 100%;
        position: sticky;
        top: 0;
        z-index: 1000;
        margin-right: 0 !important; /* الهيدر يتبع إزاحة الأب فقط */
        width: 100%;
        transition: all 0.3s ease;
    }
    
    .user-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--secondary-color) 0%, var(--info-color) 100%);
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
    }
    
    /* بطاقة الترحيب */
    .welcome-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 15px;
        overflow: hidden;
        position: relative;
        margin-bottom: 30px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    
    /* بطاقات الإحصائيات */
    .stat-card {
        border: none;
        border-radius: 15px;
        transition: all 0.3s ease;
        overflow: hidden;
        position: relative;
        z-index: 1;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        height: 100%;
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(0,0,0,0.2);
    }
    
    .stat-icon {
        width: 60px;
        height: 60px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        color: white;
    }
    
    .stat-icon.products { background: linear-gradient(135deg, var(--secondary-color), #2980b9); }
    .stat-icon.warning { background: linear-gradient(135deg, var(--warning-color), #f1c40f); }
    .stat-icon.info { background: linear-gradient(135deg, var(--info-color), #16a085); }
    .stat-icon.success { background: linear-gradient(135deg, var(--success-color), #2ecc71); }
    
    /* الجداول */
    .dashboard-table {
        background: white;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    
    .dashboard-table .table {
        margin-bottom: 0;
    }
    
    .dashboard-table .table thead {
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
        color: white;
    }
    
    .dashboard-table .table th {
        border: none;
        font-weight: 600;
        padding: 15px;
    }
    
    .dashboard-table .table td {
        padding: 12px 15px;
        vertical-align: middle;
        border-color: #f0f0f0;
    }
    
    /* تحسين شريط البحث */
    .search-box {
        position: relative;
    }
    
    .search-box input {
        padding-right: 40px;
        border-radius: 25px;
        border: 2px solid #e0e0e0;
    }
    
    .search-box i {
        position: absolute;
        right: 15px;
        top: 50%;
        transform: translateY(-50%);
        color: #999;
    }
    
    /* المنتجات المنخفضة المخزون */
    .low-stock-item {
        padding: 10px 15px;
        margin-bottom: 8px;
        background: #fff8e1;
        border-radius: 8px;
        border-right: 4px solid var(--warning-color);
        transition: all 0.3s ease;
    }
    
    .low-stock-item:hover {
        background: #ffecb3;
        transform: translateX(-5px);
    }
    
    /* الفوتر */
    .footer {
        background-color: #f8f9fa;
        border-top: 1px solid #dee2e6;
        padding: 1rem 0;
        margin-top: auto;
        margin-right: 250px;
        transition: all 0.3s ease;
    }

    .sidebar-wrapper.collapsed ~ .main-content + .footer,
    .sidebar-wrapper.collapsed ~ .footer {
        margin-right: 0px;
    }
    
    /* الأنيميشن */
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .fade-in {
        animation: fadeIn 0.5s ease-out;
    }
    
    /* تصميم متجاوب */
    @media (max-width: 992px) {
        .sidebar-wrapper {
            transform: translateX(100%);
            width: 280px;
        }
        
        .sidebar-wrapper.show {
            transform: translateX(0);
        }
        
        .sidebar-toggler {
            display: flex;
        }
        
        .main-content {
            margin-right: 0 !important;
        }
        
        .navbar-custom {
            margin-right: 0 !important;
        }
        
        .footer {
            margin-right: 0 !important;
        }
        
        .sidebar-toggle-btn {
            display: none !important;
        }
    }

    @media (min-width: 993px) {
        .sidebar-toggler {
            display: none !important;
        }
    }
    /* تحسينات للهيدر */
.navbar-custom .container-fluid {
    padding-right: 15px;
    padding-left: 15px;
}

.navbar-custom .navbar-brand h5 {
    color: rgba(255, 255, 255, 0.9);
    font-weight: 600;
}

/* تحسين شريط البحث */
.search-box {
    position: relative;
}

.search-box input {
    padding-right: 40px;
    padding-left: 15px;
    border-radius: 25px;
    border: 2px solid rgba(255, 255, 255, 0.2);
    background-color: rgba(255, 255, 255, 0.1);
    color: white;
    transition: all 0.3s ease;
}

.search-box input:focus {
    background-color: rgba(255, 255, 255, 0.2);
    border-color: rgba(255, 255, 255, 0.4);
    color: white;
    box-shadow: 0 0 0 0.25rem rgba(255, 255, 255, 0.25);
}

.search-box input::placeholder {
    color: rgba(255, 255, 255, 0.6);
}

.search-box i {
    position: absolute;
    right: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: rgba(255, 255, 255, 0.7);
}

/* تحسين الأزرار في الهيدر */
.navbar-custom .btn-outline-light {
    border-color: rgba(255, 255, 255, 0.3);
    color: rgba(255, 255, 255, 0.9);
    transition: all 0.3s ease;
}

.navbar-custom .btn-outline-light:hover {
    background-color: rgba(255, 255, 255, 0.1);
    border-color: rgba(255, 255, 255, 0.5);
    transform: translateY(-2px);
}

/* تحسين Dropdown */
.navbar-custom .dropdown-menu {
    border: none;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
    overflow: hidden;
}

.navbar-custom .dropdown-item {
    padding: 10px 15px;
    transition: all 0.3s ease;
}

.navbar-custom .dropdown-item:hover {
    background-color: #f8f9fa;
    padding-right: 20px;
}

/* تحسين الأفاتار في الهيدر */
.user-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--secondary-color) 0%, var(--info-color) 100%);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 18px;
    border: 2px solid rgba(255, 255, 255, 0.3);
}

/* تحسين البادجات */
.badge {
    font-size: 0.7rem;
    font-weight: 600;
}

/* تحسين الشاشات الصغيرة */
@media (max-width: 768px) {
    .navbar-custom .container-fluid {
        padding-right: 10px;
        padding-left: 10px;
    }
    
    .search-box {
        display: none !important;
    }
    
    .navbar-custom .dropdown-toggle .text-start {
        display: none;
    }
}

@media (max-width: 992px) and (min-width: 769px) {
    .search-box input {
        width: 200px !important;
    }
}
</style>