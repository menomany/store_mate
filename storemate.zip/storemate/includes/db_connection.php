<?php
// db_connection.php - اتصال قاعدة البيانات

// معلومات الاتصال - عدلها حسب إعداداتك
$host = 'localhost';
$dbname = 'store_mate';
$username = 'root';
$password = '';

// إنشاء اتصال
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    
    // تعيين الترميز
    $pdo->exec("SET NAMES utf8mb4");
    $pdo->exec("SET time_zone = '+02:00'"); // توقيت مصر
    
} catch(PDOException $e) {
    // عرض رسالة خطأ بسيطة للمستخدم
    die("<div style='text-align: center; padding: 50px;'>
        <h3 style='color: #dc3545;'>خطأ في الاتصال بقاعدة البيانات</h3>
        <p>تعذر الاتصال بخادم قاعدة البيانات. الرجاء التحقق من:</p>
        <ol style='text-align: right; display: inline-block;'>
            <li>تشغيل خادم MySQL (XAMPP/WAMP/MAMP)</li>
            <li>صحة معلومات الاتصال في ملف db_connection.php</li>
            <li>وجود قاعدة البيانات 'store_mate'</li>
        </ol>
        <p style='margin-top: 20px;'>
            <a href='install.php' class='btn btn-primary'>تشغيل تثبيت تلقائي</a>
        </p>
        <hr>
        <small style='color: #666;'>تفاصيل الخطأ: " . htmlspecialchars($e->getMessage()) . "</small>
    </div>");
}

// دالة لإضافة مستخدم افتراضي إذا لم يكن موجوداً
function checkDefaultUser($pdo) {
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM users");
    $result = $stmt->fetch();
    
    if($result['count'] == 0) {
        // إضافة مستخدم مدير افتراضي
        $stmt = $pdo->prepare("INSERT INTO users (username, full_name, password, role) 
                              VALUES (?, ?, ?, ?)");
        $stmt->execute(['admin', 'مدير النظام', 'admin123', 'admin']);
        
        return true;
    }
    
    return false;
}

// استدعاء الدالة
checkDefaultUser($pdo);
?>