<?php
// db_connection.php - اتصال قاعدة البيانات المحدث للاستضافة

// المعلومات الجديدة بناءً على بيانات حسابك في InfinityFree
$host = 'sql105.infinityfree.com'; 
$username = 'if0_41039723';
$password = 'kDgLE4vnhSdDm4';

// ملاحظة: تأكد من اسم قاعدة البيانات بالكامل من لوحة التحكم (يجب أن يبدأ بـ if0_41039723_)
$dbname = 'if0_41039723_store_mate'; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    
    $pdo->exec("SET NAMES utf8mb4");
    $pdo->exec("SET time_zone = '+02:00'"); 
    
} catch(PDOException $e) {
    die("<div style='text-align: center; padding: 50px;'>
        <h3 style='color: #dc3545;'>خطأ في الاتصال بقاعدة البيانات على الاستضافة</h3>
        <p>تفاصيل الخطأ: " . htmlspecialchars($e->getMessage()) . "</small>
    </div>");
}

function checkDefaultUser($pdo) {
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM users");
    $result = $stmt->fetch();
    if($result['count'] == 0) {
        $stmt = $pdo->prepare("INSERT INTO users (username, full_name, password, role) 
                              VALUES (?, ?, ?, ?)");
        $stmt->execute(['admin', 'مدير النظام', 'admin123', 'admin']);
        return true;
    }
    return false;
}

checkDefaultUser($pdo);
?>