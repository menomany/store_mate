// includes/permissions.php
function hasPermission($requiredRole) {
    return isset($_SESSION['role']) && $_SESSION['role'] === $requiredRole;
}

function hasAnyPermission($roles) {
    return isset($_SESSION['role']) && in_array($_SESSION['role'], $roles);
}