<?php
session_start();
require_once 'includes/db_connection.php';

$error = '';

// التحقق من وجود كوكي "تذكرني"
if (empty($_SESSION['user_id']) && !empty($_COOKIE['remember_token'])) {
    try {
        // تقسيم الكوكي إلى معرف المستخدم والرمز
        list($user_id, $token) = explode(':', $_COOKIE['remember_token']);
        
        // البحث عن الرمز في قاعدة البيانات
        $stmt = $pdo->prepare("SELECT * FROM remember_tokens WHERE user_id = ? AND token = ? AND expires_at > NOW()");
        $stmt->execute([$user_id, $token]);
        $remember_token = $stmt->fetch();
        
        if ($remember_token) {
            // الحصول على بيانات المستخدم
            $userStmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND status = 'active'");
            $userStmt->execute([$user_id]);
            $user = $userStmt->fetch();
            
            if ($user) {
                // تسجيل الدخول تلقائياً
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['logged_in'] = true;
                
                // تحديث آخر وقت دخول
                $updateStmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
                $updateStmt->execute([$user['id']]);
                
                // تسجيل نشاط الدخول
                $activityStmt = $pdo->prepare("INSERT INTO user_activity (user_id, action, ip_address) VALUES (?, ?, ?)");
                $activityStmt->execute([
                    $user['id'], 
                    'الدخول التلقائي عبر تذكرني', 
                    $_SERVER['REMOTE_ADDR']
                ]);
                
                header('Location: dashboard.php');
                exit;
            }
        }
    } catch (PDOException $e) {
        // تجاهل الخطأ واكمل عملية تسجيل الدخول العادية
        error_log("Remember me error: " . $e->getMessage());
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $remember_me = isset($_POST['remember_me']) ? true : false;
    
    if (!empty($username) && !empty($password)) {
        try {
            // استعلام للحصول على المستخدم
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND status = 'active'");
            $stmt->execute([$username]);
            $user = $stmt->fetch();
            
            // التحقق من كلمة المرور باستخدام password_verify()
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['logged_in'] = true;
                
                // إذا اختار "تذكرني"، إنشاء كوكي
                if ($remember_me) {
                    // إنشاء رمز فريد
                    $token = bin2hex(random_bytes(32));
                    $expires = time() + (30 * 24 * 60 * 60); // 30 يوم
                    
                    // حفظ الرمز في قاعدة البيانات
                    $tokenStmt = $pdo->prepare("
                        INSERT INTO remember_tokens (user_id, token, expires_at, ip_address) 
                        VALUES (?, ?, FROM_UNIXTIME(?), ?)
                        ON DUPLICATE KEY UPDATE 
                        token = VALUES(token), 
                        expires_at = VALUES(expires_at),
                        ip_address = VALUES(ip_address)
                    ");
                    $tokenStmt->execute([
                        $user['id'],
                        $token,
                        $expires,
                        $_SERVER['REMOTE_ADDR']
                    ]);
                    
                    // إنشاء كوكي (30 يوم)
                    $cookie_value = $user['id'] . ':' . $token;
                    setcookie('remember_token', $cookie_value, $expires, '/', '', false, true);
                } else {
                    // حذف كوكي "تذكرني" إذا كان موجوداً
                    if (isset($_COOKIE['remember_token'])) {
                        setcookie('remember_token', '', time() - 3600, '/');
                        
                        // حذف الرمز من قاعدة البيانات
                        list($user_id, $token) = explode(':', $_COOKIE['remember_token']);
                        $deleteStmt = $pdo->prepare("DELETE FROM remember_tokens WHERE user_id = ? AND token = ?");
                        $deleteStmt->execute([$user_id, $token]);
                    }
                }
                
                // تحديث آخر وقت دخول
                $updateStmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
                $updateStmt->execute([$user['id']]);
                
                // تسجيل نشاط الدخول
                $activityStmt = $pdo->prepare("INSERT INTO user_activity (user_id, action, ip_address) VALUES (?, ?, ?)");
                $activityStmt->execute([
                    $user['id'], 
                    'الدخول إلى لوحة التحكم', 
                    $_SERVER['REMOTE_ADDR']
                ]);
                
                header('Location: dashboard.php');
                exit;
            } else {
                $error = 'اسم المستخدم أو كلمة المرور غير صحيحة';
                
                // تسجيل محاولة دخول فاشلة
                try {
                    $logStmt = $pdo->prepare("INSERT INTO login_attempts (username, ip_address, success) VALUES (?, ?, ?)");
                    $logStmt->execute([$username, $_SERVER['REMOTE_ADDR'], 0]);
                } catch (Exception $e) {
                    // تجاهل خطأ تسجيل المحاولة
                }
            }
        } catch (PDOException $e) {
            $error = 'حدث خطأ في النظام. الرجاء المحاولة مرة أخرى لاحقاً.';
            error_log("Login error: " . $e->getMessage());
        }
    } else {
        $error = 'الرجاء إدخال جميع البيانات المطلوبة';
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول - StoreMate</title>
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    
    <!-- الخط العربي -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #1abc9c;
            --light-color: #f8f9fa;
            --dark-color: #2c3e50;
        }
        
        body {
            font-family: 'Cairo', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .login-container {
            width: 100%;
            max-width: 450px;
            animation: fadeIn 0.6s ease-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .login-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s ease;
        }
        
        .login-card:hover {
            transform: translateY(-5px);
        }
        
        .login-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            padding: 40px 20px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        
        .login-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="rgba(255,255,255,0.1)" d="M0,96L48,112C96,128,192,160,288,186.7C384,213,480,235,576,213.3C672,192,768,128,864,122.7C960,117,1056,171,1152,197.3C1248,224,1344,224,1392,224L1440,224L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>');
            background-size: cover;
            opacity: 0.1;
        }
        
        .login-logo {
            width: 80px;
            height: 80px;
            margin: 0 auto 20px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.5rem;
            color: white;
            position: relative;
            z-index: 2;
        }
        
        .login-header h4 {
            position: relative;
            z-index: 2;
            font-weight: 700;
            margin-bottom: 10px;
        }
        
        .login-header p {
            position: relative;
            z-index: 2;
            opacity: 0.9;
            margin-bottom: 0;
        }
        
        .login-body {
            padding: 40px 30px;
        }
        
        .input-group {
            border-radius: 12px;
            overflow: hidden;
            border: 2px solid #e0e0e0;
            transition: all 0.3s;
        }
        
        .input-group:focus-within {
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 0.25rem rgba(52, 152, 219, 0.25);
        }
        
        .input-group-text {
            background: #f8f9fa;
            border: none;
            padding: 0 20px;
            color: #6c757d;
        }
        
        .form-control {
            border: none;
            padding: 15px;
            font-size: 1rem;
            background: transparent;
        }
        
        .form-control:focus {
            box-shadow: none;
            background: transparent;
        }
        
        .form-label {
            font-weight: 600;
            color: var(--dark-color);
            margin-bottom: 8px;
            display: block;
        }
        
        .btn-login {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            border: none;
            padding: 15px;
            border-radius: 12px;
            font-weight: 600;
            font-size: 1.1rem;
            width: 100%;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(52, 152, 219, 0.3);
            color: white;
        }
        
        .alert {
            border-radius: 12px;
            border: none;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .version-text {
            text-align: center;
            color: #6c757d;
            font-size: 0.9rem;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #e0e0e0;
        }
        
        .password-toggle {
            cursor: pointer;
            padding: 0 15px;
            background: #f8f9fa;
            border-left: 1px solid #e0e0e0;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #6c757d;
            transition: color 0.3s;
        }
        
        .password-toggle:hover {
            color: var(--secondary-color);
        }
        
        /* تنسيق خيار "تذكرني" */
        .remember-me {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        
        .form-check {
            display: flex;
            align-items: center;
            gap: 8px;
            margin: 0;
        }
        
        .form-check-input {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }
        
        .form-check-input:checked {
            background-color: var(--secondary-color);
            border-color: var(--secondary-color);
        }
        
        .form-check-label {
            cursor: pointer;
            font-weight: 500;
            color: var(--dark-color);
        }
        
        /* Responsive */
        @media (max-width: 576px) {
            .login-body {
                padding: 30px 20px;
            }
            
            .login-header {
                padding: 30px 20px;
            }
            
            .login-logo {
                width: 70px;
                height: 70px;
                font-size: 2rem;
            }
            
            .remember-me {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
        }
        
        /* Animation for error */
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
            20%, 40%, 60%, 80% { transform: translateX(5px); }
        }
        
        .shake {
            animation: shake 0.5s ease-in-out;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <div class="login-logo">
                    <i class="bi bi-box-seam"></i>
                </div>
                <h4>مرحباً بك في StoreMate</h4>
                <p>رفيقك الذكي لإدارة المخزون</p>
            </div>
            
            <div class="login-body">
                <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show shake" role="alert">
                    <div class="d-flex align-items-center">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i>
                        <div><?php echo htmlspecialchars($error); ?></div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php endif; ?>
                
                <form method="POST" action="" id="loginForm">
                    <div class="mb-4">
                        <label for="username" class="form-label">اسم المستخدم</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-person"></i></span>
                            <input type="text" class="form-control" id="username" name="username" 
                                   placeholder="أدخل اسم المستخدم" required autofocus
                                   value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <label for="password" class="form-label">كلمة المرور</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-lock"></i></span>
                            <input type="password" class="form-control" id="password" name="password" 
                                   placeholder="أدخل كلمة المرور" required>
                            <span class="password-toggle" id="togglePassword">
                                <i class="bi bi-eye"></i>
                            </span>
                        </div>
                    </div>
                    
                    <!-- قسم "تذكرني" -->
                    <div class="remember-me">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="remember_me" name="remember_me" 
                                   <?php echo (isset($_POST['remember_me']) || isset($_COOKIE['remember_token'])) ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="remember_me">
                                <i class="bi bi-check-square"></i> تذكرني على هذا الجهاز
                            </label>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-login mb-4" id="loginBtn">
                        <i class="bi bi-box-arrow-in-right"></i> تسجيل الدخول
                        <span id="loadingSpinner" class="spinner-border spinner-border-sm d-none" role="status"></span>
                    </button>
                    
                    <div class="version-text">
                        الإصدار 1.2.0 | &copy; <?php echo date('Y'); ?> StoreMate
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // عرض/إخفاء كلمة المرور
        document.getElementById('togglePassword').addEventListener('click', function() {
            const passwordInput = document.getElementById('password');
            const eyeIcon = this.querySelector('i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                eyeIcon.className = 'bi bi-eye-slash';
            } else {
                passwordInput.type = 'password';
                eyeIcon.className = 'bi bi-eye';
            }
        });
        
        // إضافة تأثير التحميل عند النقر
        document.getElementById('loginForm').addEventListener('submit', function() {
            const loginBtn = document.getElementById('loginBtn');
            const spinner = document.getElementById('loadingSpinner');
            
            loginBtn.disabled = true;
            spinner.classList.remove('d-none');
            loginBtn.innerHTML = '<i class="bi bi-box-arrow-in-right"></i> جاري تسجيل الدخول...';
        });
        
        // إعادة تمكين الزر إذا كان هناك خطأ في التحقق
        document.querySelectorAll('input').forEach(input => {
            input.addEventListener('invalid', function() {
                const loginBtn = document.getElementById('loginBtn');
                const spinner = document.getElementById('loadingSpinner');
                
                setTimeout(() => {
                    loginBtn.disabled = false;
                    spinner.classList.add('d-none');
                    loginBtn.innerHTML = '<i class="bi bi-box-arrow-in-right"></i> تسجيل الدخول';
                }, 100);
            });
        });
        
        // التركيز على حقل اسم المستخدم إذا كان فارغاً
        document.addEventListener('DOMContentLoaded', function() {
            const usernameInput = document.getElementById('username');
            if (!usernameInput.value) {
                usernameInput.focus();
            }
        });
    </script>
</body>
</html>