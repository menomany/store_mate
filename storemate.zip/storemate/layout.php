<?php
// layout.php - قالب موحد لجميع الصفحات

function renderLayout($page_title, $content) {
    ?>
    <!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?> - StoreMate</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- الخط العربي -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    <!-- CSS المخصص -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- الحاوية الرئيسية -->
    <div class="container-fluid">
        <!-- صف واحد يحتوي على عمودين -->
        <div class="row">
            <!-- العمود الأول: السايدبار (عرض 2 من 12 عمود) -->
            <div class="col-lg-2 col-md-3 d-none d-md-block p-0">
                <?php include 'sidebar.php'; ?>
            </div>
            
            <!-- العمود الثاني: المحتوى الرئيسي (عرض 10 من 12 عمود) -->
            <div class="col-lg-10 col-md-9 ms-sm-auto p-0">
                <!-- شريط التنقل العلوي -->
                <?php include 'header.php'; ?>
                
                <!-- محتوى الصفحة الرئيسي -->
                <main class="p-4">
                    <?php echo $content; ?>
                </main>
                
                <!-- الفوتر -->
                <?php include 'footer.php'; ?>
            </div>
        </div>
    </div>
    
    <!-- زر إظهار/إخفاء السايدبار في الجوال -->
    <button class="sidebar-toggle d-md-none" onclick="toggleSidebar()">
        <i class="bi bi-list"></i>
    </button>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- JS المخصص -->
    <script src="script.js"></script>
    <script>
    // إظهار/إخفاء السايدبار في الجوال
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        sidebar.classList.toggle('show');
    }
    </script>
</body>
</html>
    <?php
}
?>