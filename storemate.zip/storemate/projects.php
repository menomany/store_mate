<?php
session_start();
require_once 'includes/db_connection.php';
require_once 'includes/auth_check.php';

$page_title = "المشاريع";

// جلب المشاريع
$search = $_GET['search'] ?? '';
$status = $_GET['status'] ?? '';

$query = "SELECT * FROM projects WHERE 1=1";
$params = [];

if(!empty($search)) {
    $query .= " AND (project_name LIKE ? OR client_name LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if(!empty($status)) {
    $query .= " AND project_status = ?";
    $params[] = $status;
}

$query .= " ORDER BY start_date DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$projects = $stmt->fetchAll();

// حساب إحصائيات المشاريع
$stats = [
    'total_projects' => 0,
    'active_projects' => 0,
    'completed_projects' => 0,
    'on_hold_projects' => 0,
    'total_budget' => 0,
    'total_spent' => 0
];

foreach($projects as $project) {
    $stats['total_projects']++;
    
    // حساب إجمالي الصرفيات للمشروع
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(total_amount), 0) as total_spent 
                           FROM transactions 
                           WHERE project_id = ? AND trans_type = 'issue'");
    $stmt->execute([$project['project_id']]);
    $project_spent = $stmt->fetch()['total_spent'];
    
    $stats['total_budget'] += ($project['budget_limit'] ?? 0);
    $stats['total_spent'] += $project_spent;
    
    switch($project['project_status']) {
        case 'active': $stats['active_projects']++; break;
        case 'completed': $stats['completed_projects']++; break;
        case 'on_hold': $stats['on_hold_projects']++; break;
    }
}

// حالة المشاريع
$project_statuses = [
    'active' => ['name' => 'نشط', 'color' => 'success', 'icon' => 'bi-play-circle'],
    'completed' => ['name' => 'مكتمل', 'color' => 'secondary', 'icon' => 'bi-check-circle'],
    'on_hold' => ['name' => 'معلق', 'color' => 'warning', 'icon' => 'bi-pause-circle']
];
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - StoreMate</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- الخط العربي -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    <!-- CSS المخصص -->
    <link rel="stylesheet" href="style.css">
    
    <style>
        .project-card {
            transition: all 0.3s ease;
            height: 100%;
        }
        
        .project-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }
        
        .project-progress {
            height: 8px;
            border-radius: 4px;
        }
        
        .project-budget {
            font-size: 0.9rem;
        }
        
        .project-status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
        }
    </style>
</head>
<body>
    <!-- السايدبار -->
    <div class="sidebar d-none d-md-block">
        <?php include 'sidebar.php'; ?>
    </div>
    
    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <nav class="navbar navbar-expand-lg navbar-dark navbar-custom mb-4">
            <div class="container">
                <button class="navbar-toggler d-md-none" type="button" onclick="toggleSidebar()">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
                <a class="navbar-brand d-flex align-items-center" href="dashboard.php">
                    <i class="bi bi-box-seam me-2 fs-4"></i>
                    <span class="fw-bold fs-4">StoreMate</span>
                </a>
                
                <div class="d-flex align-items-center">
                    <!-- الملف الشخصي -->
                    <div class="dropdown">
                        <button class="btn btn-outline-light dropdown-toggle d-flex align-items-center" type="button" data-bs-toggle="dropdown">
                            <div class="user-avatar me-2">
                                <?php echo substr($_SESSION['full_name'], 0, 1); ?>
                            </div>
                            <div class="text-start">
                                <small class="d-block"><?php echo $_SESSION['full_name']; ?></small>
                                <small class="d-block opacity-75"><?php echo $_SESSION['role']; ?></small>
                            </div>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="profile.php">
                                <i class="bi bi-person me-2"></i> الملف الشخصي
                            </a></li>
                            <li><a class="dropdown-item" href="settings.php">
                                <i class="bi bi-gear me-2"></i> الإعدادات
                            </a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="logout.php">
                                <i class="bi bi-box-arrow-right me-2"></i> تسجيل الخروج
                            </a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
        
        <!-- بطاقة الترحيب -->
        <div class="welcome-card fade-in">
            <div class="container p-4 position-relative">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h2 class="mb-2">إدارة المشاريع</h2>
                        <p class="mb-0 opacity-75">تتبع وإدارة جميع مشاريع المؤسسة</p>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <button class="btn btn-light" data-bs-toggle="modal" data-bs-target="#addProjectModal">
                            <i class="bi bi-plus-circle me-1"></i>إضافة مشروع
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- بطاقات الإحصائيات -->
        <div class="row mb-4 fade-in">
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">إجمالي المشاريع</h6>
                                <h3 class="mb-0"><?php echo $stats['total_projects']; ?></h3>
                                <small class="text-primary">مشروع في النظام</small>
                            </div>
                            <div class="stat-icon">
                                <i class="bi bi-briefcase"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card success">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">المشاريع النشطة</h6>
                                <h3 class="mb-0"><?php echo $stats['active_projects']; ?></h3>
                                <small class="text-success">مشروع نشط</small>
                            </div>
                            <div class="stat-icon success">
                                <i class="bi bi-play-circle"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card secondary">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">المشاريع المكتملة</h6>
                                <h3 class="mb-0"><?php echo $stats['completed_projects']; ?></h3>
                                <small class="text-secondary">مشروع مكتمل</small>
                            </div>
                            <div class="stat-icon secondary">
                                <i class="bi bi-check-circle"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card warning">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">المشاريع المعلقة</h6>
                                <h3 class="mb-0"><?php echo $stats['on_hold_projects']; ?></h3>
                                <small class="text-warning">مشروع معلق</small>
                            </div>
                            <div class="stat-icon warning">
                                <i class="bi bi-pause-circle"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- إحصائيات الميزانية -->
        <div class="row mb-4 fade-in">
            <div class="col-md-6 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h6 class="card-title mb-3">إحصائيات الميزانية</h6>
                        <div class="row">
                            <div class="col-6 mb-3">
                                <div class="text-center p-3 bg-light rounded">
                                    <div class="h4 text-primary mb-1">
                                        <i class="bi bi-cash-stack"></i>
                                    </div>
                                    <div class="h5 fw-bold"><?php echo number_format($stats['total_budget'], 2); ?> ج.م</div>
                                    <small class="text-muted">إجمالي الميزانية</small>
                                </div>
                            </div>
                            <div class="col-6 mb-3">
                                <div class="text-center p-3 bg-light rounded">
                                    <div class="h4 text-warning mb-1">
                                        <i class="bi bi-cash"></i>
                                    </div>
                                    <div class="h5 fw-bold"><?php echo number_format($stats['total_spent'], 2); ?> ج.م</div>
                                    <small class="text-muted">إجمالي الصرفيات</small>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="text-center p-3 bg-light rounded">
                                    <div class="h4 text-success mb-1">
                                        <i class="bi bi-coin"></i>
                                    </div>
                                    <div class="h5 fw-bold"><?php echo number_format($stats['total_budget'] - $stats['total_spent'], 2); ?> ج.م</div>
                                    <small class="text-muted">المتبقي</small>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="text-center p-3 bg-light rounded">
                                    <div class="h4 text-info mb-1">
                                        <i class="bi bi-percent"></i>
                                    </div>
                                    <div class="h5 fw-bold">
                                        <?php echo $stats['total_budget'] > 0 ? number_format(($stats['total_spent'] / $stats['total_budget']) * 100, 1) : 0; ?>%
                                    </div>
                                    <small class="text-muted">نسبة التنفيذ</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- فلترة البحث -->
            <div class="col-md-6 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h6 class="card-title mb-3">فلترة المشاريع</h6>
                        <form method="GET" class="row g-3">
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="search" 
                                       placeholder="بحث باسم المشروع أو العميل" value="<?php echo htmlspecialchars($search); ?>">
                            </div>
                            <div class="col-md-4">
                                <select class="form-select" name="status">
                                    <option value="">كل الحالات</option>
                                    <?php foreach($project_statuses as $key => $status_info): ?>
                                    <option value="<?php echo $key; ?>" <?php echo $status == $key ? 'selected' : ''; ?>>
                                        <?php echo $status_info['name']; ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="bi bi-search"></i> بحث
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- بطاقات المشاريع -->
        <div class="row fade-in">
            <?php if(count($projects) > 0): ?>
                <?php foreach($projects as $project): 
                    $status_info = $project_statuses[$project['project_status']] ?? 
                                  ['name' => 'غير محدد', 'color' => 'secondary', 'icon' => 'bi-question-circle'];
                    
                    // حساب إجمالي الصرفيات للمشروع
                    $stmt = $pdo->prepare("SELECT COALESCE(SUM(total_amount), 0) as total_spent 
                                           FROM transactions 
                                           WHERE project_id = ? AND trans_type = 'issue'");
                    $stmt->execute([$project['project_id']]);
                    $total_spent = $stmt->fetch()['total_spent'];
                    
                    $budget = $project['budget_limit'] ?? 0;
                    $progress = $budget > 0 ? ($total_spent / $budget) * 100 : 0;
                ?>
                <div class="col-md-4 mb-4">
                    <div class="card project-card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <div>
                                    <h5 class="card-title mb-1"><?php echo htmlspecialchars($project['project_name']); ?></h5>
                                    <p class="text-muted mb-0"><?php echo htmlspecialchars($project['client_name'] ?? '---'); ?></p>
                                </div>
                                <span class="badge bg-<?php echo $status_info['color']; ?> project-status-badge">
                                    <i class="bi <?php echo $status_info['icon']; ?> me-1"></i>
                                    <?php echo $status_info['name']; ?>
                                </span>
                            </div>
                            
                            <p class="card-text mb-3">
                                <i class="bi bi-geo-alt me-1"></i>
                                <?php echo htmlspecialchars($project['project_location'] ?? '---'); ?>
                            </p>
                            
                            <div class="mb-3">
                                <small class="text-muted">
                                    <i class="bi bi-calendar me-1"></i>
                                    تاريخ البدء: <?php echo $project['start_date'] ? date('Y-m-d', strtotime($project['start_date'])) : '---'; ?>
                                </small>
                            </div>
                            
                            <?php if($budget > 0): ?>
                            <div class="mb-3">
                                <div class="d-flex justify-content-between mb-1">
                                    <small class="text-muted">الميزانية</small>
                                    <small><?php echo number_format($total_spent, 2); ?> / <?php echo number_format($budget, 2); ?> ج.م</small>
                                </div>
                                <div class="progress project-progress">
                                    <div class="progress-bar <?php echo $progress > 100 ? 'bg-danger' : 'bg-success'; ?>" 
                                         style="width: <?php echo min($progress, 100); ?>%">
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <div class="d-flex justify-content-between mt-3">
                                <button class="btn btn-sm btn-outline-info" 
                                        onclick="viewProject(<?php echo $project['project_id']; ?>)">
                                    <i class="bi bi-eye"></i> عرض
                                </button>
                                <button class="btn btn-sm btn-outline-warning"
                                        onclick="editProject(<?php echo $project['project_id']; ?>)">
                                    <i class="bi bi-pencil"></i> تعديل
                                </button>
                                <button class="btn btn-sm btn-outline-danger" 
                                        onclick="deleteProject(<?php echo $project['project_id']; ?>, '<?php echo htmlspecialchars($project['project_name']); ?>')">
                                    <i class="bi bi-trash"></i> حذف
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
            <div class="col-12">
                <div class="text-center py-5">
                    <i class="bi bi-inbox display-1 text-muted"></i>
                    <h5 class="mt-3">لا توجد مشاريع</h5>
                    <p>ابدأ بإضافة مشاريع جديدة إلى النظام</p>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- مودال إضافة مشروع -->
    <div class="modal fade" id="addProjectModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">إضافة مشروع جديد</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form action="api/save_project.php" method="POST" id="projectForm">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">اسم المشروع *</label>
                            <input type="text" class="form-control" name="project_name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">اسم العميل</label>
                            <input type="text" class="form-control" name="client_name">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">موقع المشروع</label>
                            <input type="text" class="form-control" name="project_location">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">ميزانية المشروع</label>
                            <input type="number" class="form-control" name="budget_limit" step="0.01">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">تاريخ البدء</label>
                            <input type="date" class="form-control" name="start_date">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">حالة المشروع</label>
                            <select class="form-select" name="project_status">
                                <?php foreach($project_statuses as $key => $status_info): ?>
                                <option value="<?php echo $key; ?>"><?php echo $status_info['name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">ملاحظات</label>
                            <textarea class="form-control" name="notes" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary">حفظ المشروع</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- زر إظهار/إخفاء السايدبار في الجوال -->
    <button class="sidebar-toggle d-md-none" onclick="toggleSidebar()">
        <i class="bi bi-list"></i>
    </button>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="script.js"></script>
    <script>
    function viewProject(id) {
        window.location.href = 'project_details.php?id=' + id;
    }

    function editProject(id) {
        window.location.href = 'edit_project.php?id=' + id;
    }

    function deleteProject(id, name) {
        if(confirm(`هل أنت متأكد من حذف المشروع "${name}"؟`)) {
            fetch(`api/delete_project.php?id=${id}`, {
                method: 'DELETE'
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    alert('تم الحذف بنجاح');
                    window.location.reload();
                } else {
                    alert(data.message || 'حدث خطأ أثناء الحذف');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('حدث خطأ في الاتصال');
            });
        }
    }
    
    // معالجة نموذج إضافة المشروع
    document.getElementById('projectForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        
        fetch('api/save_project.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                alert('تم إضافة المشروع بنجاح');
                window.location.reload();
            } else {
                alert('حدث خطأ: ' + (data.message || 'غير معروف'));
            }
        })
        .catch(error => {
            alert('حدث خطأ في الاتصال بالخادم');
        });
    });
    </script>
</body>
</html>