<?php
session_start();
require_once 'includes/db_connection.php';
require_once 'includes/auth_check.php';

$page_title = "الخزينة";

// جلب حركات الخزينة
$search = $_GET['search'] ?? '';
$operation_type = $_GET['operation_type'] ?? '';
$payment_method = $_GET['payment_method'] ?? '';
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';

$query = "SELECT t.*, c.contact_name, tr.trans_id as related_transaction
          FROM treasury t
          LEFT JOIN contacts c ON t.contact_id = c.contact_id
          LEFT JOIN transactions tr ON t.trans_id = tr.trans_id
          WHERE 1=1";

$params = [];

if(!empty($search)) {
    $query .= " AND (c.contact_name LIKE ? OR t.notes LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if(!empty($operation_type)) {
    $query .= " AND t.operation_type = ?";
    $params[] = $operation_type;
}

if(!empty($payment_method)) {
    $query .= " AND t.payment_method = ?";
    $params[] = $payment_method;
}

if(!empty($start_date)) {
    $query .= " AND DATE(t.created_at) >= ?";
    $params[] = $start_date;
}

if(!empty($end_date)) {
    $query .= " AND DATE(t.created_at) <= ?";
    $params[] = $end_date;
}

$query .= " ORDER BY t.created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$treasury_transactions = $stmt->fetchAll();

// حساب إحصائيات الخزينة
$stats = [
    'total_in' => 0,
    'total_out' => 0,
    'balance' => 0,
    'today_in' => 0,
    'today_out' => 0
];

// حساب إجمالي الإيرادات والمصروفات
foreach($treasury_transactions as $trans) {
    if($trans['operation_type'] == 'in') {
        $stats['total_in'] += $trans['amount'];
    } else {
        $stats['total_out'] += $trans['amount'];
    }
}

$stats['balance'] = $stats['total_in'] - $stats['total_out'];

// حركات اليوم
$stmt = $pdo->prepare("
    SELECT 
        COALESCE(SUM(CASE WHEN operation_type = 'in' THEN amount END), 0) as today_in,
        COALESCE(SUM(CASE WHEN operation_type = 'out' THEN amount END), 0) as today_out
    FROM treasury 
    WHERE DATE(created_at) = CURDATE()
");
$stmt->execute();
$today_stats = $stmt->fetch();
$stats['today_in'] = $today_stats['today_in'];
$stats['today_out'] = $today_stats['today_out'];

// أنواع العمليات
$operation_types = [
    'in' => ['name' => 'دخل', 'icon' => 'bi-cash-coin', 'color' => 'success'],
    'out' => ['name' => 'خرج', 'icon' => 'bi-cash-stack', 'color' => 'danger']
];

// طرق الدفع
$payment_methods = [
    'cash' => ['name' => 'نقدي', 'icon' => 'bi-wallet'],
    'transfer' => ['name' => 'تحويل بنكي', 'icon' => 'bi-bank'],
    'check' => ['name' => 'شيك', 'icon' => 'bi-receipt']
];
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - StoreMate</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- الخط العربي -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    <!-- CSS المخصص -->
    <link rel="stylesheet" href="style.css">
    
    <style>
        .treasury-card {
            border: none;
            border-radius: 12px;
            overflow: hidden;
        }
        
        .treasury-in {
            border-right: 4px solid var(--success-color);
        }
        
        .treasury-out {
            border-right: 4px solid var(--danger-color);
        }
        
        .balance-positive {
            color: var(--success-color);
        }
        
        .balance-negative {
            color: var(--danger-color);
        }
        
        .payment-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
        }
    </style>
</head>
<body>
    <!-- السايدبار -->
    <div class="sidebar d-none d-md-block">
        <?php include 'sidebar.php'; ?>
    </div>
    
    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <nav class="navbar navbar-expand-lg navbar-dark navbar-custom mb-4">
            <div class="container">
                <button class="navbar-toggler d-md-none" type="button" onclick="toggleSidebar()">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
                <a class="navbar-brand d-flex align-items-center" href="dashboard.php">
                    <i class="bi bi-box-seam me-2 fs-4"></i>
                    <span class="fw-bold fs-4">StoreMate</span>
                </a>
                
                <div class="d-flex align-items-center">
                    <!-- الملف الشخصي -->
                    <div class="dropdown">
                        <button class="btn btn-outline-light dropdown-toggle d-flex align-items-center" type="button" data-bs-toggle="dropdown">
                            <div class="user-avatar me-2">
                                <?php echo substr($_SESSION['full_name'], 0, 1); ?>
                            </div>
                            <div class="text-start">
                                <small class="d-block"><?php echo $_SESSION['full_name']; ?></small>
                                <small class="d-block opacity-75"><?php echo $_SESSION['role']; ?></small>
                            </div>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="profile.php">
                                <i class="bi bi-person me-2"></i> الملف الشخصي
                            </a></li>
                            <li><a class="dropdown-item" href="settings.php">
                                <i class="bi bi-gear me-2"></i> الإعدادات
                            </a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="logout.php">
                                <i class="bi bi-box-arrow-right me-2"></i> تسجيل الخروج
                            </a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
        
        <!-- بطاقة الترحيب -->
        <div class="welcome-card fade-in">
            <div class="container p-4 position-relative">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h2 class="mb-2">إدارة الخزينة</h2>
                        <p class="mb-0 opacity-75">تتبع وإدارة حركات الخزينة النقدية</p>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <button class="btn btn-light" data-bs-toggle="modal" data-bs-target="#addTreasuryModal">
                            <i class="bi bi-plus-circle me-1"></i>إضافة حركة
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- بطاقات الإحصائيات -->
        <div class="row mb-4 fade-in">
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card <?php echo $stats['balance'] >= 0 ? 'success' : 'danger'; ?>">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">رصيد الخزينة</h6>
                                <h3 class="mb-0 <?php echo $stats['balance'] >= 0 ? 'text-success' : 'text-danger'; ?>">
                                    <?php echo number_format($stats['balance'], 2); ?> ج.م
                                </h3>
                                <small class="<?php echo $stats['balance'] >= 0 ? 'text-success' : 'text-danger'; ?>">
                                    <?php echo $stats['balance'] >= 0 ? 'إيجابي' : 'سلبي'; ?>
                                </small>
                            </div>
                            <div class="stat-icon <?php echo $stats['balance'] >= 0 ? 'success' : 'danger'; ?>">
                                <i class="bi <?php echo $stats['balance'] >= 0 ? 'bi-arrow-up-circle' : 'bi-arrow-down-circle'; ?>"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card success">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">إجمالي الدخل</h6>
                                <h3 class="mb-0"><?php echo number_format($stats['total_in'], 2); ?> ج.م</h3>
                                <small class="text-success">إيرادات الخزينة</small>
                            </div>
                            <div class="stat-icon success">
                                <i class="bi bi-cash-coin"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card danger">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">إجمالي المصروف</h6>
                                <h3 class="mb-0"><?php echo number_format($stats['total_out'], 2); ?> ج.م</h3>
                                <small class="text-danger">مصروفات الخزينة</small>
                            </div>
                            <div class="stat-icon danger">
                                <i class="bi bi-cash-stack"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card warning">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">صافي اليوم</h6>
                                <h3 class="mb-0 <?php echo ($stats['today_in'] - $stats['today_out']) >= 0 ? 'text-success' : 'text-danger'; ?>">
                                    <?php echo number_format($stats['today_in'] - $stats['today_out'], 2); ?> ج.م
                                </h3>
                                <small class="text-warning">حركات اليوم</small>
                            </div>
                            <div class="stat-icon warning">
                                <i class="bi bi-calendar-day"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- فلترة البحث -->
        <div class="card mb-4 fade-in">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-2">
                        <input type="text" class="form-control" name="search" 
                               placeholder="بحث بالجهة أو الملاحظات" value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="col-md-2">
                        <select class="form-select" name="operation_type">
                            <option value="">كل العمليات</option>
                            <?php foreach($operation_types as $key => $type_info): ?>
                            <option value="<?php echo $key; ?>" <?php echo $operation_type == $key ? 'selected' : ''; ?>>
                                <?php echo $type_info['name']; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select class="form-select" name="payment_method">
                            <option value="">كل الطرق</option>
                            <?php foreach($payment_methods as $key => $method_info): ?>
                            <option value="<?php echo $key; ?>" <?php echo $payment_method == $key ? 'selected' : ''; ?>>
                                <?php echo $method_info['name']; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <input type="date" class="form-control" name="start_date" value="<?php echo $start_date; ?>">
                    </div>
                    <div class="col-md-2">
                        <input type="date" class="form-control" name="end_date" value="<?php echo $end_date; ?>">
                    </div>
                    <div class="col-md-1">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-search"></i>
                        </button>
                    </div>
                    <div class="col-md-1">
                        <a href="treasury.php" class="btn btn-secondary w-100">
                            <i class="bi bi-arrow-clockwise"></i>
                        </a>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- جدول حركات الخزينة -->
        <div class="dashboard-table fade-in">
            <div class="card">
                <div class="card-body">
                    <?php if(count($treasury_transactions) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>التاريخ</th>
                                    <th>نوع العملية</th>
                                    <th>طريقة الدفع</th>
                                    <th>الجهة</th>
                                    <th>المبلغ</th>
                                    <th>الملاحظات</th>
                                    <th>الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($treasury_transactions as $index => $trans): 
                                    $type_info = $operation_types[$trans['operation_type']] ?? 
                                                ['name' => 'غير معروف', 'icon' => 'bi-question-circle', 'color' => 'secondary'];
                                    $method_info = $payment_methods[$trans['payment_method']] ?? 
                                                 ['name' => 'غير معروف', 'icon' => 'bi-question-circle'];
                                ?>
                                <tr class="<?php echo $trans['operation_type'] == 'in' ? 'treasury-in' : 'treasury-out'; ?>">
                                    <td><?php echo $index + 1; ?></td>
                                    <td>
                                        <small class="d-block"><?php echo date('Y-m-d', strtotime($trans['created_at'])); ?></small>
                                        <small class="text-muted"><?php echo date('H:i', strtotime($trans['created_at'])); ?></small>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo $type_info['color']; ?>">
                                            <i class="bi <?php echo $type_info['icon']; ?> me-1"></i>
                                            <?php echo $type_info['name']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-info payment-badge">
                                            <i class="bi <?php echo $method_info['icon']; ?> me-1"></i>
                                            <?php echo $method_info['name']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars($trans['contact_name'] ?? '---'); ?></td>
                                    <td>
                                        <strong class="<?php echo $trans['operation_type'] == 'in' ? 'text-success' : 'text-danger'; ?>">
                                            <?php echo number_format($trans['amount'], 2); ?> ج.م
                                        </strong>
                                    </td>
                                    <td><?php echo htmlspecialchars($trans['notes'] ?? '---'); ?></td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <button class="btn btn-outline-warning"
                                                    onclick="editTreasury(<?php echo $trans['cash_id']; ?>)"
                                                    title="تعديل">
                                                <i class="bi bi-pencil"></i>
                                            </button>
                                            <button class="btn btn-outline-danger" 
                                                    onclick="deleteTreasury(<?php echo $trans['cash_id']; ?>)"
                                                    title="حذف">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="text-center py-5">
                        <i class="bi bi-inbox display-1 text-muted"></i>
                        <h5 class="mt-3">لا توجد حركات خزينة</h5>
                        <p>ابدأ بإضافة حركات جديدة للخزينة</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- مودال إضافة حركة خزينة -->
    <div class="modal fade" id="addTreasuryModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">إضافة حركة خزينة</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form action="api/save_treasury.php" method="POST" id="treasuryForm">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">نوع العملية *</label>
                                <select class="form-select" name="operation_type" required>
                                    <option value="">اختر النوع</option>
                                    <?php foreach($operation_types as $key => $type_info): ?>
                                    <option value="<?php echo $key; ?>"><?php echo $type_info['name']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">طريقة الدفع *</label>
                                <select class="form-select" name="payment_method" required>
                                    <option value="">اختر الطريقة</option>
                                    <?php foreach($payment_methods as $key => $method_info): ?>
                                    <option value="<?php echo $key; ?>"><?php echo $method_info['name']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">المبلغ *</label>
                                <input type="number" class="form-control" name="amount" step="0.01" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">الجهة</label>
                                <select class="form-select" name="contact_id">
                                    <option value="">اختر الجهة</option>
                                    <?php 
                                    $contacts = $pdo->query("SELECT * FROM contacts ORDER BY contact_name")->fetchAll();
                                    foreach($contacts as $contact): ?>
                                    <option value="<?php echo $contact['contact_id']; ?>">
                                        <?php echo htmlspecialchars($contact['contact_name']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-12 mb-3">
                                <label class="form-label">الملاحظات</label>
                                <textarea class="form-control" name="notes" rows="3"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary">حفظ الحركة</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- زر إظهار/إخفاء السايدبار في الجوال -->
    <button class="sidebar-toggle d-md-none" onclick="toggleSidebar()">
        <i class="bi bi-list"></i>
    </button>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="script.js"></script>
    <script>
    function editTreasury(id) {
        window.location.href = 'edit_treasury.php?id=' + id;
    }

    function deleteTreasury(id) {
        if(confirm('هل أنت متأكد من حذف هذه الحركة؟')) {
            fetch(`api/delete_treasury.php?id=${id}`, {
                method: 'DELETE'
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    alert('تم الحذف بنجاح');
                    window.location.reload();
                } else {
                    alert(data.message || 'حدث خطأ أثناء الحذف');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('حدث خطأ في الاتصال');
            });
        }
    }
    
    // معالجة نموذج إضافة حركة الخزينة
    document.getElementById('treasuryForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        
        fetch('api/save_treasury.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                alert('تم إضافة الحركة بنجاح');
                window.location.reload();
            } else {
                alert('حدث خطأ: ' + (data.message || 'غير معروف'));
            }
        })
        .catch(error => {
            alert('حدث خطأ في الاتصال بالخادم');
        });
    });
    </script>
</body>
</html>