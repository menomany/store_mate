<?php
session_start();

// تعريف متغيرات الجلسة إذا لم تكن موجودة
if (!isset($_SESSION['full_name'])) {
    // إعادة التوجيه للدخول أو تعيين قيم افتراضية
    header('Location: login.php');
    exit;
}

require_once 'includes/db_connection.php';
require_once 'includes/auth_check.php';

$page_title = "الأصناف";

// جلب المنتجات مع حسابات المخزون
$search = $_GET['search'] ?? '';
$category_id = $_GET['category_id'] ?? '';
$low_stock = isset($_GET['low_stock']) ? 1 : 0;

$query = "SELECT p.*, c.category_name,
          (SELECT COALESCE(SUM(CASE WHEN t.trans_type IN ('in', 'return') THEN td.quantity ELSE 0 END), 0)
           FROM transaction_details td 
           JOIN transactions t ON td.trans_id = t.trans_id 
           WHERE td.product_id = p.product_id) as total_in,
          (SELECT COALESCE(SUM(CASE WHEN t.trans_type IN ('out', 'issue') THEN td.quantity ELSE 0 END), 0)
           FROM transaction_details td 
           JOIN transactions t ON td.trans_id = t.trans_id 
           WHERE td.product_id = p.product_id) as total_out
          FROM products p 
          LEFT JOIN categories c ON p.category_id = c.category_id 
          WHERE 1=1";

$params = [];

if (!empty($search)) {
    $searchTerm = "%$search%";
    $query .= " AND (p.product_name LIKE ? OR p.product_code LIKE ?)";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

if (!empty($category_id)) {
    $query .= " AND p.category_id = ?";
    $params[] = $category_id;
}

$query .= " ORDER BY p.product_name";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $products = $stmt->fetchAll();
} catch (PDOException $e) {
    $products = [];
    echo "<div class='alert alert-danger'>خطأ في جلب البيانات: " . $e->getMessage() . "</div>";
}

// جلب الفئات
try {
    $categories = $pdo->query("SELECT * FROM categories ORDER BY category_name")->fetchAll();
} catch (PDOException $e) {
    $categories = [];
}

// حساب الإحصائيات - هذا الجزء مهم جداً!
$stats = [
    'total_products' => 0,
    'low_stock_count' => 0,
    'total_categories' => 0,
    'total_items_in_stock' => 0
];

foreach($products as $product) {
    $stats['total_products']++;
    $initial_balance = $product['initial_balance'] ?? 0; // رصيد أول المدة
    $current_stock = (($product['initial_balance'] ?? 0) + ($product['total_in'] ?? 0)) - ($product['total_out'] ?? 0);
    $stats['total_items_in_stock'] += $current_stock;
    
    if($current_stock <= ($product['min_stock_level'] ?? 0)) {
        $stats['low_stock_count']++;
    }
}

$stats['total_categories'] = count($categories);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - StoreMate</title>
    
<!-- Bootstrap CSS مع نسخة احتياطية محلية -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" 
      integrity="sha384-PJsj/BTMqILvmcej7ulplguok8ag4xFTPry3qS8VgN3b4F+8sRj4Lz5q3Tz5z5z5" 
      crossorigin="anonymous">
<link rel="stylesheet" href="assets/css/bootstrap.rtl.min.css" 
      onerror="this.onerror=null;this.href='assets/css/bootstrap.min.css';">

<!-- Bootstrap Icons مع نسخة احتياطية محلية -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
<link rel="stylesheet" href="assets/css/bootstrap-icons.css">

<!-- الخط العربي مع نسخة احتياطية -->
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
    @font-face {
        font-family: 'Cairo';
        src: url('assets/fonts/Cairo-Regular.ttf') format('truetype');
        font-weight: normal;
        font-style: normal;
    }
    /* يمكنك إضافة أوزان أخرى للخط إذا توفرت */
</style>
    
    <!-- الأنماط العامة -->
    <?php include 'includes/styles.php'; ?>
    
    <style>
        /* أنماط إضافية خاصة بالصفحة */
        .content-area {
            min-height: 80vh;
        }
        
        .stat-value {
            font-size: 1.8rem;
            font-weight: bold;
        }
        
        .stat-label {
            font-size: 0.9rem;
            color: #6c757d;
        }
        
        .product-code {
            font-family: 'Courier New', monospace;
            background-color: #f8f9fa;
            padding: 2px 6px;
            border-radius: 4px;
            border: 1px solid #dee2e6;
        }
        
        .action-buttons .btn {
            min-width: 40px;
        }
    </style>
</head>
<body>
    <!-- السايدبار -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- الشريط العلوي -->
        <?php include 'includes/header.php'; ?>
        
        <!-- بطاقة الترحيب -->
        <div class="welcome-card fade-in">
            <div class="container p-4 position-relative">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h2 class="mb-2">إدارة الأصناف</h2>
                        <p class="mb-0 opacity-75">إدارة وتتبع جميع الأصناف في المخازن</p>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <button class="btn btn-light" data-bs-toggle="modal" data-bs-target="#addProductModal">
                            <i class="bi bi-plus-circle me-1"></i>إضافة صنف
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- بطاقات الإحصائيات -->
        <div class="row mb-4 fade-in">
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card products h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">إجمالي الأصناف</h6>
                                <h3 class="mb-0 stat-value"><?php echo $stats['total_products']; ?></h3>
                                <small class="text-primary stat-label">صنف في النظام</small>
                            </div>
                            <div class="stat-icon products">
                                <i class="bi bi-box-seam"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card warning h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">منخفضة المخزون</h6>
                                <h3 class="mb-0 stat-value"><?php echo $stats['low_stock_count']; ?></h3>
                                <small class="text-warning stat-label">تحتاج لإعادة تزويد</small>
                            </div>
                            <div class="stat-icon warning">
                                <i class="bi bi-exclamation-triangle"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card info h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">الفئات</h6>
                                <h3 class="mb-0 stat-value"><?php echo $stats['total_categories']; ?></h3>
                                <small class="text-info stat-label">فئة مختلفة</small>
                            </div>
                            <div class="stat-icon info">
                                <i class="bi bi-tags"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="card stat-card success h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">إجمالي المخزون</h6>
                                <h3 class="mb-0 stat-value"><?php echo number_format($stats['total_items_in_stock'], 2); ?></h3>
                                <small class="text-success stat-label">وحدة في المخازن</small>
                            </div>
                            <div class="stat-icon success">
                                <i class="bi bi-boxes"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      
        <!-- فلترة البحث -->
        <div class="card mb-4 fade-in">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-4">
                        <input type="text" class="form-control" name="search" placeholder="بحث بالاسم أو الكود" 
                               value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="col-md-3">
                        <select class="form-select" name="category_id">
                            <option value="">كل الفئات</option>
                            <?php foreach($categories as $cat): ?>
                            <option value="<?php echo $cat['category_id']; ?>" 
                                    <?php echo ($category_id == $cat['category_id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($cat['category_name']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <div class="form-check mt-2">
                            <input class="form-check-input" type="checkbox" name="low_stock" value="1" 
                                   id="lowStock" <?php echo $low_stock ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="lowStock">
                                المخزون المنخفض فقط
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-search"></i> بحث
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- جدول المنتجات -->
        <div class="dashboard-table fade-in">
            <div class="card">
                <div class="card-body">
                    <?php if(count($products) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>كود المنتج</th>
                                    <th>اسم المنتج</th>
                                    <th>الفئة</th>
                                    <th>رصيد أول </th>
                                    <th>حد الطلب</th>
                                    <th>الوارد</th>
                                    <th>الصادر</th>
                                    <th>الرصيد</th>
                                    <th>الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($products as $index => $product): 
                                    $current_stock = ($product['initial_balance'] ?? 0 + ($product['total_in'] ?? 0)) - ($product['total_out'] ?? 0);
                                    $is_low_stock = $current_stock <= ($product['min_stock_level'] ?? 0);
                                    
                                ?>
                                <tr class="<?php echo $is_low_stock ? 'table-warning' : ''; ?>">
                                    <td><?php echo $index + 1; ?></td>
                                    <td>
                                        <span class="product-code">
                                            <?php echo htmlspecialchars($product['product_code'] ?? '---'); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($product['product_name']); ?></strong>
                                        <?php if($product['is_cable'] ?? 0): ?>
                                        <span class="badge bg-info ms-2">كابل</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($product['category_name'] ?? '---'); ?></td>
                                    <td><?php echo number_format($product['initial_balance'] ?? 0,0); ?></td>
                                    <td><?php echo number_format($product['min_stock_level'] ?? 0, 0); ?></td>
                                    <td><?php echo number_format($product['total_in'] ?? 0,0); ?></td>
                                    <td><?php echo number_format($product['total_out'] ?? 0,0); ?></td>
                                    <td>
                                        <span class="<?php echo $is_low_stock ? 'text-danger fw-bold' : 'text-success'; ?>">
                                            <?php echo number_format($current_stock, 0); ?>
                                        </span>
                                        <?php if($is_low_stock): ?>
                                        <i class="bi bi-exclamation-triangle text-danger ms-1" 
                                           title="المخزون منخفض"></i>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm action-buttons">
                                            <button class="btn btn-outline-info" 
                                                    onclick="viewProduct(<?php echo $product['product_id']; ?>)"
                                                    title="عرض"
                                                    data-bs-toggle="tooltip">
                                                <i class="bi bi-eye"></i>
                                            </button>
                                            <button class="btn btn-outline-warning"
                                                    onclick="editProduct(<?php echo $product['product_id']; ?>)"
                                                    title="تعديل"
                                                    data-bs-toggle="tooltip">
                                                <i class="bi bi-pencil"></i>
                                            </button>
                                            <button class="btn btn-outline-danger" 
                                                    onclick="deleteProduct(<?php echo $product['product_id']; ?>, '<?php echo htmlspecialchars($product['product_name']); ?>')"
                                                    title="حذف"
                                                    data-bs-toggle="tooltip">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="text-center py-5">
                        <i class="bi bi-inbox display-1 text-muted"></i>
                        <h5 class="mt-3">لا توجد منتجات</h5>
                        <p class="text-muted">ابدأ بإضافة منتجات جديدة إلى النظام</p>
                        <button class="btn btn-primary mt-3" data-bs-toggle="modal" data-bs-target="#addProductModal">
                            <i class="bi bi-plus-circle me-1"></i>إضافة أول منتج
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- المنتجات المنخفضة المخزون -->
        <?php 
        $low_stock_products = array_filter($products, function($product) {
            $current_stock = (($product['initial_balance'] ?? 0) + ($product['total_in'] ?? 0)) - ($product['total_out'] ?? 0);
            return $current_stock <= ($product['min_stock_level'] ?? 0);
        });
        
        if(count($low_stock_products) > 0): ?>
        <div class="row mt-4 fade-in">
            <div class="col-12">
                <div class="dashboard-table">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <i class="bi bi-exclamation-triangle me-2 text-warning"></i> المنتجات المنخفضة المخزون
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <?php foreach($low_stock_products as $product): 
                                    $current_stock = ($product['total_in'] ?? 0) - ($product['total_out'] ?? 0);
                                    $min_stock = $product['min_stock_level'] ?? 0;
                                    $percentage = $min_stock > 0 ? ($current_stock / $min_stock) * 100 : 0;
                                ?>
                                <div class="col-md-6 col-lg-4 mb-3">
                                    <div class="low-stock-item">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <strong class="text-dark"><?php echo htmlspecialchars($product['product_name']); ?></strong>
                                            <span class="badge bg-danger"><?php echo number_format($current_stock, 2); ?></span>
                                        </div>
                                        <div class="progress mb-2" style="height: 8px;">
                                            <div class="progress-bar bg-danger" 
                                                 style="width: <?php echo min($percentage, 100); ?>%"
                                                 role="progressbar"
                                                 aria-valuenow="<?php echo $percentage; ?>"
                                                 aria-valuemin="0"
                                                 aria-valuemax="100"></div>
                                        </div>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <small class="text-muted">
                                                حد الطلب: <strong><?php echo number_format($min_stock, 2); ?></strong>
                                            </small>
                                            <a href="#" onclick="orderProduct(<?php echo $product['product_id']; ?>)" 
                                               class="btn btn-sm btn-warning">
                                                <i class="bi bi-cart-plus me-1"></i>طلب
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <!-- الفوتر -->
    <?php include 'includes/footer.php'; ?>
    
    <!-- مودال إضافة منتج -->
<div class="modal fade" id="addProductModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header"> <h5 class="modal-title">إضافة منتج جديد</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form action="api/save_product.php" method="POST" id="productForm">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">اسم المنتج *</label>
                                <input type="text" class="form-control" name="product_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">كود المنتج</label>
                                <input type="text" class="form-control" name="product_code">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">الفئة</label>
                                <select class="form-select" name="category_id">
                                    <option value="">اختر الفئة</option>
                                    <?php foreach($categories as $cat): ?>
                                    <option value="<?php echo $cat['category_id']; ?>">
                                        <?php echo htmlspecialchars($cat['category_name']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">حد الطلب الأدنى</label>
                                <input type="number" class="form-control" name="min_stock_level" step="0.01" value="0">
                            </div>
                            <div class="col-md-6 mb-3">
                                 <label class="form-label">رصيد أول المدة</label>
                                 <input type="number" class="form-control" name="initial_balance" step="0.001" value="0" min="0">
                                 <small class="form-text text-muted">الكمية المتوفرة حالياً في المخزون</small>
                            </div>

                            <div class="col-12 mb-3">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="is_cable" name="is_cable" value="1">
                                    <label class="form-check-label" for="is_cable">منتج من نوع كابل</label>
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="p-3 bg-light border rounded">
                                    <h6 class="mb-3 fw-bold">إعدادات الوحدات والأسعار</h6>
                                    
                                    <div class="row g-2 align-items-end mb-2">
                                        <div class="col-md-4">
                                            <label class="form-label small">الوحدة الصغرى (نص)</label>
                                            <input type="text" class="form-control form-control-sm" name="units[0][name]" placeholder="مثلاً: قطعة" required>
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label small">سعر البيع</label>
                                            <input type="number" class="form-control form-control-sm" name="units[0][price]" step="0.01" value="0">
                                        </div>
                                        <input type="hidden" name="units[0][factor]" value="1">
                                    </div>

                                    <div id="extraUnitsContainer"></div>

                                    <button type="button" class="btn btn-sm btn-outline-primary mt-2" onclick="addExtraUnit()">
                                        <i class="bi bi-plus-circle me-1"></i> إضافة وحدة كبرى
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary">حفظ المنتج</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- الاسكريبتات العامة -->
    <?php include 'includes/scripts.php'; ?>
    
    <script>
    // وظائف خاصة بصفحة المنتجات
    function viewProduct(id) {
        window.location.href = 'product_details.php?id=' + id;
    }
    
    function editProduct(id) {
        window.location.href = 'edit_product.php?id=' + id;
    }
    
    function deleteProduct(id, name) {
        if(confirm(`هل أنت متأكد من حذف المنتج "${name}"؟`)) {
            fetch(`api/delete_product.php?id=${id}`, {
                method: 'DELETE'
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    alert('تم الحذف بنجاح');
                    window.location.reload();
                } else {
                    alert(data.message || 'حدث خطأ أثناء الحذف');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('حدث خطأ في الاتصال');
            });
        }
    }
    
    function orderProduct(id) {
        alert('طلب المنتج: ' + id);
        // يمكن تنفيذ وظيفة طلب المنتج هنا
    }
    
    // معالجة نموذج إضافة المنتج
    document.getElementById('productForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        
        fetch('api/save_product.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                alert('تم إضافة المنتج بنجاح');
                window.location.reload();
            } else {
                alert('حدث خطأ: ' + (data.message || 'غير معروف'));
            }
        })
        .catch(error => {
            alert('حدث خطأ في الاتصال بالخادم');
        });
    });
    
    // تهيئة أدوات التلميح
    document.addEventListener('DOMContentLoaded', function() {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    });
    // المتغير ده عشان ندي أرقام فريدة لكل وحدة كبرى جديدة
let unitIndex = 1; 

function addExtraUnit() {
    const container = document.getElementById('extraUnitsContainer');
    const html = `
        <div class="row g-2 align-items-end mb-3 border p-2 rounded bg-white shadow-sm">
            <div class="col-md-3">
                <label class="form-label small fw-bold">اسم الوحدة الكبرى</label>
                <input type="text" class="form-control form-control-sm" name="units[${unitIndex}][name]" placeholder="مثلاً: كرتونة" required>
            </div>
            <div class="col-md-3">
                <label class="form-label small text-muted">سعر البيع</label>
                <input type="number" class="form-control form-control-sm" name="units[${unitIndex}][price]" step="0.01" value="0.00">
            </div>
            <div class="col-md-4">
                <label class="form-label small text-muted">معامل الضرب (كم وحدة صغرى؟)</label>
                <input type="number" class="form-control form-control-sm" name="units[${unitIndex}][factor]" placeholder="مثال: 12" required>
            </div>
            <div class="col-md-2 text-end">
                <button type="button" class="btn btn-sm btn-danger" onclick="this.closest('.row').remove()">
                    <i class="bi bi-trash"></i> حذف
                </button>
            </div>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', html);
    unitIndex++;
}
    </script>
</body>
</html>