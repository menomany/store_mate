<?php
// user_details.php - لعرض تفاصيل مستخدم معين
session_start();

if (!isset($_SESSION['full_name'])) {
    $_SESSION['full_name'] = 'مستخدم النظام';
    $_SESSION['role'] = 'مدير';
}

require_once 'includes/db_connection.php';
require_once 'includes/auth_check.php';

$page_title = "تفاصيل المستخدم";

// التحقق من وجود معرف المستخدم
$user_id = $_GET['id'] ?? 0;
if (!$user_id) {
    header('Location: users.php');
    exit;
}

// جلب بيانات المستخدم
try {
    $stmt = $pdo->prepare("
        SELECT u.*, 
        DATE_FORMAT(u.last_login, '%Y-%m-%d %H:%i') as last_login_formatted,
        DATE_FORMAT(u.created_at, '%Y-%m-%d %H:%i') as created_at_formatted,
        (SELECT COUNT(*) FROM transactions t WHERE t.user_id = u.id) as transactions_count
        FROM users u WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        header('Location: users.php');
        exit;
    }
} catch (PDOException $e) {
    die("<div class='alert alert-danger'>خطأ في جلب بيانات المستخدم: " . $e->getMessage() . "</div>");
}

// جلب آخر عمليات المستخدم
try {
    $transactions_stmt = $pdo->prepare("
        SELECT t.*, 
               DATE_FORMAT(t.trans_date, '%Y-%m-%d %H:%i') as trans_date_formatted,
               c.contact_name,
               p.project_name,
               CASE 
                   WHEN t.trans_type = 'in' THEN 'وارد'
                   WHEN t.trans_type = 'out' THEN 'صادر'
                   WHEN t.trans_type = 'issue' THEN 'صرف'
                   WHEN t.trans_type = 'return' THEN 'مرتجع'
                   WHEN t.trans_type = 'transfer' THEN 'تحويل'
                   ELSE t.trans_type
               END as trans_type_arabic
        FROM transactions t
        LEFT JOIN contacts c ON t.contact_id = c.contact_id
        LEFT JOIN projects p ON t.project_id = p.project_id
        WHERE t.user_id = ?
        ORDER BY t.trans_date DESC
        LIMIT 10
    ");
    $transactions_stmt->execute([$user_id]);
    $recent_transactions = $transactions_stmt->fetchAll();
} catch (PDOException $e) {
    $recent_transactions = [];
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($user['full_name']) . ' - ' . $page_title; ?> - StoreMate</title>
    
    <?php include 'includes/styles.php'; ?>
    
    <style>
        .user-header {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            border-radius: 10px;
            padding: 2rem;
            margin-bottom: 2rem;
        }
        
        .user-avatar-large {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            margin: 0 auto 20px;
            color: white;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
    </style>
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include 'includes/header.php'; ?>
        
        <div class="container mt-4">
            <div class="user-header fade-in">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <div class="d-flex align-items-center mb-3">
                            <a href="users.php" class="btn btn-light btn-sm me-3">
                                <i class="bi bi-arrow-right me-1"></i> رجوع
                            </a>
                            <h2 class="mb-0">تفاصيل المستخدم</h2>
                        </div>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <a href="edit_user.php?id=<?php echo $user_id; ?>" class="btn btn-warning">
                            <i class="bi bi-pencil-square me-1"></i> تعديل
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <div class="card">
                        <div class="card-body text-center">
                            <div class="user-avatar-large">
                                <?php 
                                $initials = '';
                                $names = explode(' ', $user['full_name']);
                                foreach($names as $name) {
                                    $initials .= strtoupper(substr($name, 0, 1));
                                }
                                echo substr($initials, 0, 2);
                                ?>
                            </div>
                            
                            <h4 class="card-title"><?php echo htmlspecialchars($user['full_name']); ?></h4>
                            <p class="text-muted">@<?php echo htmlspecialchars($user['username']); ?></p>
                            
                            <div class="mb-3">
                                <span class="badge bg-<?php 
                                switch($user['status']) {
                                    case 'active': echo 'success'; break;
                                    case 'inactive': echo 'warning'; break;
                                    case 'suspended': echo 'danger'; break;
                                    default: echo 'secondary';
                                }
                                ?>">
                                    <?php 
                                    switch($user['status']) {
                                        case 'active': echo 'نشط'; break;
                                        case 'inactive': echo 'غير نشط'; break;
                                        case 'suspended': echo 'موقوف'; break;
                                        default: echo $user['status'];
                                    }
                                    ?>
                                </span>
                                
                                <span class="badge bg-primary ms-1">
                                    <?php echo htmlspecialchars($user['role']); ?>
                                </span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card mt-3">
                        <div class="card-header">
                            <h6 class="mb-0">معلومات الاتصال</h6>
                        </div>
                        <div class="card-body">
                            <?php if($user['email']): ?>
                            <div class="mb-2">
                                <i class="bi bi-envelope me-2 text-muted"></i>
                                <a href="mailto:<?php echo $user['email']; ?>">
                                    <?php echo htmlspecialchars($user['email']); ?>
                                </a>
                            </div>
                            <?php endif; ?>
                            
                            <?php if($user['phone']): ?>
                            <div class="mb-2">
                                <i class="bi bi-telephone me-2 text-muted"></i>
                                <a href="tel:<?php echo $user['phone']; ?>">
                                    <?php echo htmlspecialchars($user['phone']); ?>
                                </a>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-8 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h6 class="mb-0">معلومات الحساب</h6>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label text-muted">اسم المستخدم</label>
                                    <p class="form-control-static">@<?php echo htmlspecialchars($user['username']); ?></p>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label text-muted">تاريخ الإنشاء</label>
                                    <p class="form-control-static"><?php echo $user['created_at_formatted']; ?></p>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label text-muted">آخر دخول</label>
                                    <p class="form-control-static">
                                        <?php echo $user['last_login_formatted'] ?: 'لم يسجل دخول'; ?>
                                    </p>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label text-muted">إجمالي العمليات</label>
                                    <p class="form-control-static"><?php echo $user['transactions_count']; ?> عملية</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <?php if(count($recent_transactions) > 0): ?>
                    <div class="card mt-3">
                        <div class="card-header">
                            <h6 class="mb-0">آخر العمليات</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>التاريخ</th>
                                            <th>نوع العملية</th>
                                            <th>المبلغ</th>
                                            <th>الجهة</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($recent_transactions as $index => $trans): ?>
                                        <tr>
                                            <td><?php echo $index + 1; ?></td>
                                            <td><?php echo $trans['trans_date_formatted']; ?></td>
                                            <td>
                                                <span class="badge bg-info">
                                                    <?php echo $trans['trans_type_arabic']; ?>
                                                </span>
                                            </td>
                                            <td><?php echo number_format($trans['total_amount'] ?? 0, 2); ?> ج.م</td>
                                            <td>
                                                <?php echo $trans['contact_name'] ?: ($trans['project_name'] ?: '---'); ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <?php include 'includes/footer.php'; ?>
    <?php include 'includes/scripts.php'; ?>
</body>
</html>