<?php
session_start();

// تسجيل نشاط الخروج
if (isset($_SESSION['user_id'])) {
    require_once 'includes/db_connection.php';
    try {
        $stmt = $pdo->prepare("INSERT INTO user_activity (user_id, action, ip_address) VALUES (?, ?, ?)");
        $stmt->execute([$_SESSION['user_id'], 'تسجيل الخروج', $_SERVER['REMOTE_ADDR']]);
    } catch (Exception $e) {
        // تجاهل الخطأ
    }
}

// تدمير الجلسة
session_destroy();

// إعادة التوجيه لصفحة الدخول
header('Location: login.php');
exit;