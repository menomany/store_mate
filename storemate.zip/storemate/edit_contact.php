<?php
session_start();

// التحقق من وجود المستخدم
if (!isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}

require_once 'includes/db_connection.php';
require_once 'includes/auth_check.php';

$page_title = "تعديل جهة الاتصال";

// الحصول على معرف جهة الاتصال من الرابط
$contact_id = $_GET['id'] ?? 0;

if (!$contact_id) {
    header('Location: contacts.php');
    exit;
}

// جلب بيانات جهة الاتصال
try {
    $stmt = $pdo->prepare("SELECT * FROM contacts WHERE contact_id = ?");
    $stmt->execute([$contact_id]);
    $contact = $stmt->fetch();
    
    if (!$contact) {
        header('Location: contacts.php');
        exit;
    }
} catch (PDOException $e) {
    echo "<div class='alert alert-danger'>خطأ في جلب البيانات: " . $e->getMessage() . "</div>";
    exit;
}

// إذا كان هناك طلب POST (تحديث البيانات)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $contact_name = $_POST['contact_name'] ?? '';
    $contact_type = $_POST['contact_type'] ?? '';
    $phone_number = $_POST['phone_number'] ?? null;
    $address = $_POST['address'] ?? null;
    $initial_balance = $_POST['initial_balance'] ?? 0.00;
    
    // التحقق من البيانات المطلوبة
    if (empty($contact_name) || empty($contact_type)) {
        $error = "الاسم والنوع مطلوبان";
    } else {
        try {
            // حساب الرصيد الحالي بناءً على التغيير في الرصيد الأولي
            $old_initial = $contact['initial_balance'];
            $old_current = $contact['current_balance'];
            $new_current = $old_current + ($initial_balance - $old_initial);
            
            // تحديث البيانات
            $stmt = $pdo->prepare("UPDATE contacts SET 
                contact_name = ?, 
                contact_type = ?, 
                phone_number = ?, 
                address = ?, 
                initial_balance = ?,
                current_balance = ?
                WHERE contact_id = ?");
            
            $stmt->execute([$contact_name, $contact_type, $phone_number, $address, $initial_balance, $new_current, $contact_id]);
            
            $success = "تم تحديث بيانات جهة الاتصال بنجاح";
            
            // تحديث بيانات $contact للعرض
            $contact['contact_name'] = $contact_name;
            $contact['contact_type'] = $contact_type;
            $contact['phone_number'] = $phone_number;
            $contact['address'] = $address;
            $contact['initial_balance'] = $initial_balance;
            $contact['current_balance'] = $new_current;
            
        } catch (PDOException $e) {
            $error = "خطأ في قاعدة البيانات: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - StoreMate</title>
    
    <!-- Bootstrap CSS مع نسخة احتياطية محلية -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.rtl.min.css" 
          onerror="this.onerror=null;this.href='assets/css/bootstrap.min.css';">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    
    <!-- الخط العربي -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    
    <!-- الأنماط العامة -->
    <?php include 'includes/styles.php'; ?>
    
    <style>
        .contact-avatar-large {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 2rem;
            margin: 0 auto 20px;
        }
        
        .form-card {
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .info-card {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .balance-info {
            background: #e8f4fd;
            border-right: 4px solid #0d6efd;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
        }
        
        .alert-area {
            position: fixed;
            top: 20px;
            left: 20px;
            right: 20px;
            z-index: 9999;
        }
    </style>
</head>
<body>
    <!-- السايدبار -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- الشريط العلوي -->
        <?php include 'includes/header.php'; ?>
        
        <!-- عرض الرسائل -->
        <?php if(isset($error)): ?>
        <div class="alert-area">
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle me-2"></i>
                <?php echo $error; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if(isset($success)): ?>
        <div class="alert-area">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-2"></i>
                <?php echo $success; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- بطاقة الترحيب -->
        <div class="welcome-card fade-in">
            <div class="container p-4 position-relative">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h2 class="mb-2">تعديل جهة الاتصال</h2>
                        <p class="mb-0 opacity-75">تعديل بيانات جهة الاتصال: <?php echo htmlspecialchars($contact['contact_name']); ?></p>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <a href="contact_details.php?id=<?php echo $contact_id; ?>" class="btn btn-light me-2">
                            <i class="bi bi-arrow-right me-1"></i>رجوع للتفاصيل
                        </a>
                        <a href="contacts.php" class="btn btn-secondary">
                            <i class="bi bi-list me-1"></i>قائمة جهات الاتصال
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- محتوى الصفحة -->
        <div class="row mb-4 fade-in">
            <!-- العمود الأيمن: صورة ومعلومات سريعة -->
            <div class="col-lg-4 mb-4">
                <div class="card form-card">
                    <div class="card-body text-center">
                        <div class="contact-avatar-large mb-3">
                            <?php echo mb_substr($contact['contact_name'], 0, 1, 'UTF-8'); ?>
                        </div>
                        
                        <h4 class="mb-3"><?php echo htmlspecialchars($contact['contact_name']); ?></h4>
                        
                        <div class="info-card">
                            <h6 class="mb-3">معلومات سريعة</h6>
                            
                            <div class="mb-2">
                                <small class="text-muted d-block">معرف الجهة</small>
                                <strong>#<?php echo $contact_id; ?></strong>
                            </div>
                            
                            <div class="mb-2">
                                <small class="text-muted d-block">تاريخ الإضافة</small>
                                <strong><?php echo date('Y/m/d', strtotime($contact['created_at'])); ?></strong>
                            </div>
                            
                            <div class="mb-2">
                                <small class="text-muted d-block">آخر تحديث</small>
                                <strong><?php echo date('Y/m/d H:i', strtotime($contact['created_at'])); ?></strong>
                            </div>
                            
                            <div class="mb-2">
                                <small class="text-muted d-block">الرصيد الحالي</small>
                                <strong class="<?php echo $contact['current_balance'] > 0 ? 'text-success' : ($contact['current_balance'] < 0 ? 'text-danger' : 'text-muted'); ?>">
                                    <?php echo number_format($contact['current_balance'], 2); ?>
                                </strong>
                            </div>
                        </div>
                        
                        <div class="balance-info">
                            <h6 class="mb-3">معلومات الرصيد</h6>
                            <p class="small mb-2">
                                عند تعديل الرصيد الأولي، سيتم تعديل الرصيد الحالي تلقائياً للحفاظ على صحة البيانات.
                            </p>
                            <div class="d-flex justify-content-between mb-1">
                                <span>الرصيد الأولي الحالي:</span>
                                <span><?php echo number_format($contact['initial_balance'], 2); ?></span>
                            </div>
                            <div class="d-flex justify-content-between mb-1">
                                <span>الرصيد الحالي:</span>
                                <span><?php echo number_format($contact['current_balance'], 2); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- العمود الأيسر: نموذج التعديل -->
            <div class="col-lg-8">
                <div class="card form-card">
                    <div class="card-body">
                        <h5 class="card-title mb-4">تعديل البيانات</h5>
                        
                        <form method="POST" id="editContactForm">
                            <input type="hidden" name="contact_id" value="<?php echo $contact_id; ?>">
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">اسم جهة الاتصال *</label>
                                    <input type="text" class="form-control" name="contact_name" 
                                           value="<?php echo htmlspecialchars($contact['contact_name']); ?>" required>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">نوع جهة الاتصال *</label>
                                    <select class="form-select" name="contact_type" required>
                                        <option value="">اختر النوع</option>
                                        <option value="supplier" <?php echo $contact['contact_type'] == 'supplier' ? 'selected' : ''; ?>>مورد</option>
                                        <option value="customer" <?php echo $contact['contact_type'] == 'customer' ? 'selected' : ''; ?>>عميل</option>
                                        <option value="contractor" <?php echo $contact['contact_type'] == 'contractor' ? 'selected' : ''; ?>>مقاول</option>
                                    </select>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">رقم الهاتف</label>
                                    <input type="tel" class="form-control" name="phone_number" 
                                           value="<?php echo htmlspecialchars($contact['phone_number'] ?? ''); ?>">
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">رصيد أولي</label>
                                    <input type="number" class="form-control" name="initial_balance" 
                                           value="<?php echo $contact['initial_balance']; ?>" step="0.01" required>
                                    <small class="form-text text-muted">الرصيد الافتتاحي لجهة الاتصال</small>
                                </div>
                                
                                <div class="col-12 mb-3">
                                    <label class="form-label">العنوان</label>
                                    <textarea class="form-control" name="address" rows="3"><?php echo htmlspecialchars($contact['address'] ?? ''); ?></textarea>
                                </div>
                                
                                <div class="col-12">
                                    <div class="alert alert-info">
                                        <i class="bi bi-info-circle me-2"></i>
                                        <strong>ملاحظة:</strong> سيتم تحديث الرصيد الحالي تلقائياً بناءً على التغيير في الرصيد الأولي.
                                    </div>
                                </div>
                            </div>
                            
                            <hr class="my-4">
                            
                            <div class="d-flex justify-content-between">
                                <div>
                                    <a href="contact_details.php?id=<?php echo $contact_id; ?>" class="btn btn-secondary">
                                        <i class="bi bi-x-circle me-1"></i>إلغاء
                                    </a>
                                    <button type="button" class="btn btn-danger ms-2" 
                                            onclick="deleteContact(<?php echo $contact_id; ?>, '<?php echo htmlspecialchars($contact['contact_name']); ?>')">
                                        <i class="bi bi-trash me-1"></i>حذف
                                    </button>
                                </div>
                                <div>
                                    <button type="reset" class="btn btn-outline-secondary me-2">
                                        <i class="bi bi-arrow-clockwise me-1"></i>استعادة
                                    </button>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-check-circle me-1"></i>حفظ التغييرات
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- قسم سريع للحركات -->
                <div class="card form-card mt-4">
                    <div class="card-body">
                        <h5 class="card-title mb-3">حركات سريعة</h5>
                        <p class="text-muted mb-4">يمكنك إنشاء حركة جديدة لهذه جهة الاتصال مباشرة:</p>
                        
                        <div class="row g-2">
                            <div class="col-md-3 col-6">
                                <a href="add_transaction.php?type=in&contact_id=<?php echo $contact_id; ?>" class="btn btn-success w-100">
                                    <i class="bi bi-box-arrow-in-down me-1"></i>وارد
                                </a>
                            </div>
                            <div class="col-md-3 col-6">
                                <a href="add_transaction.php?type=out&contact_id=<?php echo $contact_id; ?>" class="btn btn-danger w-100">
                                    <i class="bi bi-box-arrow-up me-1"></i>صادر
                                </a>
                            </div>
                            <div class="col-md-3 col-6">
                                <a href="add_transaction.php?type=issue&contact_id=<?php echo $contact_id; ?>" class="btn btn-warning w-100">
                                    <i class="bi bi-box-arrow-right me-1"></i>صرف
                                </a>
                            </div>
                            <div class="col-md-3 col-6">
                                <a href="add_transaction.php?type=return&contact_id=<?php echo $contact_id; ?>" class="btn btn-info w-100">
                                    <i class="bi bi-arrow-counterclockwise me-1"></i>مرتجع
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- الفوتر -->
    <?php include 'includes/footer.php'; ?>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- الاسكريبتات العامة -->
    <?php include 'includes/scripts.php'; ?>
    
    <script>
    // وظيفة حذف جهة الاتصال
    function deleteContact(id, name) {
        if(confirm(`هل أنت متأكد من حذف جهة الاتصال "${name}"؟`)) {
            fetch(`api/delete_contact.php?id=${id}`, {
                method: 'DELETE'
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    alert('تم حذف جهة الاتصال بنجاح');
                    window.location.href = 'contacts.php';
                } else {
                    alert(data.message || 'حدث خطأ أثناء الحذف');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('حدث خطأ في الاتصال');
            });
        }
    }
    
    // معالجة نموذج التعديل
    document.getElementById('editContactForm').addEventListener('submit', function(e) {
        // يمكن إضافة تحقق إضافي هنا إذا لزم الأمر
        return true;
    });
    
    // إغلاق الرسائل بعد 5 ثواني
    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(function() {
            var alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                var bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
    });
    </script>
</body>
</html>