<?php
require_once '../includes/db_connection.php';

$date = $_GET['date'] ?? date('Y-m-d');

// إحصائيات اليوم
$stmt = $pdo->prepare("
    SELECT 
        (SELECT COUNT(*) FROM transactions WHERE DATE(trans_date) = ? AND trans_type = 'in') as in_count,
        (SELECT COUNT(*) FROM transactions WHERE DATE(trans_date) = ? AND trans_type = 'out') as out_count,
        (SELECT COALESCE(SUM(total_amount), 0) FROM transactions WHERE DATE(trans_date) = ? AND trans_type = 'in') as in_total,
        (SELECT COALESCE(SUM(total_amount), 0) FROM transactions WHERE DATE(trans_date) = ? AND trans_type = 'out') as out_total
");
$stmt->execute([$date, $date, $date, $date]);
$stats = $stmt->fetch();

// حركات اليوم
$stmt = $pdo->prepare("
    SELECT t.*, c.contact_name, u.username
    FROM transactions t
    LEFT JOIN contacts c ON t.contact_id = c.contact_id
    LEFT JOIN users u ON t.user_id = u.id
    WHERE DATE(t.trans_date) = ?
    ORDER BY t.trans_date DESC
");
$stmt->execute([$date]);
$transactions = $stmt->fetchAll();
?>

<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3 mb-4">
            <div class="col-md-3">
                <input type="date" class="form-control" name="date" value="<?php echo $date; ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">عرض</button>
            </div>
            <div class="col-md-2">
                <button type="button" class="btn btn-success w-100" onclick="printDailyReport()">
                    <i class="bi bi-printer me-1"></i> طباعة
                </button>
            </div>
        </form>

        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card bg-light">
                    <div class="card-body text-center">
                        <h6 class="text-muted">حركات الوارد</h6>
                        <h3><?php echo $stats['in_count']; ?></h3>
                        <h6><?php echo number_format($stats['in_total'], 2); ?> ج.م</h6>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-light">
                    <div class="card-body text-center">
                        <h6 class="text-muted">حركات الصادر</h6>
                        <h3><?php echo $stats['out_count']; ?></h3>
                        <h6><?php echo number_format($stats['out_total'], 2); ?> ج.م</h6>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-light">
                    <div class="card-body text-center">
                        <h6 class="text-muted">صافي الحركات</h6>
                        <h3><?php echo $stats['in_count'] + $stats['out_count']; ?></h3>
                        <h6><?php echo number_format($stats['in_total'] - $stats['out_total'], 2); ?> ج.م</h6>
                    </div>
                </div>
            </div>
        </div>

        <?php if(count($transactions) > 0): ?>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr class="table-primary">
                        <th>#</th>
                        <th>الوقت</th>
                        <th>نوع الحركة</th>
                        <th>الجهة</th>
                        <th>المبلغ</th>
                        <th>المستخدم</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($transactions as $index => $trans): ?>
                    <tr>
                        <td><?php echo $index + 1; ?></td>
                        <td><?php echo date('H:i', strtotime($trans['trans_date'])); ?></td>
                        <td>
                            <?php
                            $type_text = [
                                'in' => 'وارد',
                                'out' => 'صادر',
                                'issue' => 'صرف مشروع',
                                'return' => 'مرتجع',
                                'transfer' => 'تحويل'
                            ];
                            echo $type_text[$trans['trans_type']] ?? $trans['trans_type'];
                            ?>
                        </td>
                        <td><?php echo htmlspecialchars($trans['contact_name'] ?? '---'); ?></td>
                        <td><?php echo number_format($trans['total_amount'], 2); ?> ج.م</td>
                        <td><?php echo htmlspecialchars($trans['username'] ?? '---'); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="text-center py-5">
            <i class="bi bi-inbox display-1 text-muted"></i>
            <h5 class="mt-3">لا توجد حركات لهذا اليوم</h5>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
function printDailyReport() {
    window.open('print_daily_report.php?date=<?php echo $date; ?>', '_blank');
}
</script>