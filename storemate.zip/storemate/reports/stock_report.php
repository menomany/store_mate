<?php
require_once '../includes/db_connection.php';

// جلب المنتجات مع رصيدها
$stmt = $pdo->query("
    SELECT p.*, c.category_name,
    COALESCE((SELECT SUM(td.quantity) 
     FROM transaction_details td 
     JOIN transactions t ON td.trans_id = t.trans_id 
     WHERE td.product_id = p.product_id AND t.trans_type IN ('in', 'return')), 0) as total_in,
    COALESCE((SELECT SUM(td.quantity) 
     FROM transaction_details td 
     JOIN transactions t ON td.trans_id = t.trans_id 
     WHERE td.product_id = p.product_id AND t.trans_type IN ('out', 'issue')), 0) as total_out
    FROM products p 
    LEFT JOIN categories c ON p.category_id = c.category_id 
    ORDER BY p.product_name
");
$products = $stmt->fetchAll();

// حساب الإجماليات
$total_products = count($products);
$low_stock_count = 0;
$out_of_stock = 0;

foreach($products as $product) {
    $current_stock = $product['total_in'] - $product['total_out'];
    if($current_stock <= $product['min_stock_level']) {
        $low_stock_count++;
    }
    if($current_stock <= 0) {
        $out_of_stock++;
    }
}
?>

<div class="card mb-4">
    <div class="card-body">
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card bg-light">
                    <div class="card-body text-center">
                        <h6 class="text-muted">إجمالي المنتجات</h6>
                        <h3><?php echo $total_products; ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-light">
                    <div class="card-body text-center">
                        <h6 class="text-muted">منخفضة المخزون</h6>
                        <h3 class="text-danger"><?php echo $low_stock_count; ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-light">
                    <div class="card-body text-center">
                        <h6 class="text-muted">نفذ من المخزون</h6>
                        <h3 class="text-danger"><?php echo $out_of_stock; ?></h3>
                    </div>
                </div>
            </div>
        </div>

        <?php if(count($products) > 0): ?>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr class="table-primary">
                        <th>#</th>
                        <th>المنتج</th>
                        <th>الفئة</th>
                        <th>الوارد</th>
                        <th>الصادر</th>
                        <th>الرصيد الحالي</th>
                        <th>حد الطلب</th>
                        <th>الحالة</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($products as $index => $product): 
                        $current_stock = $product['total_in'] - $product['total_out'];
                        $status = 'normal';
                        $status_text = 'طبيعي';
                        
                        if($current_stock <= 0) {
                            $status = 'danger';
                            $status_text = 'نفذ';
                        } elseif($current_stock <= $product['min_stock_level']) {
                            $status = 'warning';
                            $status_text = 'منخفض';
                        }
                    ?>
                    <tr class="table-<?php echo $status; ?>">
                        <td><?php echo $index + 1; ?></td>
                        <td>
                            <strong><?php echo htmlspecialchars($product['product_name']); ?></strong>
                            <?php if($product['is_cable']): ?>
                            <span class="badge bg-info ms-2">كابل</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($product['category_name'] ?? '---'); ?></td>
                        <td><?php echo number_format($product['total_in'], 3); ?></td>
                        <td><?php echo number_format($product['total_out'], 3); ?></td>
                        <td><strong><?php echo number_format($current_stock, 3); ?></strong></td>
                        <td><?php echo number_format($product['min_stock_level'], 2); ?></td>
                        <td>
                            <span class="badge bg-<?php echo $status; ?>">
                                <?php echo $status_text; ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="text-center py-5">
            <i class="bi bi-inbox display-1 text-muted"></i>
            <h5 class="mt-3">لا توجد منتجات</h5>
        </div>
        <?php endif; ?>
    </div>
</div>